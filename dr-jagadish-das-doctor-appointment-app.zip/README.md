# Dr. Jagadish Das (MBBS) - Clinic Appointment Booking Platform

A complete, modern, professional, and mobile-responsive Doctor Appointment Booking Website and Doctor Admin Console for **Dr. Jagadish Das (MBBS)**.

---

## Features

- **Public Medical Portal**: Doctor profile, qualifications, clinic timings, clinical services, embedded interactive Google Maps, and patient guidance.
- **Online Appointment Booking**:
  - Live available slot picker (10:00 AM – 1:00 PM & 5:00 PM – 8:00 PM).
  - Server-side atomic slot lock to prevent double booking.
  - Unique Appointment ID generation (`APT-2026-XXXX`).
- **Appointment Confirmation**:
  - Download `.ics` Calendar event or open in Google Calendar.
  - One-click Call Clinic and Google Maps Directions.
  - Patient self-cancellation.
  - Print-ready clinical appointment receipt.
- **SMS & WhatsApp Notification Architecture**:
  - Preferred: Meta WhatsApp Business API.
  - Automated Fallback: SMS Gateway (e.g. Fast2SMS, Twilio, Gupshup).
  - Instant dispatch to Doctor and Patient upon booking.
- **Doctor Admin Console** (`/admin/login` or `#admin`):
  - Metric cards: Today's visits, upcoming, total, confirmed, pending, cancelled, completed.
  - 7-day appointment distribution chart.
  - Search, filter by date & status, clinical notes editor, rescheduling, and status management.
  - Patient Directory with complete consultation history.
  - Availability manager for shifts, working days, slot duration, and custom holiday closures.
  - Audit log for all WhatsApp and SMS dispatches.
- **PWA (Progressive Web App)**: Installable directly onto mobile devices and desktop computers with offline caching.

---

## Local Setup & Quick Start

### 1. Requirements
- Node.js 18.x or 20.x+
- npm or yarn

### 2. Installation
```bash
# Extract the zip file and navigate into the folder:
cd dr-jagadish-das-doctor-appointment-app

# Install dependencies:
npm install
```

### 3. Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Configure your keys if connecting live Meta WhatsApp or SMS services:
```env
WHATSAPP_API_KEY="your_meta_whatsapp_api_token"
WHATSAPP_PHONE_NUMBER_ID="your_whatsapp_phone_number_id"
SMS_API_KEY="your_sms_api_key"
SMS_SENDER_ID="DRJDAS"
DOCTOR_PHONE_NUMBER="+919876543210"
ADMIN_JWT_SECRET="doctor_secure_secret_key_2026"
```

### 4. Running the Application
```bash
# Start development server with live backend API & frontend:
npm run dev
```
Open **http://localhost:3000** in your web browser.

---

## Admin Portal Login Credentials

- **URL**: `http://localhost:3000/#admin-login`
- **Email**: `doctor@drjagadishdas.com` *(or Mobile: `+919876543210`)*
- **Password**: `Doctor@2026`

---

## Production Build & Deployment

```bash
# Build production bundle:
npm run build

# Start production full-stack server:
npm start
```
