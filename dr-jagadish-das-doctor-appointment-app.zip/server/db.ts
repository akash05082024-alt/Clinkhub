import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

export interface DoctorProfile {
  id: string;
  name: string;
  degrees: string;
  specialization: string;
  experienceYears: number;
  registrationNumber: string;
  registrationCouncil: string;
  consultationFee: number;
  languages: string[];
  photoUrl: string;
  about: string;
  qualifications: {
    degree: string;
    institution: string;
    year: string;
  }[];
  services: {
    title: string;
    description: string;
    icon: string;
  }[];
}

export interface ClinicSettings {
  name: string;
  tagline: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  state: string;
  postalCode: string;
  phone: string;
  emergencyPhone: string;
  email: string;
  googleMapsUrl: string;
  googleMapsEmbedUrl: string;
  parkingInfo: string;
  consultationFee: number;
  notice: string;
  whatsappApiKey: string;
  whatsappPhoneNumberId: string;
  smsApiKey: string;
  smsSenderId: string;
  doctorPhoneNumber: string;
}

export interface AvailabilitySettings {
  workingDays: number[]; // 0=Sunday, 1=Monday, ..., 6=Saturday
  morningShift: {
    enabled: boolean;
    startTime: string; // "10:00"
    endTime: string;   // "13:00"
  };
  eveningShift: {
    enabled: boolean;
    startTime: string; // "17:00"
    endTime: string;   // "20:00"
  };
  slotDurationMinutes: number; // 20
  maxAppointmentsPerDay: number;
  holidays: {
    date: string; // "YYYY-MM-DD"
    reason: string;
  }[];
}

export type AppointmentStatus = 'PENDING' | 'CONFIRMED' | 'COMPLETED' | 'CANCELLED' | 'NO-SHOW';

export interface Appointment {
  appointment_id: string; // e.g. APT-2026-0001
  doctor_id: string;
  patient_id: string;
  patient_name: string;
  patient_phone: string;
  patient_email: string;
  patient_age: number;
  patient_gender: 'Male' | 'Female' | 'Other';
  patient_address: string;
  appointment_date: string; // "YYYY-MM-DD"
  appointment_time: string; // "10:20 AM"
  reason: string;
  status: AppointmentStatus;
  doctor_notes: string;
  created_at: string;
  updated_at: string;
  cancelled_at?: string;
  cancellation_reason?: string;
}

export interface Patient {
  patient_id: string;
  name: string;
  phone: string;
  email: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  address: string;
  created_at: string;
  updated_at: string;
}

export interface NotificationLog {
  id: string;
  type: 'WhatsApp' | 'SMS';
  recipient: 'Doctor' | 'Patient';
  recipient_phone: string;
  appointment_id: string;
  message: string;
  timestamp: string;
  status: 'Sent' | 'Failed' | 'Fallback Sent';
  error?: string;
}

export interface AdminUser {
  id: string;
  email: string;
  phone: string;
  fullName: string;
  passwordHash: string;
  salt: string;
  createdAt: string;
}

export interface DatabaseSchema {
  isDemoData: boolean;
  admin: AdminUser;
  doctor: DoctorProfile;
  clinic: ClinicSettings;
  availability: AvailabilitySettings;
  appointments: Appointment[];
  patients: Patient[];
  notifications: NotificationLog[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'clinic-db.json');

// In-memory atomic state
let dbData: DatabaseSchema;

export function hashPassword(password: string, salt: string): string {
  return crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
}

function getSeedData(): DatabaseSchema {
  const salt = crypto.randomBytes(16).toString('hex');
  const defaultPassword = 'Doctor@2026'; // Standard safe demo admin credential
  const passwordHash = hashPassword(defaultPassword, salt);

  const today = new Date();
  const formatDate = (offsetDays: number) => {
    const d = new Date();
    d.setDate(today.getDate() + offsetDays);
    return d.toISOString().split('T')[0];
  };

  const seedDoctor: DoctorProfile = {
    id: 'DOC-001',
    name: 'Dr. Jagadish Das',
    degrees: 'MBBS',
    specialization: 'General Medicine / Consultant Physician',
    experienceYears: 14,
    registrationNumber: 'WBMC-64821',
    registrationCouncil: 'West Bengal Medical Council',
    consultationFee: 500,
    languages: ['English', 'Bengali', 'Hindi'],
    photoUrl: '/doctor-avatar.svg',
    about: 'Dr. Jagadish Das (MBBS) is a trusted General Physician with over 14 years of comprehensive clinical practice. He is dedicated to compassionate, evidence-based primary healthcare, diagnosis and treatment of acute infectious illnesses, preventive care, and ongoing management of lifestyle and chronic health conditions. Known for his patient-first methodology, Dr. Das takes the time to listen and provide personalized treatment plans.',
    qualifications: [
      {
        degree: 'MBBS (Bachelor of Medicine, Bachelor of Surgery)',
        institution: 'Calcutta National Medical College & Hospital',
        year: '2012'
      },
      {
        degree: 'Senior Clinical Residency (Internal Medicine)',
        institution: 'District General Hospital',
        year: '2014'
      },
      {
        degree: 'Certificate in Diabetes & Metabolic Care',
        institution: 'Medical Association Academy',
        year: '2018'
      }
    ],
    services: [
      {
        title: 'Primary Health Consultation',
        description: 'Comprehensive general physical examinations, diagnostic evaluations, and medical management for children, adults, and elderly.',
        icon: 'Stethoscope'
      },
      {
        title: 'Fever & Infection Management',
        description: 'Timely evaluation and evidence-backed therapy for seasonal flu, viral infections, malaria, dengue, typhoid, and respiratory illnesses.',
        icon: 'Thermometer'
      },
      {
        title: 'Hypertension & Cardiac Screening',
        description: 'Regular blood pressure monitoring, cardiovascular risk stratification, lipid profiling, and medication adjustments.',
        icon: 'Activity'
      },
      {
        title: 'Diabetes & Metabolic Care',
        description: 'Blood glucose monitoring, dietary counseling, oral hypoglycemic medication management, and preventive screenings.',
        icon: 'HeartPulse'
      },
      {
        title: 'Preventive Health Checkups',
        description: 'Routine wellness assessments, essential pathology lab reviews, immunization guidance, and annual health screenings.',
        icon: 'ShieldCheck'
      },
      {
        title: 'Prescription & Ongoing Follow-ups',
        description: 'Thorough prescription reviews, chronic ailment monitoring, drug interaction checks, and medical follow-up consultations.',
        icon: 'FileText'
      }
    ]
  };

  const seedClinic: ClinicSettings = {
    name: 'Arogya Health & Consultation Clinic',
    tagline: 'Compassionate, Reliable Primary Healthcare for the Whole Family',
    addressLine1: 'Suite 204, 2nd Floor, Care Health Complex',
    addressLine2: 'Opposite Central Railway Station, Station Road',
    city: 'Kolkata',
    state: 'West Bengal',
    postalCode: '700001',
    phone: '+91 98765 43210',
    emergencyPhone: '+91 98765 43211',
    email: 'care@drjagadishdas.com',
    googleMapsUrl: 'https://maps.google.com/?q=22.5726,88.3639',
    googleMapsEmbedUrl: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d117925.21689650207!2d88.26495048220556!3d22.53556493690184!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39f882db4908f667%3A0x43e330e68f6c2cbc!2sKolkata%2C%20West%20Bengal!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin',
    parkingInfo: 'Dedicated basement parking available for 2-wheelers and 4-wheelers. Ramp access and elevator available for wheelchair patients.',
    consultationFee: 500,
    notice: 'Please bring your previous prescriptions, diagnostic test reports, and government ID card for your appointment.',
    whatsappApiKey: process.env.WHATSAPP_API_KEY || '',
    whatsappPhoneNumberId: process.env.WHATSAPP_PHONE_NUMBER_ID || '',
    smsApiKey: process.env.SMS_API_KEY || '',
    smsSenderId: process.env.SMS_SENDER_ID || 'DRJDAS',
    doctorPhoneNumber: process.env.DOCTOR_PHONE_NUMBER || '+919876543210'
  };

  const seedAvailability: AvailabilitySettings = {
    workingDays: [1, 2, 3, 4, 5, 6], // Monday through Saturday
    morningShift: {
      enabled: true,
      startTime: '10:00',
      endTime: '13:00'
    },
    eveningShift: {
      enabled: true,
      startTime: '17:00',
      endTime: '20:00'
    },
    slotDurationMinutes: 20,
    maxAppointmentsPerDay: 25,
    holidays: [
      {
        date: formatDate(14),
        reason: 'National Holiday'
      }
    ]
  };

  const seedPatients: Patient[] = [
    {
      patient_id: 'PAT-101',
      name: 'Ramesh Mukherjee',
      phone: '+91 98301 23456',
      email: 'ramesh.mukherjee@example.com',
      age: 48,
      gender: 'Male',
      address: 'Flat 4B, Green View Apts, Kolkata',
      created_at: new Date(Date.now() - 86400000 * 20).toISOString(),
      updated_at: new Date(Date.now() - 86400000 * 2).toISOString()
    },
    {
      patient_id: 'PAT-102',
      name: 'Priyanka Sharma',
      phone: '+91 98312 98765',
      email: 'priyanka.s@example.com',
      age: 32,
      gender: 'Female',
      address: '22 Park Lane, Salt Lake City',
      created_at: new Date(Date.now() - 86400000 * 12).toISOString(),
      updated_at: new Date(Date.now() - 86400000 * 5).toISOString()
    },
    {
      patient_id: 'PAT-103',
      name: 'Anirban Sen',
      phone: '+91 98320 11223',
      email: 'anirban.sen@example.com',
      age: 56,
      gender: 'Male',
      address: '15 Lake Terrace, Kolkata',
      created_at: new Date(Date.now() - 86400000 * 8).toISOString(),
      updated_at: new Date(Date.now() - 86400000 * 1).toISOString()
    },
    {
      patient_id: 'PAT-104',
      name: 'Sunita Ghosh',
      phone: '+91 98305 67890',
      email: 'sunita.ghosh@example.com',
      age: 27,
      gender: 'Female',
      address: 'Garia Main Road, Kolkata',
      created_at: new Date(Date.now() - 86400000 * 3).toISOString(),
      updated_at: new Date(Date.now() - 86400000 * 3).toISOString()
    },
    {
      patient_id: 'PAT-105',
      name: 'Amitava Roy',
      phone: '+91 98309 45678',
      email: 'amitava.roy@example.com',
      age: 62,
      gender: 'Male',
      address: 'Behala Chowrasta, Kolkata',
      created_at: new Date(Date.now() - 86400000 * 1).toISOString(),
      updated_at: new Date().toISOString()
    }
  ];

  const seedAppointments: Appointment[] = [
    {
      appointment_id: 'APT-2026-0001',
      doctor_id: 'DOC-001',
      patient_id: 'PAT-101',
      patient_name: 'Ramesh Mukherjee',
      patient_phone: '+91 98301 23456',
      patient_email: 'ramesh.mukherjee@example.com',
      patient_age: 48,
      patient_gender: 'Male',
      patient_address: 'Flat 4B, Green View Apts, Kolkata',
      appointment_date: formatDate(0),
      appointment_time: '10:00 AM',
      reason: 'Routine blood pressure review and prescription renewal',
      status: 'CONFIRMED',
      doctor_notes: 'Patient advised to bring previous 3 months BP chart.',
      created_at: new Date(Date.now() - 86400000 * 2).toISOString(),
      updated_at: new Date(Date.now() - 86400000 * 2).toISOString()
    },
    {
      appointment_id: 'APT-2026-0002',
      doctor_id: 'DOC-001',
      patient_id: 'PAT-102',
      patient_name: 'Priyanka Sharma',
      patient_phone: '+91 98312 98765',
      patient_email: 'priyanka.s@example.com',
      patient_age: 32,
      patient_gender: 'Female',
      patient_address: '22 Park Lane, Salt Lake City',
      appointment_date: formatDate(0),
      appointment_time: '10:40 AM',
      reason: 'Persistent dry cough and mild fever for 4 days',
      status: 'PENDING',
      doctor_notes: '',
      created_at: new Date(Date.now() - 86400000 * 1).toISOString(),
      updated_at: new Date(Date.now() - 86400000 * 1).toISOString()
    },
    {
      appointment_id: 'APT-2026-0003',
      doctor_id: 'DOC-001',
      patient_id: 'PAT-103',
      patient_name: 'Anirban Sen',
      patient_phone: '+91 98320 11223',
      patient_email: 'anirban.sen@example.com',
      patient_age: 56,
      patient_gender: 'Male',
      patient_address: '15 Lake Terrace, Kolkata',
      appointment_date: formatDate(0),
      appointment_time: '05:20 PM',
      reason: 'Fasting blood sugar follow-up and HbA1c evaluation',
      status: 'CONFIRMED',
      doctor_notes: 'HbA1c was 7.4% on last visit. Need to evaluate dietary compliance.',
      created_at: new Date(Date.now() - 86400000 * 1).toISOString(),
      updated_at: new Date(Date.now() - 86400000 * 1).toISOString()
    },
    {
      appointment_id: 'APT-2026-0004',
      doctor_id: 'DOC-001',
      patient_id: 'PAT-104',
      patient_name: 'Sunita Ghosh',
      patient_phone: '+91 98305 67890',
      patient_email: 'sunita.ghosh@example.com',
      patient_age: 27,
      patient_gender: 'Female',
      patient_address: 'Garia Main Road, Kolkata',
      appointment_date: formatDate(1),
      appointment_time: '11:20 AM',
      reason: 'Severe migraine headache and nausea',
      status: 'CONFIRMED',
      doctor_notes: '',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    },
    {
      appointment_id: 'APT-2026-0005',
      doctor_id: 'DOC-001',
      patient_id: 'PAT-105',
      patient_name: 'Amitava Roy',
      patient_phone: '+91 98309 45678',
      patient_email: 'amitava.roy@example.com',
      patient_age: 62,
      patient_gender: 'Male',
      patient_address: 'Behala Chowrasta, Kolkata',
      appointment_date: formatDate(2),
      appointment_time: '06:00 PM',
      reason: 'Joint stiffness and fatigue consultation',
      status: 'CONFIRMED',
      doctor_notes: '',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    },
    {
      appointment_id: 'APT-2026-0006',
      doctor_id: 'DOC-001',
      patient_id: 'PAT-101',
      patient_name: 'Ramesh Mukherjee',
      patient_phone: '+91 98301 23456',
      patient_email: 'ramesh.mukherjee@example.com',
      patient_age: 48,
      patient_gender: 'Male',
      patient_address: 'Flat 4B, Green View Apts, Kolkata',
      appointment_date: formatDate(-5),
      appointment_time: '11:00 AM',
      reason: 'Seasonal viral flu and body ache',
      status: 'COMPLETED',
      doctor_notes: 'Prescribed Paracetamol 650mg SOS and Steam inhalation. Advised plenty of fluids.',
      created_at: new Date(Date.now() - 86400000 * 7).toISOString(),
      updated_at: new Date(Date.now() - 86400000 * 5).toISOString()
    }
  ];

  const seedNotifications: NotificationLog[] = [
    {
      id: 'NOTIF-001',
      type: 'WhatsApp',
      recipient: 'Doctor',
      recipient_phone: '+919876543210',
      appointment_id: 'APT-2026-0004',
      message: 'New Appointment Received\nDoctor: Dr. Jagadish Das\nPatient: Sunita Ghosh\nMobile: +91 98305 67890\nDate: ' + formatDate(1) + '\nTime: 11:20 AM\nAppointment ID: APT-2026-0004\nReason: Severe migraine headache and nausea',
      timestamp: new Date().toISOString(),
      status: 'Sent'
    },
    {
      id: 'NOTIF-002',
      type: 'WhatsApp',
      recipient: 'Patient',
      recipient_phone: '+91 98305 67890',
      appointment_id: 'APT-2026-0004',
      message: 'Your appointment with Dr. Jagadish Das has been successfully booked.\n\nAppointment ID: APT-2026-0004\nDate: ' + formatDate(1) + '\nTime: 11:20 AM\n\nPlease arrive 10–15 minutes before your appointment.',
      timestamp: new Date().toISOString(),
      status: 'Sent'
    },
    {
      id: 'NOTIF-003',
      type: 'WhatsApp',
      recipient: 'Doctor',
      recipient_phone: '+919876543210',
      appointment_id: 'APT-2026-0005',
      message: 'New Appointment Received\nDoctor: Dr. Jagadish Das\nPatient: Amitava Roy\nMobile: +91 98309 45678\nDate: ' + formatDate(2) + '\nTime: 06:00 PM\nAppointment ID: APT-2026-0005\nReason: Joint stiffness and fatigue consultation',
      timestamp: new Date().toISOString(),
      status: 'Sent'
    }
  ];

  return {
    isDemoData: true,
    admin: {
      id: 'ADM-001',
      email: 'doctor@drjagadishdas.com',
      phone: '+919876543210',
      fullName: 'Dr. Jagadish Das',
      passwordHash,
      salt,
      createdAt: new Date().toISOString()
    },
    doctor: seedDoctor,
    clinic: seedClinic,
    availability: seedAvailability,
    appointments: seedAppointments,
    patients: seedPatients,
    notifications: seedNotifications
  };
}

export function initDatabase(): DatabaseSchema {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }

    if (fs.existsSync(DATA_FILE)) {
      const raw = fs.readFileSync(DATA_FILE, 'utf-8');
      dbData = JSON.parse(raw);
      return dbData;
    }
  } catch (err) {
    console.warn('Could not read existing database file, initializing fresh data:', err);
  }

  dbData = getSeedData();
  saveDatabase();
  return dbData;
}

export function getDatabase(): DatabaseSchema {
  if (!dbData) {
    return initDatabase();
  }
  return dbData;
}

export function saveDatabase(): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DATA_FILE, JSON.stringify(dbData, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to save database file:', err);
  }
}

export function resetDemoData(): DatabaseSchema {
  dbData = getSeedData();
  saveDatabase();
  return dbData;
}

// Atomic helper to book appointment with race-condition prevention
export function atomicBookAppointment(booking: {
  date: string;
  time: string;
  name: string;
  phone: string;
  email?: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  address?: string;
  reason: string;
}): { success: boolean; appointment?: Appointment; error?: string } {
  const db = getDatabase();

  // 1. Validate slot availability (not booked and not cancelled)
  const existing = db.appointments.find(
    (a) =>
      a.appointment_date === booking.date &&
      a.appointment_time === booking.time &&
      a.status !== 'CANCELLED'
  );

  if (existing) {
    return {
      success: false,
      error: 'Sorry, this time slot has just been booked. Please select another time.'
    };
  }

  // 2. Generate unique Appointment ID (e.g. APT-2026-0007)
  const currentYear = new Date().getFullYear();
  const nextSeq = db.appointments.length + 1;
  const appointment_id = `APT-${currentYear}-${String(nextSeq).padStart(4, '0')}`;

  // 3. Find or create patient record
  let patient = db.patients.find(
    (p) => p.phone.replace(/\D/g, '') === booking.phone.replace(/\D/g, '')
  );

  if (!patient) {
    const patient_id = `PAT-${100 + db.patients.length + 1}`;
    patient = {
      patient_id,
      name: booking.name.trim(),
      phone: booking.phone.trim(),
      email: (booking.email || '').trim(),
      age: Number(booking.age),
      gender: booking.gender,
      address: (booking.address || '').trim(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    db.patients.push(patient);
  } else {
    // Update contact info if newer
    patient.name = booking.name.trim();
    if (booking.email) patient.email = booking.email.trim();
    if (booking.address) patient.address = booking.address.trim();
    patient.updated_at = new Date().toISOString();
  }

  // 4. Create appointment
  const newAppointment: Appointment = {
    appointment_id,
    doctor_id: db.doctor.id,
    patient_id: patient.patient_id,
    patient_name: booking.name.trim(),
    patient_phone: booking.phone.trim(),
    patient_email: (booking.email || '').trim(),
    patient_age: Number(booking.age),
    patient_gender: booking.gender,
    patient_address: (booking.address || '').trim(),
    appointment_date: booking.date,
    appointment_time: booking.time,
    reason: booking.reason.trim() || 'General Consultation',
    status: 'CONFIRMED',
    doctor_notes: '',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  };

  db.appointments.unshift(newAppointment);
  saveDatabase();

  return {
    success: true,
    appointment: newAppointment
  };
}
