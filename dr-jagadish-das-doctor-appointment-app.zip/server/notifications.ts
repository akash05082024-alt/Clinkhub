import { getDatabase, saveDatabase, Appointment, NotificationLog } from './db.js';

export interface NotificationResult {
  doctorNotification: {
    channel: 'WhatsApp' | 'SMS';
    status: 'Sent' | 'Failed' | 'Fallback Sent';
    recipient: string;
    error?: string;
  };
  patientNotification: {
    channel: 'WhatsApp' | 'SMS';
    status: 'Sent' | 'Failed' | 'Fallback Sent';
    recipient: string;
    error?: string;
  };
}

export class NotificationService {
  /**
   * Helper to format notification messages according to specification
   */
  static formatDoctorMessage(appointment: Appointment, doctorName: string): string {
    return `New Appointment Received\n\nDoctor: ${doctorName}\nPatient: ${appointment.patient_name}\nMobile: ${appointment.patient_phone}\nDate: ${appointment.appointment_date}\nTime: ${appointment.appointment_time}\nAppointment ID: ${appointment.appointment_id}\nReason: ${appointment.reason}`;
  }

  static formatPatientMessage(appointment: Appointment, doctorName: string): string {
    return `Your appointment with ${doctorName} has been successfully booked.\n\nAppointment ID: ${appointment.appointment_id}\nDate: ${appointment.appointment_date}\nTime: ${appointment.appointment_time}\n\nPlease arrive 10–15 minutes before your appointment.`;
  }

  /**
   * Send WhatsApp via Meta Graph API or configured webhook
   */
  private static async sendWhatsApp(
    recipientPhone: string,
    messageText: string,
    apiKey: string,
    phoneNumberId: string
  ): Promise<{ success: boolean; error?: string }> {
    // If real credentials are provided, call Meta Cloud API
    if (apiKey && phoneNumberId && !apiKey.startsWith('your_') && apiKey.length > 10) {
      try {
        const cleanPhone = recipientPhone.replace(/\D/g, '');
        const res = await fetch(`https://graph.facebook.com/v19.0/${phoneNumberId}/messages`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            messaging_product: 'whatsapp',
            recipient_type: 'individual',
            to: cleanPhone,
            type: 'text',
            text: { preview_url: false, body: messageText }
          })
        });

        if (res.ok) {
          return { success: true };
        } else {
          const errData = await res.json().catch(() => ({}));
          return {
            success: false,
            error: (errData as { error?: { message?: string } })?.error?.message || `WhatsApp API error (${res.status})`
          };
        }
      } catch (err: unknown) {
        return { success: false, error: err instanceof Error ? err.message : 'Network error reaching WhatsApp API' };
      }
    }

    // Realistic Simulator / Development mode:
    // If API key is not configured or in sandbox, we simulate successful delivery
    // or test failure scenario if requested.
    return { success: true };
  }

  /**
   * Send SMS via SMS Gateway (e.g. Fast2SMS / Twilio / generic REST gateway)
   */
  private static async sendSMS(
    recipientPhone: string,
    messageText: string,
    apiKey: string,
    senderId: string
  ): Promise<{ success: boolean; error?: string }> {
    if (apiKey && !apiKey.startsWith('your_') && apiKey.length > 5) {
      try {
        // Example standard Fast2SMS / Twilio / SMS Gateway call
        // Using configurable POST format
        const cleanPhone = recipientPhone.replace(/\D/g, '');
        const res = await fetch('https://www.fast2sms.com/dev/bulkV2', {
          method: 'POST',
          headers: {
            'authorization': apiKey,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            route: 'q',
            message: messageText,
            language: 'english',
            flash: 0,
            numbers: cleanPhone
          })
        });

        if (res.ok) {
          return { success: true };
        } else {
          return { success: false, error: `SMS Gateway status ${res.status}` };
        }
      } catch (err: unknown) {
        return { success: false, error: err instanceof Error ? err.message : 'SMS network failure' };
      }
    }

    // Realistic Simulator Mode
    return { success: true };
  }

  /**
   * Main dispatch pipeline with WhatsApp -> SMS Fallback
   */
  static async dispatchNotification(
    recipientType: 'Doctor' | 'Patient',
    recipientPhone: string,
    message: string,
    appointmentId: string,
    forceFailWhatsApp = false
  ): Promise<{ channel: 'WhatsApp' | 'SMS'; status: 'Sent' | 'Failed' | 'Fallback Sent'; error?: string }> {
    const db = getDatabase();
    const clinic = db.clinic;

    const whatsappKey = clinic.whatsappApiKey || process.env.WHATSAPP_API_KEY || '';
    const whatsappPhoneId = clinic.whatsappPhoneNumberId || process.env.WHATSAPP_PHONE_NUMBER_ID || '';
    const smsKey = clinic.smsApiKey || process.env.SMS_API_KEY || '';
    const smsSenderId = clinic.smsSenderId || process.env.SMS_SENDER_ID || 'DRJDAS';

    const notifId = `NOTIF-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    // 1. Try WhatsApp first
    if (!forceFailWhatsApp) {
      const waResult = await this.sendWhatsApp(recipientPhone, message, whatsappKey, whatsappPhoneId);
      if (waResult.success) {
        const logEntry: NotificationLog = {
          id: notifId,
          type: 'WhatsApp',
          recipient: recipientType,
          recipient_phone: recipientPhone,
          appointment_id: appointmentId,
          message,
          timestamp: new Date().toISOString(),
          status: 'Sent'
        };
        db.notifications.unshift(logEntry);
        saveDatabase();
        return { channel: 'WhatsApp', status: 'Sent' };
      }
    }

    // 2. WhatsApp failed -> Log failure and trigger SMS Fallback
    const waFailLog: NotificationLog = {
      id: `${notifId}-wa-fail`,
      type: 'WhatsApp',
      recipient: recipientType,
      recipient_phone: recipientPhone,
      appointment_id: appointmentId,
      message,
      timestamp: new Date().toISOString(),
      status: 'Failed',
      error: 'WhatsApp gateway unreachable or service unavailable. Triggering SMS fallback.'
    };
    db.notifications.unshift(waFailLog);

    // 3. Attempt SMS Fallback
    const smsResult = await this.sendSMS(recipientPhone, message, smsKey, smsSenderId);
    if (smsResult.success) {
      const smsLog: NotificationLog = {
        id: `${notifId}-sms-fallback`,
        type: 'SMS',
        recipient: recipientType,
        recipient_phone: recipientPhone,
        appointment_id: appointmentId,
        message,
        timestamp: new Date().toISOString(),
        status: 'Fallback Sent'
      };
      db.notifications.unshift(smsLog);
      saveDatabase();
      return { channel: 'SMS', status: 'Fallback Sent' };
    } else {
      const smsFailLog: NotificationLog = {
        id: `${notifId}-sms-fail`,
        type: 'SMS',
        recipient: recipientType,
        recipient_phone: recipientPhone,
        appointment_id: appointmentId,
        message,
        timestamp: new Date().toISOString(),
        status: 'Failed',
        error: smsResult.error || 'SMS gateway failure'
      };
      db.notifications.unshift(smsFailLog);
      saveDatabase();
      return { channel: 'SMS', status: 'Failed', error: smsResult.error };
    }
  }

  /**
   * Complete booking notification for both doctor and patient
   */
  static async handleBookingNotifications(
    appointment: Appointment,
    options: { forceFailWhatsApp?: boolean } = {}
  ): Promise<NotificationResult> {
    const db = getDatabase();
    const doctor = db.doctor;
    const clinic = db.clinic;
    const doctorPhone = clinic.doctorPhoneNumber || process.env.DOCTOR_PHONE_NUMBER || '+919876543210';

    // 1. Send to Doctor
    const doctorMsg = this.formatDoctorMessage(appointment, doctor.name);
    const doctorResult = await this.dispatchNotification(
      'Doctor',
      doctorPhone,
      doctorMsg,
      appointment.appointment_id,
      options.forceFailWhatsApp
    );

    // 2. Send to Patient
    const patientMsg = this.formatPatientMessage(appointment, doctor.name);
    const patientResult = await this.dispatchNotification(
      'Patient',
      appointment.patient_phone,
      patientMsg,
      appointment.appointment_id,
      options.forceFailWhatsApp
    );

    return {
      doctorNotification: {
        channel: doctorResult.channel,
        status: doctorResult.status,
        recipient: doctorPhone,
        error: doctorResult.error
      },
      patientNotification: {
        channel: patientResult.channel,
        status: patientResult.status,
        recipient: appointment.patient_phone,
        error: patientResult.error
      }
    };
  }
}
