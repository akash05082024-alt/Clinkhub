import { Router, Request, Response } from 'express';
import {
  getDatabase,
  saveDatabase,
  atomicBookAppointment,
  hashPassword,
  resetDemoData,
  AppointmentStatus,
  Appointment
} from './db.js';
import { NotificationService } from './notifications.js';
import { generateToken, requireAdminAuth, AuthenticatedRequest } from './auth.js';

export const apiRouter = Router();

// ==========================================
// 1. PUBLIC ENDPOINTS
// ==========================================

/**
 * Public clinic & doctor info
 */
apiRouter.get('/public/clinic-info', (_req: Request, res: Response) => {
  const db = getDatabase();
  res.json({
    doctor: {
      name: db.doctor.name,
      degrees: db.doctor.degrees,
      specialization: db.doctor.specialization,
      experienceYears: db.doctor.experienceYears,
      registrationNumber: db.doctor.registrationNumber,
      registrationCouncil: db.doctor.registrationCouncil,
      consultationFee: db.doctor.consultationFee,
      languages: db.doctor.languages,
      photoUrl: db.doctor.photoUrl,
      about: db.doctor.about,
      qualifications: db.doctor.qualifications,
      services: db.doctor.services
    },
    clinic: {
      name: db.clinic.name,
      tagline: db.clinic.tagline,
      addressLine1: db.clinic.addressLine1,
      addressLine2: db.clinic.addressLine2,
      city: db.clinic.city,
      state: db.clinic.state,
      postalCode: db.clinic.postalCode,
      phone: db.clinic.phone,
      emergencyPhone: db.clinic.emergencyPhone,
      email: db.clinic.email,
      googleMapsUrl: db.clinic.googleMapsUrl,
      parkingInfo: db.clinic.parkingInfo,
      consultationFee: db.clinic.consultationFee,
      notice: db.clinic.notice
    },
    availability: {
      workingDays: db.availability.workingDays,
      morningShift: db.availability.morningShift,
      eveningShift: db.availability.eveningShift,
      slotDurationMinutes: db.availability.slotDurationMinutes,
      holidays: db.availability.holidays
    }
  });
});

/**
 * Helper to generate 12-hour formatted time slot array (e.g. "10:00 AM", "10:20 AM")
 */
function generateTimeSlots(startTime: string, endTime: string, stepMinutes: number): string[] {
  const slots: string[] = [];
  const [startH, startM] = startTime.split(':').map(Number);
  const [endH, endM] = endTime.split(':').map(Number);

  let current = startH * 60 + startM;
  const end = endH * 60 + endM;

  while (current < end) {
    const hours24 = Math.floor(current / 60);
    const mins = current % 60;
    const period = hours24 >= 12 ? 'PM' : 'AM';
    const hours12 = hours24 % 12 === 0 ? 12 : hours24 % 12;
    const formatted = `${String(hours12).padStart(2, '0')}:${String(mins).padStart(2, '0')} ${period}`;
    slots.push(formatted);
    current += stepMinutes;
  }

  return slots;
}

/**
 * Public available slots lookup
 */
apiRouter.get('/appointments/available-slots', (req: Request, res: Response) => {
  const dateStr = req.query.date as string;
  if (!dateStr || !/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
    res.status(400).json({ error: 'Valid date in YYYY-MM-DD format is required.' });
    return;
  }

  const db = getDatabase();
  const targetDate = new Date(`${dateStr}T00:00:00`);
  const dayOfWeek = targetDate.getDay();

  // Check if clinic operates on this weekday
  if (!db.availability.workingDays.includes(dayOfWeek)) {
    res.json({
      date: dateStr,
      isOpen: false,
      reason: 'The clinic is closed on this day of the week.',
      slots: []
    });
    return;
  }

  // Check if date is designated holiday
  const holiday = db.availability.holidays.find((h) => h.date === dateStr);
  if (holiday) {
    res.json({
      date: dateStr,
      isOpen: false,
      reason: `Clinic closed for holiday: ${holiday.reason}`,
      slots: []
    });
    return;
  }

  const step = db.availability.slotDurationMinutes || 20;
  const morningSlots = db.availability.morningShift.enabled
    ? generateTimeSlots(db.availability.morningShift.startTime, db.availability.morningShift.endTime, step)
    : [];
  const eveningSlots = db.availability.eveningShift.enabled
    ? generateTimeSlots(db.availability.eveningShift.endTime ? db.availability.eveningShift.startTime : '17:00', db.availability.eveningShift.endTime, step)
    : [];

  const allCandidateSlots = [
    ...morningSlots.map((time) => ({ time, shift: 'Morning' as const })),
    ...eveningSlots.map((time) => ({ time, shift: 'Evening' as const }))
  ];

  // Check booked appointments for that date (excluding CANCELLED)
  const bookedTimes = new Set(
    db.appointments
      .filter((a) => a.appointment_date === dateStr && a.status !== 'CANCELLED')
      .map((a) => a.appointment_time)
  );

  // If date is today, disable past time slots
  const now = new Date();
  const isToday = dateStr === now.toISOString().split('T')[0];
  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  const slotsWithStatus = allCandidateSlots.map((s) => {
    // Parse slot time to minutes
    const parts = s.time.match(/(\d+):(\d+)\s*(AM|PM)/i);
    let slotMinutes = 0;
    if (parts) {
      let h = parseInt(parts[1], 10);
      const m = parseInt(parts[2], 10);
      const isPM = parts[3].toUpperCase() === 'PM';
      if (isPM && h !== 12) h += 12;
      if (!isPM && h === 12) h = 0;
      slotMinutes = h * 60 + m;
    }

    const isPast = isToday && slotMinutes <= currentMinutes;
    const isBooked = bookedTimes.has(s.time);
    const available = !isBooked && !isPast;

    return {
      time: s.time,
      shift: s.shift,
      available,
      status: isBooked ? 'booked' : isPast ? 'past' : 'available'
    };
  });

  res.json({
    date: dateStr,
    isOpen: true,
    totalSlots: slotsWithStatus.length,
    availableSlotsCount: slotsWithStatus.filter((s) => s.available).length,
    slots: slotsWithStatus
  });
});

/**
 * Public appointment booking (Atomic slot lock & validation)
 */
apiRouter.post('/appointments/book', async (req: Request, res: Response) => {
  const { date, time, name, phone, email, age, gender, address, reason } = req.body;

  // Validation
  if (!date || !time || !name || !phone || !age || !gender) {
    res.status(400).json({ error: 'Please provide all required fields: date, time, name, phone, age, gender.' });
    return;
  }

  // Validate phone format (at least 10 digits)
  const cleanPhone = phone.replace(/\D/g, '');
  if (cleanPhone.length < 10) {
    res.status(400).json({ error: 'Please enter a valid mobile number (at least 10 digits).' });
    return;
  }

  // Atomic reservation
  const result = atomicBookAppointment({
    date,
    time,
    name,
    phone,
    email,
    age: parseInt(age, 10),
    gender,
    address,
    reason: reason || 'General Healthcare Consultation'
  });

  if (!result.success || !result.appointment) {
    res.status(409).json({ error: result.error || 'Appointment could not be booked. Please select another time slot.' });
    return;
  }

  // Dispatch background notification (WhatsApp preferred, SMS fallback)
  try {
    await NotificationService.handleBookingNotifications(result.appointment);
  } catch (err) {
    console.error('Notification dispatch notice:', err);
    // Booking itself still succeeds even if notification gateway has an issue
  }

  res.status(201).json({
    message: 'Appointment booked successfully.',
    appointment: result.appointment
  });
});

/**
 * Public get appointment details by ID
 */
apiRouter.get('/appointments/:id', (req: Request, res: Response) => {
  const db = getDatabase();
  const apt = db.appointments.find((a) => a.appointment_id.toUpperCase() === req.params.id.toUpperCase());

  if (!apt) {
    res.status(404).json({ error: 'Appointment not found. Please verify your Appointment ID.' });
    return;
  }

  res.json({
    appointment: apt,
    doctor: {
      name: db.doctor.name,
      degrees: db.doctor.degrees,
      specialization: db.doctor.specialization,
      consultationFee: db.doctor.consultationFee
    },
    clinic: {
      name: db.clinic.name,
      address: `${db.clinic.addressLine1}, ${db.clinic.addressLine2}, ${db.clinic.city} - ${db.clinic.postalCode}`,
      phone: db.clinic.phone,
      googleMapsUrl: db.clinic.googleMapsUrl
    }
  });
});

/**
 * Public / patient cancel appointment
 */
apiRouter.post('/appointments/:id/cancel', (req: Request, res: Response) => {
  const db = getDatabase();
  const apt = db.appointments.find((a) => a.appointment_id.toUpperCase() === req.params.id.toUpperCase());

  if (!apt) {
    res.status(404).json({ error: 'Appointment not found.' });
    return;
  }

  if (apt.status === 'CANCELLED') {
    res.status(400).json({ error: 'This appointment is already cancelled.' });
    return;
  }

  apt.status = 'CANCELLED';
  apt.cancelled_at = new Date().toISOString();
  apt.cancellation_reason = req.body.reason || 'Cancelled by patient';
  apt.updated_at = new Date().toISOString();
  saveDatabase();

  res.json({ message: 'Appointment has been cancelled successfully.', appointment: apt });
});

// ==========================================
// 2. ADMIN AUTH ENDPOINTS
// ==========================================

apiRouter.post('/admin/login', (req: Request, res: Response) => {
  const { identifier, password, rememberMe } = req.body;

  if (!identifier || !password) {
    res.status(400).json({ error: 'Please enter your email or phone and password.' });
    return;
  }

  const db = getDatabase();
  const admin = db.admin;

  const cleanInput = identifier.trim().toLowerCase();
  const cleanAdminPhone = admin.phone.replace(/\D/g, '');
  const cleanInputPhone = identifier.replace(/\D/g, '');

  const isEmailMatch = cleanInput === admin.email.toLowerCase();
  const isPhoneMatch = cleanInputPhone && cleanInputPhone === cleanAdminPhone;

  if (!isEmailMatch && !isPhoneMatch) {
    res.status(401).json({ error: 'Invalid email/phone or password.' });
    return;
  }

  const testHash = hashPassword(password, admin.salt);
  if (testHash !== admin.passwordHash) {
    res.status(401).json({ error: 'Invalid email/phone or password.' });
    return;
  }

  const token = generateToken(admin.id, admin.email, admin.fullName, Boolean(rememberMe));

  res.json({
    token,
    user: {
      id: admin.id,
      email: admin.email,
      phone: admin.phone,
      fullName: admin.fullName
    }
  });
});

apiRouter.get('/admin/me', requireAdminAuth, (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  res.json({
    user: {
      id: db.admin.id,
      email: db.admin.email,
      phone: db.admin.phone,
      fullName: db.admin.fullName
    },
    isDemoData: db.isDemoData
  });
});

apiRouter.post('/admin/logout', requireAdminAuth, (_req: AuthenticatedRequest, res: Response) => {
  res.json({ message: 'Logged out successfully.' });
});

// ==========================================
// 3. ADMIN DASHBOARD & STATS
// ==========================================

apiRouter.get('/admin/dashboard-stats', requireAdminAuth, (_req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const todayStr = new Date().toISOString().split('T')[0];

  const todayAppointments = db.appointments.filter((a) => a.appointment_date === todayStr);
  const upcomingAppointments = db.appointments.filter(
    (a) => a.appointment_date >= todayStr && a.status !== 'CANCELLED' && a.status !== 'COMPLETED'
  );

  const total = db.appointments.length;
  const pending = db.appointments.filter((a) => a.status === 'PENDING').length;
  const confirmed = db.appointments.filter((a) => a.status === 'CONFIRMED').length;
  const completed = db.appointments.filter((a) => a.status === 'COMPLETED').length;
  const cancelled = db.appointments.filter((a) => a.status === 'CANCELLED').length;
  const noShow = db.appointments.filter((a) => a.status === 'NO-SHOW').length;

  // Unique today's patients
  const todayPatientIds = new Set(todayAppointments.map((a) => a.patient_id));

  // 7-day trend
  const trend: { date: string; label: string; count: number }[] = [];
  for (let i = -3; i <= 3; i++) {
    const d = new Date();
    d.setDate(d.getDate() + i);
    const dStr = d.toISOString().split('T')[0];
    const label = i === 0 ? 'Today' : d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
    const count = db.appointments.filter((a) => a.appointment_date === dStr && a.status !== 'CANCELLED').length;
    trend.push({ date: dStr, label, count });
  }

  res.json({
    todayCount: todayAppointments.length,
    upcomingCount: upcomingAppointments.length,
    totalCount: total,
    pendingCount: pending,
    confirmedCount: confirmed,
    completedCount: completed,
    cancelledCount: cancelled,
    noShowCount: noShow,
    todayPatientCount: todayPatientIds.size,
    trend,
    consultationFee: db.clinic.consultationFee,
    todayRevenueEstimate: todayAppointments.filter((a) => a.status === 'CONFIRMED' || a.status === 'COMPLETED').length * db.clinic.consultationFee
  });
});

// ==========================================
// 4. ADMIN APPOINTMENT MANAGEMENT
// ==========================================

apiRouter.get('/admin/appointments', requireAdminAuth, (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const { date, status, search } = req.query;

  let list = [...db.appointments];

  if (date && typeof date === 'string') {
    list = list.filter((a) => a.appointment_date === date);
  }

  if (status && typeof status === 'string' && status !== 'ALL') {
    list = list.filter((a) => a.status === status);
  }

  if (search && typeof search === 'string') {
    const q = search.toLowerCase().trim();
    list = list.filter(
      (a) =>
        a.patient_name.toLowerCase().includes(q) ||
        a.patient_phone.includes(q) ||
        a.appointment_id.toLowerCase().includes(q) ||
        a.reason.toLowerCase().includes(q)
    );
  }

  // Sort descending by date and time
  list.sort((a, b) => {
    if (a.appointment_date !== b.appointment_date) {
      return b.appointment_date.localeCompare(a.appointment_date);
    }
    return a.appointment_time.localeCompare(b.appointment_time);
  });

  res.json({ appointments: list, count: list.length });
});

apiRouter.post('/admin/appointments', requireAdminAuth, async (req: AuthenticatedRequest, res: Response) => {
  const { date, time, name, phone, email, age, gender, address, reason, doctorNotes } = req.body;

  if (!date || !time || !name || !phone || !age || !gender) {
    res.status(400).json({ error: 'Missing required appointment fields.' });
    return;
  }

  const result = atomicBookAppointment({
    date,
    time,
    name,
    phone,
    email,
    age: parseInt(age, 10),
    gender,
    address,
    reason: reason || 'Walk-in Consultation'
  });

  if (!result.success || !result.appointment) {
    res.status(409).json({ error: result.error });
    return;
  }

  if (doctorNotes) {
    result.appointment.doctor_notes = doctorNotes;
    saveDatabase();
  }

  // Trigger notifications
  try {
    await NotificationService.handleBookingNotifications(result.appointment);
  } catch (err) {
    console.error('Notification dispatch error:', err);
  }

  res.status(201).json({ appointment: result.appointment, message: 'Appointment created successfully.' });
});

apiRouter.patch('/admin/appointments/:id/status', requireAdminAuth, (req: AuthenticatedRequest, res: Response) => {
  const { status } = req.body;
  const allowed: AppointmentStatus[] = ['PENDING', 'CONFIRMED', 'COMPLETED', 'CANCELLED', 'NO-SHOW'];

  if (!allowed.includes(status)) {
    res.status(400).json({ error: 'Invalid appointment status.' });
    return;
  }

  const db = getDatabase();
  const apt = db.appointments.find((a) => a.appointment_id.toUpperCase() === req.params.id.toUpperCase());

  if (!apt) {
    res.status(404).json({ error: 'Appointment not found.' });
    return;
  }

  apt.status = status;
  apt.updated_at = new Date().toISOString();
  saveDatabase();

  res.json({ message: `Status updated to ${status}.`, appointment: apt });
});

apiRouter.patch('/admin/appointments/:id/reschedule', requireAdminAuth, (req: AuthenticatedRequest, res: Response) => {
  const { newDate, newTime } = req.body;

  if (!newDate || !newTime) {
    res.status(400).json({ error: 'Please provide new date and time.' });
    return;
  }

  const db = getDatabase();
  const apt = db.appointments.find((a) => a.appointment_id.toUpperCase() === req.params.id.toUpperCase());

  if (!apt) {
    res.status(404).json({ error: 'Appointment not found.' });
    return;
  }

  // Check if target slot is occupied by another appointment
  const conflict = db.appointments.find(
    (a) =>
      a.appointment_id !== apt.appointment_id &&
      a.appointment_date === newDate &&
      a.appointment_time === newTime &&
      a.status !== 'CANCELLED'
  );

  if (conflict) {
    res.status(409).json({ error: 'The selected slot is already booked for another patient.' });
    return;
  }

  apt.appointment_date = newDate;
  apt.appointment_time = newTime;
  apt.updated_at = new Date().toISOString();
  saveDatabase();

  // Send update notification
  NotificationService.dispatchNotification(
    'Patient',
    apt.patient_phone,
    `Your appointment with Dr. Jagadish Das has been rescheduled.\n\nNew Date: ${newDate}\nNew Time: ${newTime}\nAppointment ID: ${apt.appointment_id}`,
    apt.appointment_id
  ).catch(console.error);

  res.json({ message: 'Appointment rescheduled successfully.', appointment: apt });
});

apiRouter.patch('/admin/appointments/:id/notes', requireAdminAuth, (req: AuthenticatedRequest, res: Response) => {
  const { notes } = req.body;
  const db = getDatabase();
  const apt = db.appointments.find((a) => a.appointment_id.toUpperCase() === req.params.id.toUpperCase());

  if (!apt) {
    res.status(404).json({ error: 'Appointment not found.' });
    return;
  }

  apt.doctor_notes = notes || '';
  apt.updated_at = new Date().toISOString();
  saveDatabase();

  res.json({ message: 'Clinical notes saved successfully.', appointment: apt });
});

// ==========================================
// 5. ADMIN PATIENTS DIRECTORY
// ==========================================

apiRouter.get('/admin/patients', requireAdminAuth, (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const search = (req.query.search as string || '').toLowerCase().trim();

  let list = db.patients.map((p) => {
    const patientAppointments = db.appointments.filter((a) => a.patient_id === p.patient_id);
    const lastVisit = patientAppointments.sort((a, b) => b.appointment_date.localeCompare(a.appointment_date))[0];
    return {
      ...p,
      appointmentCount: patientAppointments.length,
      lastVisitDate: lastVisit?.appointment_date || 'N/A',
      latestStatus: lastVisit?.status || 'N/A'
    };
  });

  if (search) {
    list = list.filter((p) => p.name.toLowerCase().includes(search) || p.phone.includes(search) || p.email.toLowerCase().includes(search));
  }

  res.json({ patients: list });
});

apiRouter.get('/admin/patients/:id', requireAdminAuth, (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const patient = db.patients.find((p) => p.patient_id.toUpperCase() === req.params.id.toUpperCase());

  if (!patient) {
    res.status(404).json({ error: 'Patient not found.' });
    return;
  }

  const appointments = db.appointments
    .filter((a) => a.patient_id === patient.patient_id)
    .sort((a, b) => b.appointment_date.localeCompare(a.appointment_date));

  res.json({
    patient,
    appointments
  });
});

// ==========================================
// 6. AVAILABILITY & SHIFT MANAGEMENT
// ==========================================

apiRouter.get('/admin/availability', requireAdminAuth, (_req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  res.json({ availability: db.availability });
});

apiRouter.put('/admin/availability', requireAdminAuth, (req: AuthenticatedRequest, res: Response) => {
  const { workingDays, morningShift, eveningShift, slotDurationMinutes, maxAppointmentsPerDay, holidays } = req.body;

  const db = getDatabase();

  if (Array.isArray(workingDays)) db.availability.workingDays = workingDays;
  if (morningShift) db.availability.morningShift = morningShift;
  if (eveningShift) db.availability.eveningShift = eveningShift;
  if (slotDurationMinutes) db.availability.slotDurationMinutes = Number(slotDurationMinutes);
  if (maxAppointmentsPerDay) db.availability.maxAppointmentsPerDay = Number(maxAppointmentsPerDay);
  if (Array.isArray(holidays)) db.availability.holidays = holidays;

  saveDatabase();
  res.json({ message: 'Availability and timings updated successfully.', availability: db.availability });
});

// ==========================================
// 7. CLINIC & DOCTOR PROFILE SETTINGS
// ==========================================

apiRouter.get('/admin/settings', requireAdminAuth, (_req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  res.json({
    doctor: db.doctor,
    clinic: db.clinic,
    availability: db.availability
  });
});

apiRouter.put('/admin/settings', requireAdminAuth, (req: AuthenticatedRequest, res: Response) => {
  const { doctor, clinic } = req.body;
  const db = getDatabase();

  if (doctor) {
    db.doctor = { ...db.doctor, ...doctor };
  }
  if (clinic) {
    db.clinic = { ...db.clinic, ...clinic };
  }

  saveDatabase();
  res.json({ message: 'Settings saved successfully.', doctor: db.doctor, clinic: db.clinic });
});

apiRouter.post('/admin/change-password', requireAdminAuth, (req: AuthenticatedRequest, res: Response) => {
  const { currentPassword, newPassword } = req.body;

  if (!currentPassword || !newPassword || newPassword.length < 6) {
    res.status(400).json({ error: 'New password must be at least 6 characters long.' });
    return;
  }

  const db = getDatabase();
  const currentHash = hashPassword(currentPassword, db.admin.salt);

  if (currentHash !== db.admin.passwordHash) {
    res.status(401).json({ error: 'Current password is incorrect.' });
    return;
  }

  db.admin.passwordHash = hashPassword(newPassword, db.admin.salt);
  saveDatabase();

  res.json({ message: 'Password changed successfully.' });
});

// ==========================================
// 8. NOTIFICATION LOGS & TEST DISPATCH
// ==========================================

apiRouter.get('/admin/notifications', requireAdminAuth, (_req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  res.json({ notifications: db.notifications });
});

apiRouter.post('/admin/notifications/test', requireAdminAuth, async (req: AuthenticatedRequest, res: Response) => {
  const { phone, message, forceFailWhatsApp } = req.body;

  if (!phone || !message) {
    res.status(400).json({ error: 'Phone number and test message are required.' });
    return;
  }

  try {
    const result = await NotificationService.dispatchNotification(
      'Doctor',
      phone,
      message,
      'TEST-MSG',
      Boolean(forceFailWhatsApp)
    );
    res.json({
      message: `Notification dispatch executed via ${result.channel}: ${result.status}`,
      result
    });
  } catch (err: unknown) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Notification dispatch failed' });
  }
});

// ==========================================
// 9. DEMO DATA RESET
// ==========================================

apiRouter.post('/admin/reset-demo-data', requireAdminAuth, (_req: AuthenticatedRequest, res: Response) => {
  const freshDb = resetDemoData();
  res.json({ message: 'Demo data has been reset to initial seed state.', count: freshDb.appointments.length });
});

// ==========================================
// 10. DOWNLOAD FULL SOURCE CODE (.ZIP)
// ==========================================

apiRouter.get('/download/source-code', async (_req: Request, res: Response) => {
  try {
    const AdmZip = (await import('adm-zip')).default;
    const path = (await import('path')).default;
    const fs = (await import('fs')).default;

    const zip = new AdmZip();
    const rootDir = process.cwd();

    // Helper to add directory recursively while ignoring node_modules, dist, .git
    function addDirRecursive(localDirPath: string, zipPrefix: string) {
      if (!fs.existsSync(localDirPath)) return;
      const entries = fs.readdirSync(localDirPath, { withFileTypes: true });

      for (const entry of entries) {
        const fullPath = path.join(localDirPath, entry.name);
        const zipEntryPath = zipPrefix ? `${zipPrefix}/${entry.name}` : entry.name;

        // Skip ignored directories & files
        if (
          entry.name === 'node_modules' ||
          entry.name === 'dist' ||
          entry.name === '.git' ||
          entry.name === '.cache' ||
          entry.name === '.DS_Store'
        ) {
          continue;
        }

        if (entry.isDirectory()) {
          addDirRecursive(fullPath, zipEntryPath);
        } else if (entry.isFile()) {
          const content = fs.readFileSync(fullPath);
          zip.addFile(zipEntryPath, content);
        }
      }
    }

    // Add main source directories & config files
    addDirRecursive(path.join(rootDir, 'src'), 'src');
    addDirRecursive(path.join(rootDir, 'server'), 'server');
    addDirRecursive(path.join(rootDir, 'public'), 'public');
    addDirRecursive(path.join(rootDir, 'data'), 'data');

    const topFiles = [
      'index.html',
      'package.json',
      'tsconfig.json',
      'vite.config.ts',
      'server.ts',
      '.env.example',
      'metadata.json',
      'README.md'
    ];

    for (const file of topFiles) {
      const fullPath = path.join(rootDir, file);
      if (fs.existsSync(fullPath)) {
        zip.addFile(file, fs.readFileSync(fullPath));
      }
    }

    // Generate zip buffer
    const zipBuffer = zip.toBuffer();

    res.set({
      'Content-Type': 'application/zip',
      'Content-Disposition': 'attachment; filename="dr-jagadish-das-doctor-appointment-app.zip"',
      'Content-Length': zipBuffer.length.toString()
    });

    res.send(zipBuffer);
  } catch (err: unknown) {
    console.error('Failed to create project ZIP:', err);
    res.status(500).json({ error: 'Failed to generate source zip file' });
  }
});

