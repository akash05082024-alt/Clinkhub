import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { api } from './api';
import { PublicClinicInfo, Appointment } from './types';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { DoctorProfilePage } from './pages/DoctorProfilePage';
import { ServicesPage } from './pages/ServicesPage';
import { ClinicPage } from './pages/ClinicPage';
import { BookingPage } from './pages/BookingPage';
import { FindAppointmentPage } from './pages/FindAppointmentPage';
import { ConfirmationView } from './components/ConfirmationView';
import { AdminLogin } from './components/admin/AdminLogin';
import { AdminLayout } from './components/admin/AdminLayout';

function MainApp() {
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [clinicInfo, setClinicInfo] = useState<PublicClinicInfo | null>(null);
  const [confirmedAppointment, setConfirmedAppointment] = useState<Appointment | null>(null);
  const [searchAppointmentId, setSearchAppointmentId] = useState<string>('');

  // Fetch initial public clinic & doctor profile info
  useEffect(() => {
    async function loadInfo() {
      try {
        const data = await api.getClinicInfo();
        setClinicInfo(data);
      } catch (err) {
        console.error('Failed to load clinic information:', err);
      }
    }
    loadInfo();

    // Check pathname / hash for deep linking
    const path = window.location.pathname;
    const hash = window.location.hash;

    if (path === '/admin/login' || hash === '#admin-login') {
      setCurrentTab('admin-login');
    } else if (path === '/admin' || hash === '#admin') {
      setCurrentTab('admin');
    } else if (path.startsWith('/appointment/')) {
      const id = path.replace('/appointment/', '');
      if (id) {
        setSearchAppointmentId(id);
        setCurrentTab('my-appointment');
      }
    }
  }, []);

  // Update hash when switching tabs for bookmarking
  const handleNavigate = (tab: string, appointmentId?: string) => {
    if (appointmentId) {
      setSearchAppointmentId(appointmentId);
    }
    setCurrentTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Sync window hash for clean URL state
    if (tab === 'home') {
      window.history.pushState(null, '', '/');
    } else if (tab === 'admin') {
      window.history.pushState(null, '', '#admin');
    } else if (tab === 'admin-login') {
      window.history.pushState(null, '', '#admin-login');
    } else {
      window.history.pushState(null, '', `#${tab}`);
    }
  };

  const handleBookingSuccess = (appointment: Appointment) => {
    setConfirmedAppointment(appointment);
    setCurrentTab('confirmation');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // If user is accessing Admin
  if (currentTab === 'admin') {
    if (authLoading) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-slate-100">
          <div className="w-8 h-8 border-4 border-teal-600 border-t-transparent rounded-full animate-spin"></div>
        </div>
      );
    }

    if (!isAuthenticated) {
      return (
        <AdminLogin
          onBackToWebsite={() => handleNavigate('home')}
          onLoginSuccess={() => handleNavigate('admin')}
        />
      );
    }

    return <AdminLayout onBackToWebsite={() => handleNavigate('home')} />;
  }

  if (currentTab === 'admin-login') {
    return (
      <AdminLogin
        onBackToWebsite={() => handleNavigate('home')}
        onLoginSuccess={() => handleNavigate('admin')}
      />
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans selection:bg-teal-100 selection:text-teal-900">
      {/* Public Navigation */}
      <Navbar
        currentTab={currentTab}
        onNavigate={handleNavigate}
        clinicInfo={clinicInfo}
      />

      {/* Main Page Content */}
      <main className="flex-1">
        {currentTab === 'home' && (
          <HomePage
            clinicInfo={clinicInfo}
            onNavigate={handleNavigate}
            onBookingSuccess={handleBookingSuccess}
          />
        )}

        {currentTab === 'profile' && (
          <DoctorProfilePage
            clinicInfo={clinicInfo}
            onBookClick={() => handleNavigate('book')}
          />
        )}

        {currentTab === 'services' && (
          <ServicesPage
            clinicInfo={clinicInfo}
            onBookClick={() => handleNavigate('book')}
          />
        )}

        {currentTab === 'clinic' && (
          <ClinicPage
            clinicInfo={clinicInfo}
            onBookClick={() => handleNavigate('book')}
          />
        )}

        {currentTab === 'book' && (
          <BookingPage
            clinicInfo={clinicInfo}
            onAppointmentConfirmed={handleBookingSuccess}
          />
        )}

        {currentTab === 'my-appointment' && (
          <FindAppointmentPage
            clinicInfo={clinicInfo}
            onBookClick={() => handleNavigate('book')}
            initialAppointmentId={searchAppointmentId}
          />
        )}

        {currentTab === 'confirmation' && confirmedAppointment && (
          <div className="max-w-4xl mx-auto px-4 py-8">
            <ConfirmationView
              appointment={confirmedAppointment}
              clinicInfo={clinicInfo}
              onBookAnother={() => handleNavigate('book')}
              onAppointmentUpdated={(upd) => setConfirmedAppointment(upd)}
            />
          </div>
        )}
      </main>

      {/* Public Footer */}
      <Footer
        clinicInfo={clinicInfo}
        onNavigate={handleNavigate}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
