import {
  PublicClinicInfo,
  AvailableSlotsResponse,
  Appointment,
  Patient,
  DashboardStats,
  AvailabilitySettings,
  NotificationLog,
  DoctorProfile,
  ClinicSettings
} from './types';

const TOKEN_KEY = 'dr_jdas_admin_token';

export const getAuthToken = (): string | null => {
  return localStorage.getItem(TOKEN_KEY);
};

export const setAuthToken = (token: string): void => {
  localStorage.setItem(TOKEN_KEY, token);
};

export const removeAuthToken = (): void => {
  localStorage.removeItem(TOKEN_KEY);
};

async function apiFetch<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers || {});
  if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  const token = getAuthToken();
  if (token && !headers.has('Authorization')) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  const res = await fetch(`/api${endpoint}`, {
    ...options,
    headers
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.error || `Request failed with status ${res.status}`);
  }

  return data as T;
}

export const api = {
  // Public
  getClinicInfo: () => apiFetch<PublicClinicInfo>('/public/clinic-info'),
  getAvailableSlots: (date: string) => apiFetch<AvailableSlotsResponse>(`/appointments/available-slots?date=${date}`),
  bookAppointment: (bookingData: {
    date: string;
    time: string;
    name: string;
    phone: string;
    email?: string;
    age: number;
    gender: 'Male' | 'Female' | 'Other';
    address?: string;
    reason: string;
  }) =>
    apiFetch<{ message: string; appointment: Appointment }>('/appointments/book', {
      method: 'POST',
      body: JSON.stringify(bookingData)
    }),
  getAppointmentById: (id: string) =>
    apiFetch<{
      appointment: Appointment;
      doctor: { name: string; degrees: string; specialization: string; consultationFee: number };
      clinic: { name: string; address: string; phone: string; googleMapsUrl: string };
    }>(`/appointments/${encodeURIComponent(id)}`),
  cancelAppointment: (id: string, reason?: string) =>
    apiFetch<{ message: string; appointment: Appointment }>(`/appointments/${encodeURIComponent(id)}/cancel`, {
      method: 'POST',
      body: JSON.stringify({ reason })
    }),

  // Admin Auth
  adminLogin: (identifier: string, password: string, rememberMe = false) =>
    apiFetch<{ token: string; user: { id: string; email: string; phone: string; fullName: string } }>(
      '/admin/login',
      {
        method: 'POST',
        body: JSON.stringify({ identifier, password, rememberMe })
      }
    ),
  adminMe: () =>
    apiFetch<{ user: { id: string; email: string; phone: string; fullName: string }; isDemoData: boolean }>(
      '/admin/me'
    ),
  adminLogout: () => apiFetch<{ message: string }>('/admin/logout', { method: 'POST' }),

  // Admin Dashboard & Appointments
  getDashboardStats: () => apiFetch<DashboardStats>('/admin/dashboard-stats'),
  getAppointments: (params?: { date?: string; status?: string; search?: string }) => {
    const query = new URLSearchParams();
    if (params?.date) query.set('date', params.date);
    if (params?.status) query.set('status', params.status);
    if (params?.search) query.set('search', params.search);
    return apiFetch<{ appointments: Appointment[]; count: number }>(`/admin/appointments?${query.toString()}`);
  },
  createAppointmentAdmin: (data: {
    date: string;
    time: string;
    name: string;
    phone: string;
    email?: string;
    age: number;
    gender: 'Male' | 'Female' | 'Other';
    address?: string;
    reason: string;
    doctorNotes?: string;
  }) =>
    apiFetch<{ appointment: Appointment; message: string }>('/admin/appointments', {
      method: 'POST',
      body: JSON.stringify(data)
    }),
  updateAppointmentStatus: (id: string, status: string) =>
    apiFetch<{ message: string; appointment: Appointment }>(`/admin/appointments/${encodeURIComponent(id)}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status })
    }),
  rescheduleAppointment: (id: string, newDate: string, newTime: string) =>
    apiFetch<{ message: string; appointment: Appointment }>(
      `/admin/appointments/${encodeURIComponent(id)}/reschedule`,
      {
        method: 'PATCH',
        body: JSON.stringify({ newDate, newTime })
      }
    ),
  updateDoctorNotes: (id: string, notes: string) =>
    apiFetch<{ message: string; appointment: Appointment }>(`/admin/appointments/${encodeURIComponent(id)}/notes`, {
      method: 'PATCH',
      body: JSON.stringify({ notes })
    }),

  // Admin Patients
  getPatients: (search?: string) => {
    const query = search ? `?search=${encodeURIComponent(search)}` : '';
    return apiFetch<{ patients: Patient[] }>(`/admin/patients${query}`);
  },
  getPatientDetails: (id: string) =>
    apiFetch<{ patient: Patient; appointments: Appointment[] }>(`/admin/patients/${encodeURIComponent(id)}`),

  // Admin Availability
  getAvailability: () => apiFetch<{ availability: AvailabilitySettings }>('/admin/availability'),
  updateAvailability: (availability: AvailabilitySettings) =>
    apiFetch<{ message: string; availability: AvailabilitySettings }>('/admin/availability', {
      method: 'PUT',
      body: JSON.stringify(availability)
    }),

  // Admin Settings
  getSettings: () =>
    apiFetch<{ doctor: DoctorProfile; clinic: ClinicSettings; availability: AvailabilitySettings }>(
      '/admin/settings'
    ),
  updateSettings: (data: { doctor?: Partial<DoctorProfile>; clinic?: Partial<ClinicSettings> }) =>
    apiFetch<{ message: string; doctor: DoctorProfile; clinic: ClinicSettings }>('/admin/settings', {
      method: 'PUT',
      body: JSON.stringify(data)
    }),
  changePassword: (currentPassword: string, newPassword: string) =>
    apiFetch<{ message: string }>('/admin/change-password', {
      method: 'POST',
      body: JSON.stringify({ currentPassword, newPassword })
    }),

  // Admin Notifications
  getNotifications: () => apiFetch<{ notifications: NotificationLog[] }>('/admin/notifications'),
  testNotification: (phone: string, message: string, forceFailWhatsApp = false) =>
    apiFetch<{ message: string; result: unknown }>('/admin/notifications/test', {
      method: 'POST',
      body: JSON.stringify({ phone, message, forceFailWhatsApp })
    }),

  // Reset demo
  resetDemoData: () => apiFetch<{ message: string }>('/admin/reset-demo-data', { method: 'POST' })
};

/**
 * Calendar Helpers
 */
export function generateGoogleCalendarUrl(appointment: Appointment, clinicAddress: string): string {
  const [hoursStr, minutesStrPeriod] = appointment.appointment_time.split(':');
  const [minutesStr, period] = minutesStrPeriod.split(' ');
  let h = parseInt(hoursStr, 10);
  const m = parseInt(minutesStr, 10);
  if (period.toUpperCase() === 'PM' && h !== 12) h += 12;
  if (period.toUpperCase() === 'AM' && h === 12) h = 0;

  const [year, month, day] = appointment.appointment_date.split('-').map(Number);
  const startDate = new Date(year, month - 1, day, h, m);
  const endDate = new Date(startDate.getTime() + 30 * 60 * 1000); // 30 mins

  const toIsoCompact = (d: Date) => d.toISOString().replace(/-|:|\.\d\d\d/g, '');

  const title = encodeURIComponent(`Doctor Appointment with Dr. Jagadish Das (${appointment.appointment_id})`);
  const details = encodeURIComponent(
    `Medical consultation with Dr. Jagadish Das (MBBS).\nAppointment ID: ${appointment.appointment_id}\nPatient: ${appointment.patient_name}\nReason: ${appointment.reason}\n\nPlease arrive 10-15 minutes prior to appointment.`
  );
  const location = encodeURIComponent(clinicAddress);
  const dates = `${toIsoCompact(startDate)}/${toIsoCompact(endDate)}`;

  return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${title}&dates=${dates}&details=${details}&location=${location}`;
}

export function downloadIcsFile(appointment: Appointment, clinicAddress: string): void {
  const [hoursStr, minutesStrPeriod] = appointment.appointment_time.split(':');
  const [minutesStr, period] = minutesStrPeriod.split(' ');
  let h = parseInt(hoursStr, 10);
  const m = parseInt(minutesStr, 10);
  if (period.toUpperCase() === 'PM' && h !== 12) h += 12;
  if (period.toUpperCase() === 'AM' && h === 12) h = 0;

  const [year, month, day] = appointment.appointment_date.split('-').map(Number);
  const startDate = new Date(year, month - 1, day, h, m);
  const endDate = new Date(startDate.getTime() + 30 * 60 * 1000);

  const formatIcsDate = (d: Date) => d.toISOString().replace(/-|:|\.\d\d\d/g, '');

  const icsContent = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Dr. Jagadish Das//Appointment Booking//EN',
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH',
    'BEGIN:VEVENT',
    `UID:${appointment.appointment_id}@drjagadishdas.com`,
    `DTSTAMP:${formatIcsDate(new Date())}`,
    `DTSTART:${formatIcsDate(startDate)}`,
    `DTEND:${formatIcsDate(endDate)}`,
    `SUMMARY:Dr. Jagadish Das - Clinic Consultation (${appointment.appointment_id})`,
    `DESCRIPTION:Appointment ID: ${appointment.appointment_id}\\nPatient: ${appointment.patient_name}\\nReason: ${appointment.reason}\\nArrive 10-15 mins early.`,
    `LOCATION:${clinicAddress.replace(/,/g, '\\,')}`,
    'STATUS:CONFIRMED',
    'END:VEVENT',
    'END:VCALENDAR'
  ].join('\r\n');

  const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `appointment-${appointment.appointment_id}.ics`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
