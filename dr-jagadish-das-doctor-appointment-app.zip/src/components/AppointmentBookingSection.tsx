import React, { useState, useEffect } from 'react';
import {
  Calendar,
  Clock,
  User,
  Phone,
  Mail,
  FileText,
  AlertCircle,
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  ShieldCheck,
  MapPin,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { api } from '../api';
import { PublicClinicInfo, TimeSlot, Appointment } from '../types';

interface AppointmentBookingSectionProps {
  clinicInfo?: PublicClinicInfo | null;
  onBookingSuccess: (appointment: Appointment) => void;
  initialDate?: string;
}

export const AppointmentBookingSection: React.FC<AppointmentBookingSectionProps> = ({
  clinicInfo,
  onBookingSuccess,
  initialDate
}) => {
  // Step state: 1 = Date & Time, 2 = Patient Information, 3 = Summary Review
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3>(1);

  // Date selection (default to today)
  const todayStr = new Date().toISOString().split('T')[0];
  const [selectedDate, setSelectedDate] = useState<string>(initialDate || todayStr);

  // Slots state
  const [slotsLoading, setSlotsLoading] = useState<boolean>(false);
  const [slotsError, setSlotsError] = useState<string | null>(null);
  const [isDayOpen, setIsDayOpen] = useState<boolean>(true);
  const [dayClosedReason, setDayClosedReason] = useState<string | null>(null);
  const [slots, setSlots] = useState<TimeSlot[]>([]);
  const [selectedTime, setSelectedTime] = useState<string>('');

  // Patient Form
  const [fullName, setFullName] = useState<string>('');
  const [mobileNumber, setMobileNumber] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [age, setAge] = useState<string>('');
  const [gender, setGender] = useState<'Male' | 'Female' | 'Other'>('Male');
  const [address, setAddress] = useState<string>('');
  const [reasonCategory, setReasonCategory] = useState<string>('General Health Consultation');
  const [customReason, setCustomReason] = useState<string>('');

  // Submission state
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  // Fetch slots whenever selectedDate changes
  useEffect(() => {
    let isCancelled = false;

    async function fetchSlots() {
      setSlotsLoading(true);
      setSlotsError(null);
      setSelectedTime('');

      try {
        const data = await api.getAvailableSlots(selectedDate);
        if (isCancelled) return;

        setIsDayOpen(data.isOpen);
        setDayClosedReason(data.reason || null);
        setSlots(data.slots || []);
      } catch (err: unknown) {
        if (!isCancelled) {
          setSlotsError(err instanceof Error ? err.message : 'Could not fetch time slots for this date.');
        }
      } finally {
        if (!isCancelled) {
          setSlotsLoading(false);
        }
      }
    }

    if (selectedDate) {
      fetchSlots();
    }

    return () => {
      isCancelled = true;
    };
  }, [selectedDate]);

  // Generate list of selectable next 21 days
  const candidateDates = React.useMemo(() => {
    const list: { dateStr: string; dayName: string; dayNum: number; monthName: string; isSunday: boolean }[] = [];
    const base = new Date();
    for (let i = 0; i < 21; i++) {
      const d = new Date();
      d.setDate(base.getDate() + i);
      const dateStr = d.toISOString().split('T')[0];
      const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
      const dayNum = d.getDate();
      const monthName = d.toLocaleDateString('en-US', { month: 'short' });
      const isSunday = d.getDay() === 0;
      list.push({ dateStr, dayName, dayNum, monthName, isSunday });
    }
    return list;
  }, []);

  // Validation before going to Review Step 3
  const handleValidatePatientInfo = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);

    if (!selectedTime) {
      setSubmitError('Please select an available appointment time slot.');
      setCurrentStep(1);
      return;
    }

    if (!fullName.trim()) {
      setSubmitError('Please enter the patient full name.');
      return;
    }

    const cleanMobile = mobileNumber.replace(/\D/g, '');
    if (cleanMobile.length < 10) {
      setSubmitError('Please enter a valid 10-digit mobile number for appointment SMS / WhatsApp confirmation.');
      return;
    }

    const ageNum = parseInt(age, 10);
    if (isNaN(ageNum) || ageNum <= 0 || ageNum > 125) {
      setSubmitError('Please enter a valid age between 1 and 120 years.');
      return;
    }

    setCurrentStep(3); // Proceed to review summary
  };

  // Final confirmation submission with atomic locking on server
  const handleFinalBooking = async () => {
    setIsSubmitting(true);
    setSubmitError(null);

    const fullReason =
      reasonCategory === 'Other' && customReason.trim()
        ? `Other: ${customReason.trim()}`
        : reasonCategory;

    try {
      const res = await api.bookAppointment({
        date: selectedDate,
        time: selectedTime,
        name: fullName.trim(),
        phone: mobileNumber.trim(),
        email: email.trim(),
        age: parseInt(age, 10),
        gender,
        address: address.trim(),
        reason: fullReason
      });

      // Notify parent to switch view to Confirmation View
      onBookingSuccess(res.appointment);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Appointment could not be booked. Please try again.';
      setSubmitError(msg);

      // If slot was just taken, refresh slots and send user back to step 1
      if (msg.includes('just been booked') || msg.includes('conflict')) {
        try {
          const freshSlots = await api.getAvailableSlots(selectedDate);
          setSlots(freshSlots.slots || []);
        } catch {
          // ignore
        }
        setCurrentStep(1);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const doctorName = clinicInfo?.doctor.name || 'Dr. Jagadish Das';
  const doctorDegree = clinicInfo?.doctor.degrees || 'MBBS';
  const consultationFee = clinicInfo?.clinic.consultationFee || 500;
  const clinicName = clinicInfo?.clinic.name || 'Arogya Health & Consultation Clinic';
  const clinicAddress = clinicInfo
    ? `${clinicInfo.clinic.addressLine1}, ${clinicInfo.clinic.addressLine2}, ${clinicInfo.clinic.city}`
    : 'Suite 204, Care Health Complex, Kolkata';

  const morningSlots = slots.filter((s) => s.shift === 'Morning');
  const eveningSlots = slots.filter((s) => s.shift === 'Evening');
  const totalAvailable = slots.filter((s) => s.available).length;

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden" id="booking-wizard">
      {/* Wizard Header */}
      <div className="bg-slate-900 text-white p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <span className="text-xs uppercase font-semibold tracking-wider text-teal-400 font-sans">
              Online Appointment System
            </span>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-white mt-1">
              Book Your Consultation
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-1">
              with <strong className="text-teal-300">{doctorName}</strong> ({doctorDegree}) · Fee: ₹{consultationFee}
            </p>
          </div>

          {/* Stepper indicator */}
          <div className="flex items-center gap-2 text-xs">
            <div
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md ${
                currentStep === 1 ? 'bg-teal-700 text-white font-semibold' : 'bg-slate-800 text-slate-400'
              }`}
            >
              <span>1. Date & Time</span>
            </div>
            <span className="text-slate-600">→</span>
            <div
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md ${
                currentStep === 2 ? 'bg-teal-700 text-white font-semibold' : 'bg-slate-800 text-slate-400'
              }`}
            >
              <span>2. Patient Info</span>
            </div>
            <span className="text-slate-600">→</span>
            <div
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md ${
                currentStep === 3 ? 'bg-teal-700 text-white font-semibold' : 'bg-slate-800 text-slate-400'
              }`}
            >
              <span>3. Confirm</span>
            </div>
          </div>
        </div>
      </div>

      {/* Error alert banner */}
      {submitError && (
        <div className="m-6 p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 flex items-start gap-3 text-sm">
          <AlertCircle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-semibold text-amber-900">Notice:</p>
            <p className="text-xs mt-0.5">{submitError}</p>
          </div>
        </div>
      )}

      {/* STEP 1: Date & Time Slot Selection */}
      {currentStep === 1 && (
        <div className="p-6 sm:p-8 space-y-8">
          {/* Date Picker Bar */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <label className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Calendar className="w-4 h-4 text-teal-700" />
                <span>1. Select Appointment Date</span>
              </label>
              <div className="text-xs text-slate-500">
                Selected: <span className="font-semibold text-teal-800">{new Date(selectedDate).toDateString()}</span>
              </div>
            </div>

            {/* Horizontal scrollable date pills */}
            <div className="flex items-center gap-2.5 overflow-x-auto pb-3 pt-1 scrollbar-thin scrollbar-thumb-slate-200">
              {candidateDates.map((item) => {
                const isSelected = selectedDate === item.dateStr;
                return (
                  <button
                    key={item.dateStr}
                    type="button"
                    onClick={() => setSelectedDate(item.dateStr)}
                    className={`flex flex-col items-center justify-center min-w-[70px] sm:min-w-[80px] py-2.5 px-2 rounded-xl text-center border transition-all ${
                      isSelected
                        ? 'border-teal-700 bg-teal-50/80 text-teal-950 font-semibold shadow-sm ring-1 ring-teal-700'
                        : item.isSunday
                        ? 'border-slate-200 bg-slate-50/60 text-slate-400 hover:border-slate-300'
                        : 'border-slate-200 bg-white text-slate-700 hover:border-teal-500 hover:bg-teal-50/30'
                    }`}
                  >
                    <span className="text-[11px] uppercase tracking-wider font-medium text-slate-500">
                      {item.dayName}
                    </span>
                    <span className="text-lg font-bold my-0.5 font-mono">{item.dayNum}</span>
                    <span className="text-[10px] text-slate-500">{item.monthName}</span>
                    {item.isSunday && (
                      <span className="text-[9px] text-rose-500 font-medium mt-0.5">Closed</span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Time Slots Area */}
          <div>
            <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
              <label className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Clock className="w-4 h-4 text-teal-700" />
                <span>2. Select Preferred Time Slot</span>
              </label>
              {isDayOpen && !slotsLoading && (
                <div className="flex items-center gap-3 text-xs text-slate-600">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                    <span>{totalAvailable} Available</span>
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-slate-300"></span>
                    <span>Booked / Past</span>
                  </span>
                </div>
              )}
            </div>

            {slotsLoading ? (
              <div className="p-12 text-center text-slate-500 border border-dashed border-slate-200 rounded-xl space-y-2">
                <div className="inline-block w-6 h-6 border-2 border-teal-600 border-t-transparent rounded-full animate-spin"></div>
                <p className="text-xs">Checking real-time doctor availability...</p>
              </div>
            ) : !isDayOpen ? (
              <div className="p-8 text-center bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <AlertCircle className="w-8 h-8 text-amber-600 mx-auto" />
                <h4 className="text-sm font-semibold text-slate-900">Clinic Closed on this Date</h4>
                <p className="text-xs text-slate-600 max-w-md mx-auto">
                  {dayClosedReason || 'Dr. Jagadish Das is not conducting consultations on this date.'}
                </p>
                <p className="text-xs text-teal-700 font-medium pt-2">
                  Please pick another working day (Monday through Saturday).
                </p>
              </div>
            ) : slots.length === 0 ? (
              <div className="p-8 text-center bg-slate-50 border border-slate-200 rounded-xl text-slate-600 text-xs">
                No slots configured for this date.
              </div>
            ) : (
              <div className="space-y-6">
                {/* Morning Session */}
                {morningSlots.length > 0 && (
                  <div>
                    <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-100">
                      <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                        Morning Session (10:00 AM – 01:00 PM)
                      </span>
                      <span className="text-[11px] text-slate-500">
                        {morningSlots.filter((s) => s.available).length} open slots
                      </span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2.5">
                      {morningSlots.map((slot) => {
                        const isSelected = selectedTime === slot.time;
                        const isAvailable = slot.available;
                        return (
                          <button
                            key={slot.time}
                            type="button"
                            disabled={!isAvailable}
                            onClick={() => {
                              setSelectedTime(slot.time);
                              setSubmitError(null);
                            }}
                            className={`py-3 px-3 rounded-xl text-xs font-medium border text-center transition-all flex flex-col items-center justify-center gap-1 ${
                              isSelected
                                ? 'bg-teal-700 text-white border-teal-800 shadow-sm font-semibold'
                                : isAvailable
                                ? 'bg-white border-slate-200 text-slate-800 hover:border-teal-600 hover:bg-teal-50/50'
                                : 'bg-slate-100/80 border-slate-200/60 text-slate-400 cursor-not-allowed'
                            }`}
                          >
                            <span className="font-mono text-sm">{slot.time}</span>
                            <span className="text-[10px]">
                              {isAvailable ? (
                                isSelected ? (
                                  <span className="text-teal-100 font-medium">Selected</span>
                                ) : (
                                  <span className="text-emerald-700 font-medium">Available</span>
                                )
                              ) : slot.status === 'booked' ? (
                                'Booked'
                              ) : (
                                'Past'
                              )}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Evening Session */}
                {eveningSlots.length > 0 && (
                  <div>
                    <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-100">
                      <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                        Evening Session (05:00 PM – 08:00 PM)
                      </span>
                      <span className="text-[11px] text-slate-500">
                        {eveningSlots.filter((s) => s.available).length} open slots
                      </span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2.5">
                      {eveningSlots.map((slot) => {
                        const isSelected = selectedTime === slot.time;
                        const isAvailable = slot.available;
                        return (
                          <button
                            key={slot.time}
                            type="button"
                            disabled={!isAvailable}
                            onClick={() => {
                              setSelectedTime(slot.time);
                              setSubmitError(null);
                            }}
                            className={`py-3 px-3 rounded-xl text-xs font-medium border text-center transition-all flex flex-col items-center justify-center gap-1 ${
                              isSelected
                                ? 'bg-teal-700 text-white border-teal-800 shadow-sm font-semibold'
                                : isAvailable
                                ? 'bg-white border-slate-200 text-slate-800 hover:border-teal-600 hover:bg-teal-50/50'
                                : 'bg-slate-100/80 border-slate-200/60 text-slate-400 cursor-not-allowed'
                            }`}
                          >
                            <span className="font-mono text-sm">{slot.time}</span>
                            <span className="text-[10px]">
                              {isAvailable ? (
                                isSelected ? (
                                  <span className="text-teal-100 font-medium">Selected</span>
                                ) : (
                                  <span className="text-emerald-700 font-medium">Available</span>
                                )
                              ) : slot.status === 'booked' ? (
                                'Booked'
                              ) : (
                                'Past'
                              )}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Step 1 Footer CTA */}
          <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="text-xs text-slate-600">
              {selectedTime ? (
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>
                    Selected: <strong className="text-slate-900">{selectedTime}</strong> on{' '}
                    <strong className="text-slate-900">{new Date(selectedDate).toDateString()}</strong>
                  </span>
                </div>
              ) : (
                <span className="text-slate-400 italic">Please select a time slot to continue</span>
              )}
            </div>

            <button
              type="button"
              disabled={!selectedTime || !isDayOpen}
              onClick={() => setCurrentStep(2)}
              className={`w-full sm:w-auto px-6 py-3 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 transition-all ${
                selectedTime && isDayOpen
                  ? 'bg-teal-700 text-white hover:bg-teal-800 shadow-sm'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
              }`}
            >
              <span>Continue to Patient Details</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: Patient Information Form */}
      {currentStep === 2 && (
        <form onSubmit={handleValidatePatientInfo} className="p-6 sm:p-8 space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Patient Details</h3>
              <p className="text-xs text-slate-500">
                Booking for: <strong className="text-teal-800">{new Date(selectedDate).toDateString()}</strong> at{' '}
                <strong className="text-teal-800">{selectedTime}</strong>
              </p>
            </div>
            <button
              type="button"
              onClick={() => setCurrentStep(1)}
              className="text-xs font-semibold text-teal-700 hover:underline flex items-center gap-1"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Change Slot</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Full Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Patient Full Name <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <User className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ramesh Mukherjee"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-teal-600"
                />
              </div>
            </div>

            {/* Mobile Number */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Mobile Number (for SMS & WhatsApp Confirmation) <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Phone className="w-4 h-4" />
                </div>
                <input
                  type="tel"
                  required
                  placeholder="e.g. 98301 23456"
                  value={mobileNumber}
                  onChange={(e) => setMobileNumber(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-teal-600"
                />
              </div>
              <p className="text-[11px] text-slate-500 mt-1">Instant confirmation will be sent to this number.</p>
            </div>

            {/* Age & Gender */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Age <span className="text-rose-500">*</span>
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  max="125"
                  placeholder="Years"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  className="w-full px-3 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-teal-600"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Gender <span className="text-rose-500">*</span>
                </label>
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value as 'Male' | 'Female' | 'Other')}
                  className="w-full px-3 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-teal-600"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>

            {/* Email (Optional) */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Email Address <span className="text-slate-400 font-normal">(Optional)</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  type="email"
                  placeholder="e.g. name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-teal-600"
                />
              </div>
            </div>

            {/* Reason for Visit */}
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Primary Reason for Consultation <span className="text-rose-500">*</span>
              </label>
              <select
                value={reasonCategory}
                onChange={(e) => setReasonCategory(e.target.value)}
                className="w-full px-3 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-teal-600"
              >
                <option value="General Health Consultation">General Health Consultation</option>
                <option value="Fever / Cough / Cold / Flu">Fever, Cough, Cold or Flu symptoms</option>
                <option value="High Blood Pressure / Hypertension Review">High Blood Pressure / Hypertension Review</option>
                <option value="Diabetes & Blood Sugar Monitoring">Diabetes & Blood Sugar Monitoring</option>
                <option value="Digestive Issues / Acidity / Abdominal Pain">Digestive Issues / Acidity / Abdominal Pain</option>
                <option value="Routine Health Checkup & Prescription Renewal">Routine Health Checkup & Prescription Renewal</option>
                <option value="Headache / Migraine Consultation">Headache / Migraine Consultation</option>
                <option value="Other">Other Medical Complaint (Specify below)</option>
              </select>

              {reasonCategory === 'Other' && (
                <input
                  type="text"
                  placeholder="Please describe your main health symptom or concern..."
                  value={customReason}
                  onChange={(e) => setCustomReason(e.target.value)}
                  className="w-full mt-2 px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
                />
              )}
            </div>

            {/* Address (Optional) */}
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Residential Address / Locality <span className="text-slate-400 font-normal">(Optional)</span>
              </label>
              <input
                type="text"
                placeholder="e.g. Salt Lake, Sector 2, Kolkata"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full px-3 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-teal-600"
              />
            </div>
          </div>

          {/* Form Actions */}
          <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-3">
            <button
              type="button"
              onClick={() => setCurrentStep(1)}
              className="w-full sm:w-auto px-5 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-lg transition-colors flex items-center justify-center gap-1.5"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Back to Time Selection</span>
            </button>

            <button
              type="submit"
              className="w-full sm:w-auto px-7 py-3 text-sm font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-sm transition-all flex items-center justify-center gap-2"
            >
              <span>Review & Confirm Details</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      )}

      {/* STEP 3: Summary & Pre-Confirmation Review */}
      {currentStep === 3 && (
        <div className="p-6 sm:p-8 space-y-6">
          <div className="pb-3 border-b border-slate-100">
            <h3 className="text-lg font-bold text-slate-900">Review Appointment Details</h3>
            <p className="text-xs text-slate-500">
              Please verify your appointment information carefully before final booking.
            </p>
          </div>

          {/* Summary Card */}
          <div className="bg-slate-50/80 rounded-xl p-5 border border-slate-200 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <span className="text-slate-500 block mb-0.5">Doctor</span>
                <span className="text-sm font-bold text-slate-900 font-serif">
                  {doctorName} ({doctorDegree})
                </span>
                <span className="block text-[11px] text-teal-700 font-medium">
                  {clinicInfo?.doctor.specialization || 'Consultant Physician'}
                </span>
              </div>

              <div>
                <span className="text-slate-500 block mb-0.5">Clinic Location</span>
                <span className="text-xs font-semibold text-slate-800 block">{clinicName}</span>
                <span className="text-[11px] text-slate-600 block">{clinicAddress}</span>
              </div>

              <div className="sm:col-span-2 pt-2 border-t border-slate-200/80 grid grid-cols-2 sm:grid-cols-3 gap-4">
                <div>
                  <span className="text-slate-500 block mb-0.5">Appointment Date</span>
                  <span className="text-sm font-bold text-teal-900 font-mono">
                    {new Date(selectedDate).toLocaleDateString('en-US', {
                      weekday: 'short',
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric'
                    })}
                  </span>
                </div>

                <div>
                  <span className="text-slate-500 block mb-0.5">Appointment Time</span>
                  <span className="text-sm font-bold text-teal-900 font-mono">{selectedTime}</span>
                </div>

                <div>
                  <span className="text-slate-500 block mb-0.5">Consultation Fee</span>
                  <span className="text-sm font-bold text-slate-900">₹{consultationFee}</span>
                  <span className="text-[10px] text-slate-500 block">(Payable at clinic)</span>
                </div>
              </div>

              <div className="sm:col-span-2 pt-2 border-t border-slate-200/80 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <span className="text-slate-500 block mb-0.5">Patient Name</span>
                  <span className="text-sm font-semibold text-slate-900">{fullName}</span>
                  <span className="text-xs text-slate-500 block">
                    {age} Years · {gender}
                  </span>
                </div>

                <div>
                  <span className="text-slate-500 block mb-0.5">Mobile Number</span>
                  <span className="text-sm font-mono font-semibold text-slate-900">{mobileNumber}</span>
                  {email && <span className="text-xs text-slate-500 block">{email}</span>}
                </div>
              </div>

              <div className="sm:col-span-2 pt-2 border-t border-slate-200/80">
                <span className="text-slate-500 block mb-0.5">Reason for Visit</span>
                <span className="text-xs font-medium text-slate-800">
                  {reasonCategory === 'Other' && customReason ? customReason : reasonCategory}
                </span>
              </div>
            </div>
          </div>

          {/* Privacy & Arrival Notice */}
          <div className="p-3.5 bg-teal-50/60 rounded-xl border border-teal-200/60 text-xs text-teal-900 space-y-1">
            <div className="flex items-center gap-1.5 font-semibold">
              <ShieldCheck className="w-4 h-4 text-teal-700" />
              <span>Instant Confirmation & Real-time Slot Reservation</span>
            </div>
            <p className="text-[11px] text-teal-800">
              When you confirm, this slot is immediately locked on our server to prevent double-booking. Automatic confirmation will be dispatched via WhatsApp/SMS to both you and Dr. Jagadish Das.
            </p>
          </div>

          {/* Actions */}
          <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-3">
            <button
              type="button"
              disabled={isSubmitting}
              onClick={() => setCurrentStep(2)}
              className="w-full sm:w-auto px-5 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
            >
              ← Edit Details
            </button>

            <button
              type="button"
              disabled={isSubmitting}
              onClick={handleFinalBooking}
              className="w-full sm:w-auto px-8 py-3.5 text-sm font-bold text-white bg-teal-700 hover:bg-teal-800 active:bg-teal-900 rounded-xl shadow-md shadow-teal-900/10 flex items-center justify-center gap-2 transition-all"
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Confirming Appointment...</span>
                </>
              ) : (
                <>
                  <span>Confirm & Book Appointment</span>
                  <CheckCircle2 className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
