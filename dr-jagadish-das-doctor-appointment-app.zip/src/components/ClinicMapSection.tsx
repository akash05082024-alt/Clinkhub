import React from 'react';
import { MapPin, Phone, Clock, Car, Compass, ShieldCheck, Mail, AlertCircle } from 'lucide-react';
import { PublicClinicInfo } from '../types';

interface ClinicMapSectionProps {
  clinicInfo?: PublicClinicInfo | null;
  onBookClick?: () => void;
}

export const ClinicMapSection: React.FC<ClinicMapSectionProps> = ({ clinicInfo, onBookClick }) => {
  const clinic = clinicInfo?.clinic;
  const doctor = clinicInfo?.doctor;

  const fullAddress = clinic
    ? `${clinic.addressLine1}, ${clinic.addressLine2}, ${clinic.city}, ${clinic.state} - ${clinic.postalCode}`
    : 'Suite 204, 2nd Floor, Care Health Complex, Station Road, Kolkata, West Bengal - 700001';

  const mapsUrl =
    clinic?.googleMapsUrl ||
    `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
      `${clinic?.name || 'Arogya Clinic'} ${fullAddress}`
    )}`;

  return (
    <section className="py-16 bg-slate-100/70 border-y border-slate-200" id="clinic-location">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs uppercase font-bold tracking-wider text-teal-700 font-sans">
            Clinic Facility & Location
          </span>
          <h2 className="text-3xl font-serif font-bold text-slate-900 mt-1">
            Visit Our Medical Consultation Centre
          </h2>
          <p className="text-sm text-slate-600 mt-2">
            Centrally located with convenient transit access, elevator facilities, and patient parking.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Clinic Details Card - 5 Cols */}
          <div className="lg:col-span-5 bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
            <div>
              <div className="flex items-center gap-2 text-teal-700 text-xs font-semibold mb-1">
                <MapPin className="w-4 h-4" />
                <span>Primary Clinic Address</span>
              </div>
              <h3 className="text-xl font-serif font-bold text-slate-900">
                {clinic?.name || 'Arogya Health & Consultation Clinic'}
              </h3>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">{fullAddress}</p>
            </div>

            {/* Quick Actions Bar */}
            <div className="flex flex-wrap gap-2.5 pt-1">
              <a
                href={mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 min-w-[140px] py-2.5 px-4 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-sm text-center flex items-center justify-center gap-1.5 transition-colors"
              >
                <Compass className="w-4 h-4" />
                <span>Get Directions</span>
              </a>
              <a
                href={`tel:${(clinic?.phone || '+919876543210').replace(/\s+/g, '')}`}
                className="py-2.5 px-4 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl text-center flex items-center justify-center gap-1.5 transition-colors"
              >
                <Phone className="w-4 h-4 text-teal-700" />
                <span>Call Clinic</span>
              </a>
            </div>

            {/* Opening Hours Box */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-900">
                <span className="flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-teal-700" />
                  <span>Consultation Timings</span>
                </span>
                <span className="text-[11px] text-teal-700 font-semibold font-sans">Mon – Sat</span>
              </div>
              <div className="grid grid-cols-2 gap-2 pt-1 text-xs">
                <div className="bg-white p-2.5 rounded-lg border border-slate-200 text-center">
                  <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-semibold">
                    Morning Shift
                  </span>
                  <span className="font-mono font-bold text-slate-900 text-xs">10:00 AM – 01:00 PM</span>
                </div>
                <div className="bg-white p-2.5 rounded-lg border border-slate-200 text-center">
                  <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-semibold">
                    Evening Shift
                  </span>
                  <span className="font-mono font-bold text-slate-900 text-xs">05:00 PM – 08:00 PM</span>
                </div>
              </div>
              <p className="text-[11px] text-slate-500 text-center pt-0.5">
                Sunday: Clinic Closed (Hospital Emergency on Call)
              </p>
            </div>

            {/* Fee & Parking */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-500 block text-[11px] font-medium">Consultation Fee</span>
                <span className="text-lg font-bold text-slate-900 mt-0.5 block">
                  ₹{clinic?.consultationFee || 500}
                </span>
                <span className="text-[10px] text-slate-500">Per patient visit</span>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <div className="flex items-center gap-1 text-slate-500 text-[11px] font-medium">
                  <Car className="w-3.5 h-3.5 text-teal-700" />
                  <span>Parking</span>
                </div>
                <span className="text-xs font-semibold text-slate-800 mt-1 block">Basement & Street</span>
                <span className="text-[10px] text-slate-500">2 & 4 Wheelers</span>
              </div>
            </div>

            {/* Parking details note */}
            <div className="text-xs text-slate-600 bg-teal-50/50 p-3 rounded-xl border border-teal-100 flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-teal-700 shrink-0 mt-0.5" />
              <p className="text-[11px] leading-relaxed text-teal-950">
                {clinic?.parkingInfo ||
                  'Dedicated basement parking available for patients. Wheelchair ramp and elevator access to 2nd floor clinic suite.'}
              </p>
            </div>

            {/* Emergency Hotline */}
            <div className="pt-2 text-xs flex items-center justify-between text-slate-600 border-t border-slate-100">
              <span className="flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-amber-600" />
                <span>Emergency Contact:</span>
              </span>
              <a
                href={`tel:${(clinic?.emergencyPhone || '+919876543211').replace(/\s+/g, '')}`}
                className="font-mono font-bold text-slate-900 hover:text-teal-700"
              >
                {clinic?.emergencyPhone || '+91 98765 43211'}
              </a>
            </div>
          </div>

          {/* Interactive Google Maps View - 7 Cols */}
          <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-[520px]">
            {/* Map Top Bar */}
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-teal-400"></span>
                <span className="font-semibold">{clinic?.name || 'Arogya Clinic'}</span>
                <span className="text-slate-400 hidden sm:inline">· Kolkata, WB</span>
              </div>
              <a
                href={mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-teal-400 hover:text-teal-300 font-semibold flex items-center gap-1"
              >
                <span>Open in Google Maps</span>
                <span>↗</span>
              </a>
            </div>

            {/* Embedded Google Map iframe with real interactive map */}
            <div className="flex-1 w-full bg-slate-200 relative">
              <iframe
                title="Clinic Location Map"
                src={
                  clinic?.googleMapsEmbedUrl ||
                  'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d117925.21689650207!2d88.26495048220556!3d22.53556493690184!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39f882db4908f667%3A0x43e330e68f6c2cbc!2sKolkata%2C%20West%20Bengal!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin'
                }
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen={false}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="w-full h-full"
              ></iframe>

              {/* Float Map Overlay Card for quick tap on mobile */}
              <div className="absolute bottom-4 left-4 right-4 sm:right-auto sm:max-w-sm bg-white/95 backdrop-blur-md p-4 rounded-xl shadow-lg border border-slate-200 text-xs space-y-2">
                <div className="font-bold text-slate-900 flex items-center justify-between">
                  <span>{clinic?.name || 'Arogya Health Clinic'}</span>
                  <span className="text-[10px] text-emerald-800 bg-emerald-100 font-semibold px-2 py-0.5 rounded">
                    Open Mon-Sat
                  </span>
                </div>
                <p className="text-slate-600 text-[11px] leading-snug">{fullAddress}</p>
                <div className="pt-1 flex items-center gap-2">
                  <a
                    href={mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 py-1.5 px-3 bg-teal-700 hover:bg-teal-800 text-white rounded-lg font-semibold text-center text-[11px] transition-colors"
                  >
                    Start Navigation
                  </a>
                  {onBookClick && (
                    <button
                      type="button"
                      onClick={onBookClick}
                      className="py-1.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg font-semibold text-[11px] transition-colors"
                    >
                      Book Slot
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
