import React, { useState } from 'react';
import {
  CheckCircle2,
  Calendar,
  Clock,
  MapPin,
  Phone,
  User,
  Download,
  AlertTriangle,
  XCircle,
  ExternalLink,
  Printer,
  ChevronLeft,
  MessageSquare
} from 'lucide-react';
import { Appointment, PublicClinicInfo } from '../types';
import { api, downloadIcsFile, generateGoogleCalendarUrl } from '../api';

interface ConfirmationViewProps {
  appointment: Appointment;
  clinicInfo?: PublicClinicInfo | null;
  onBookAnother: () => void;
  onAppointmentUpdated?: (updated: Appointment) => void;
}

export const ConfirmationView: React.FC<ConfirmationViewProps> = ({
  appointment,
  clinicInfo,
  onBookAnother,
  onAppointmentUpdated
}) => {
  const [currentAppt, setCurrentAppt] = useState<Appointment>(appointment);
  const [showCancelModal, setShowCancelModal] = useState<boolean>(false);
  const [cancelReason, setCancelReason] = useState<string>('');
  const [isCancelling, setIsCancelling] = useState<boolean>(false);
  const [cancelError, setCancelError] = useState<string | null>(null);

  const doctorName = clinicInfo?.doctor.name || 'Dr. Jagadish Das';
  const doctorDegree = clinicInfo?.doctor.degrees || 'MBBS';
  const clinicName = clinicInfo?.clinic.name || 'Arogya Health & Consultation Clinic';
  const clinicAddress = clinicInfo
    ? `${clinicInfo.clinic.addressLine1}, ${clinicInfo.clinic.addressLine2}, ${clinicInfo.clinic.city} - ${clinicInfo.clinic.postalCode}`
    : 'Suite 204, Care Health Complex, Station Road, Kolkata - 700001';
  const clinicPhone = clinicInfo?.clinic.phone || '+91 98765 43210';
  const mapsUrl = clinicInfo?.clinic.googleMapsUrl || 'https://maps.google.com';

  const handleCancel = async () => {
    setIsCancelling(true);
    setCancelError(null);
    try {
      const res = await api.cancelAppointment(currentAppt.appointment_id, cancelReason);
      setCurrentAppt(res.appointment);
      if (onAppointmentUpdated) onAppointmentUpdated(res.appointment);
      setShowCancelModal(false);
    } catch (err: unknown) {
      setCancelError(err instanceof Error ? err.message : 'Failed to cancel appointment');
    } finally {
      setIsCancelling(false);
    }
  };

  const isCancelled = currentAppt.status === 'CANCELLED';

  return (
    <div className="max-w-3xl mx-auto py-8 px-4 sm:px-6">
      {/* Printable Receipt Area */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden" id="appointment-receipt">
        {/* Top Status Header */}
        <div
          className={`p-6 sm:p-8 text-center border-b ${
            isCancelled ? 'bg-rose-50 border-rose-200' : 'bg-teal-50/70 border-teal-100'
          }`}
        >
          {isCancelled ? (
            <div className="w-16 h-16 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mx-auto mb-3 shadow-inner">
              <XCircle className="w-9 h-9" />
            </div>
          ) : (
            <div className="w-16 h-16 bg-teal-100 text-teal-700 rounded-full flex items-center justify-center mx-auto mb-3 shadow-inner">
              <CheckCircle2 className="w-9 h-9" />
            </div>
          )}

          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-slate-900">
            {isCancelled ? 'Appointment Cancelled' : 'Appointment booked successfully.'}
          </h2>

          <p className="text-sm text-slate-600 mt-1 max-w-md mx-auto">
            {isCancelled
              ? `Appointment ${currentAppt.appointment_id} has been marked as cancelled.`
              : `Your consultation slot is locked. An instant confirmation has been queued for your mobile number.`}
          </p>

          <div className="mt-4 inline-flex items-center gap-2 px-4 py-1.5 bg-white border border-slate-200 rounded-lg shadow-2xs font-mono text-sm">
            <span className="text-slate-500 font-sans text-xs">Appointment ID:</span>
            <span className="font-bold text-teal-800">{currentAppt.appointment_id}</span>
          </div>
        </div>

        {/* Appointment Key Facts Grid */}
        <div className="p-6 sm:p-8 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            {/* Doctor */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
              <div className="flex items-center gap-2 text-slate-500 mb-1">
                <User className="w-3.5 h-3.5 text-teal-600" />
                <span className="font-semibold uppercase tracking-wider text-[10px]">Consulting Doctor</span>
              </div>
              <p className="text-base font-bold text-slate-900 font-serif">
                {doctorName} ({doctorDegree})
              </p>
              <p className="text-xs text-teal-700 font-medium mt-0.5">
                {clinicInfo?.doctor.specialization || 'Consultant Physician'}
              </p>
              <p className="text-[11px] text-slate-500 mt-1">
                Reg: {clinicInfo?.doctor.registrationNumber || 'WBMC-64821'}
              </p>
            </div>

            {/* Patient */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
              <div className="flex items-center gap-2 text-slate-500 mb-1">
                <User className="w-3.5 h-3.5 text-teal-600" />
                <span className="font-semibold uppercase tracking-wider text-[10px]">Patient Details</span>
              </div>
              <p className="text-base font-bold text-slate-900">{currentAppt.patient_name}</p>
              <p className="text-xs text-slate-600 mt-0.5">
                {currentAppt.patient_age} Years · {currentAppt.patient_gender}
              </p>
              <p className="text-xs font-mono text-slate-600 mt-1">
                Mobile: {currentAppt.patient_phone}
              </p>
            </div>

            {/* Date & Time */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
              <div className="flex items-center gap-2 text-slate-500 mb-1">
                <Calendar className="w-3.5 h-3.5 text-teal-600" />
                <span className="font-semibold uppercase tracking-wider text-[10px]">Date & Time</span>
              </div>
              <p className="text-base font-bold text-teal-950 font-mono">
                {new Date(currentAppt.appointment_date).toLocaleDateString('en-US', {
                  weekday: 'short',
                  year: 'numeric',
                  month: 'short',
                  day: 'numeric'
                })}
              </p>
              <p className="text-sm font-bold text-teal-800 font-mono mt-0.5">
                {currentAppt.appointment_time}
              </p>
              <p className="text-[11px] text-slate-500 mt-1">
                Status: <strong className={isCancelled ? 'text-rose-600' : 'text-emerald-700'}>{currentAppt.status}</strong>
              </p>
            </div>

            {/* Clinic & Fee */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
              <div className="flex items-center gap-2 text-slate-500 mb-1">
                <MapPin className="w-3.5 h-3.5 text-teal-600" />
                <span className="font-semibold uppercase tracking-wider text-[10px]">Clinic & Fee</span>
              </div>
              <p className="text-xs font-bold text-slate-900">{clinicName}</p>
              <p className="text-[11px] text-slate-600 mt-0.5 leading-snug">{clinicAddress}</p>
              <p className="text-xs font-semibold text-slate-800 mt-1.5">
                Consultation Fee: ₹{clinicInfo?.clinic.consultationFee || 500}
              </p>
            </div>
          </div>

          {/* Reason for Consultation */}
          <div className="p-3.5 rounded-xl bg-white border border-slate-200 text-xs">
            <span className="text-slate-500 font-semibold block mb-0.5">Reason for Visit:</span>
            <span className="text-slate-800 font-medium">{currentAppt.reason}</span>
          </div>

          {/* Patient Instruction Card */}
          {!isCancelled && (
            <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200 text-xs text-amber-900 space-y-1">
              <p className="font-semibold flex items-center gap-1.5 text-amber-950">
                <Clock className="w-4 h-4 text-amber-700" />
                <span>Important Patient Instructions:</span>
              </p>
              <ul className="list-disc pl-5 space-y-1 text-amber-900/90 text-[11px]">
                <li>Please arrive 10–15 minutes before your scheduled appointment time.</li>
                <li>Carry any previous prescriptions, doctor discharge summaries, or recent laboratory test reports.</li>
                <li>Wear a face mask if you are suffering from cold, acute cough, or fever.</li>
              </ul>
            </div>
          )}

          {/* 4 Required Action Buttons (as requested) */}
          <div className="pt-4 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 no-print">
            {/* 1. Add to Calendar */}
            <div className="relative group">
              <button
                type="button"
                onClick={() => downloadIcsFile(currentAppt, clinicAddress)}
                disabled={isCancelled}
                className={`w-full py-2.5 px-3 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1.5 transition-all ${
                  isCancelled
                    ? 'border-slate-200 text-slate-400 cursor-not-allowed'
                    : 'border-slate-300 bg-white text-slate-800 hover:bg-slate-50 hover:border-slate-400'
                }`}
              >
                <Calendar className="w-4 h-4 text-teal-600" />
                <span>Add to Calendar</span>
              </button>
              {!isCancelled && (
                <a
                  href={generateGoogleCalendarUrl(currentAppt, clinicAddress)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block text-center text-[10px] text-teal-700 hover:underline mt-1"
                >
                  or Google Calendar ↗
                </a>
              )}
            </div>

            {/* 2. Call Clinic */}
            <a
              href={`tel:${clinicPhone.replace(/\s+/g, '')}`}
              className="py-2.5 px-3 rounded-xl text-xs font-semibold border border-slate-300 bg-white text-slate-800 hover:bg-slate-50 hover:border-slate-400 flex items-center justify-center gap-1.5 transition-all text-center"
            >
              <Phone className="w-4 h-4 text-teal-600" />
              <span>Call Clinic</span>
            </a>

            {/* 3. Get Directions */}
            <a
              href={mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="py-2.5 px-3 rounded-xl text-xs font-semibold border border-slate-300 bg-white text-slate-800 hover:bg-slate-50 hover:border-slate-400 flex items-center justify-center gap-1.5 transition-all text-center"
            >
              <MapPin className="w-4 h-4 text-teal-600" />
              <span>Get Directions</span>
            </a>

            {/* 4. Cancel Appointment */}
            <button
              type="button"
              disabled={isCancelled}
              onClick={() => setShowCancelModal(true)}
              className={`py-2.5 px-3 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1.5 transition-all ${
                isCancelled
                  ? 'border-slate-200 bg-slate-100 text-slate-400 cursor-not-allowed'
                  : 'border-rose-200 bg-white text-rose-700 hover:bg-rose-50'
              }`}
            >
              <XCircle className="w-4 h-4 text-rose-600" />
              <span>Cancel Appointment</span>
            </button>
          </div>

          {/* Secondary Action Bar: Print & Book Another */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs no-print">
            <button
              type="button"
              onClick={() => window.print()}
              className="text-slate-600 hover:text-slate-900 flex items-center gap-1.5 font-medium py-1 px-2 rounded"
            >
              <Printer className="w-4 h-4" />
              <span>Print Appointment Slip</span>
            </button>

            <button
              type="button"
              onClick={onBookAnother}
              className="font-semibold text-teal-700 hover:text-teal-800 flex items-center gap-1"
            >
              <span>+ Book Another Appointment</span>
            </button>
          </div>
        </div>
      </div>

      {/* Cancel Confirmation Modal */}
      {showCancelModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-xl border border-slate-200">
            <div className="flex items-center gap-3 text-rose-600">
              <AlertTriangle className="w-6 h-6 shrink-0" />
              <h3 className="text-lg font-bold text-slate-900">Cancel Appointment?</h3>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Are you sure you want to cancel appointment{' '}
              <strong className="font-mono text-slate-900">{currentAppt.appointment_id}</strong> scheduled for{' '}
              <strong className="text-slate-900">
                {currentAppt.appointment_date} at {currentAppt.appointment_time}
              </strong>
              ? This slot will immediately be made available to other patients.
            </p>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Reason for cancellation (Optional)
              </label>
              <input
                type="text"
                placeholder="e.g. Schedule conflict, feeling better"
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-500"
              />
            </div>

            {cancelError && <p className="text-xs text-rose-600">{cancelError}</p>}

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                disabled={isCancelling}
                onClick={() => setShowCancelModal(false)}
                className="px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-lg"
              >
                Keep Appointment
              </button>
              <button
                type="button"
                disabled={isCancelling}
                onClick={handleCancel}
                className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-sm"
              >
                {isCancelling ? 'Cancelling...' : 'Yes, Cancel Appointment'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
