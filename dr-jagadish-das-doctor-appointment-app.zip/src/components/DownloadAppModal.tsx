import React, { useState } from 'react';
import {
  Download,
  Smartphone,
  Laptop,
  CheckCircle2,
  FileCode2,
  ExternalLink,
  X,
  Share2,
  PlusSquare,
  Sparkles,
  ArrowRight,
  Terminal
} from 'lucide-react';
import { usePWAInstall } from './usePWAInstall';

interface DownloadAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadAppModal: React.FC<DownloadAppModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [installedSuccess, setInstalledSuccess] = useState(false);

  if (!isOpen) return null;

  const handleInstallPWA = async () => {
    const success = await install();
    if (success) {
      setInstalledSuccess(true);
      setTimeout(() => {
        onClose();
      }, 2000);
    }
  };

  const handleDownloadZip = () => {
    setDownloadingZip(true);
    // Trigger download of zip
    window.location.href = '/api/download/source-code';
    setTimeout(() => {
      setDownloadingZip(false);
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-slate-200 relative animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-slate-700 p-1.5 rounded-full hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center space-y-1.5">
          <div className="w-12 h-12 bg-teal-50 text-teal-700 rounded-2xl flex items-center justify-center mx-auto shadow-2xs">
            <Download className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-serif font-bold text-slate-900">
            Download Dr. Jagadish Das Clinic App
          </h2>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Choose whether to install the app onto your mobile phone/computer, or download the full source code (.ZIP) to run locally.
          </p>
        </div>

        {/* Option 1: Install as Mobile / Desktop App (PWA) */}
        <div className="p-5 rounded-2xl bg-gradient-to-br from-teal-50/80 to-cyan-50/50 border border-teal-200/80 space-y-3">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-teal-600 text-white">
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Option 1: Install App on Device (Mobile & Desktop)
                </h3>
                <p className="text-[11px] text-teal-900">
                  Fast, standalone app experience with custom doctor icon on your home screen.
                </p>
              </div>
            </div>
          </div>

          <div className="pt-1">
            {isInstalled || installedSuccess ? (
              <div className="p-3 bg-emerald-100/70 border border-emerald-300 rounded-xl text-xs text-emerald-900 flex items-center gap-2 font-medium">
                <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>The clinic application is already installed on your device!</span>
              </div>
            ) : isInstallable ? (
              <button
                type="button"
                onClick={handleInstallPWA}
                className="w-full py-3 px-4 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-bold shadow-sm transition-all flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>Install Application Now (1-Click)</span>
              </button>
            ) : isIOS ? (
              <div className="p-3 bg-white border border-teal-200 rounded-xl text-xs text-slate-700 space-y-1.5">
                <span className="font-bold text-slate-900 block flex items-center gap-1.5">
                  <Share2 className="w-3.5 h-3.5 text-teal-700" />
                  <span>How to install on iPhone & iPad:</span>
                </span>
                <ol className="list-decimal pl-4 space-y-1 text-[11px] text-slate-600">
                  <li>Tap the <strong>Share</strong> icon in the Safari bottom toolbar.</li>
                  <li>Scroll down and tap <strong>"Add to Home Screen"</strong>.</li>
                  <li>Tap <strong>Add</strong> at top right. The Doctor Appointment App icon will appear on your phone!</li>
                </ol>
              </div>
            ) : (
              <div className="p-3 bg-white border border-teal-200 rounded-xl text-xs text-slate-700 space-y-1">
                <span className="font-bold text-slate-900 block">Direct Browser Installation:</span>
                <p className="text-[11px] text-slate-600">
                  In Chrome or Edge, click the <strong>Install App icon (⊕)</strong> located on the right side of the address bar, or open the browser menu (⋮) → <strong>"Install Dr. Jagadish Das Clinic"</strong>.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Option 2: Download Full Source Code (.ZIP) */}
        <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-slate-800 text-white">
                <FileCode2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Option 2: Download Full Source Code (.ZIP)
                </h3>
                <p className="text-[11px] text-slate-500">
                  Includes complete React + Vite frontend, Express backend server, database, and setup docs.
                </p>
              </div>
            </div>
          </div>

          <p className="text-[11px] text-slate-600 leading-relaxed">
            Extract the archive to any folder on your computer. Run <code className="bg-white px-1.5 py-0.5 rounded border border-slate-200 font-mono text-[10px]">npm install</code> followed by <code className="bg-white px-1.5 py-0.5 rounded border border-slate-200 font-mono text-[10px]">npm run dev</code> to run the full application locally at <code className="bg-white px-1.5 py-0.5 rounded border border-slate-200 font-mono text-[10px]">http://localhost:3000</code>.
          </p>

          <button
            type="button"
            disabled={downloadingZip}
            onClick={handleDownloadZip}
            className="w-full py-3 px-4 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-sm transition-all flex items-center justify-center gap-2"
          >
            {downloadingZip ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                <span>Preparing Source Archive...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4 text-teal-400" />
                <span>Download Project Code (.ZIP Archive)</span>
              </>
            )}
          </button>
        </div>

        {/* Quick run instruction footer */}
        <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
          <span className="flex items-center gap-1 font-mono">
            <Terminal className="w-3.5 h-3.5 text-slate-400" />
            <span>npm install && npm run dev</span>
          </span>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-600 hover:text-slate-900 font-medium"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
