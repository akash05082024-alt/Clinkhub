import React from 'react';
import { Stethoscope, MapPin, Phone, Mail, Clock, ShieldCheck, Heart } from 'lucide-react';
import { PublicClinicInfo } from '../types';

interface FooterProps {
  clinicInfo?: PublicClinicInfo | null;
  onNavigate: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ clinicInfo, onNavigate }) => {
  const doctor = clinicInfo?.doctor;
  const clinic = clinicInfo?.clinic;

  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Column 1: Doctor & Clinic Summary */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-teal-600 flex items-center justify-center text-white">
                <Stethoscope className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-white font-serif text-lg font-bold">
                  {doctor?.name || 'Dr. Jagadish Das'}
                </h3>
                <p className="text-xs text-teal-400 font-medium tracking-wide">
                  {doctor?.degrees || 'MBBS'} · {doctor?.specialization || 'Consultant Physician'}
                </p>
              </div>
            </div>
            <p className="text-xs leading-relaxed text-slate-400">
              {clinic?.tagline ||
                'Providing compassionate, ethical, and evidence-based clinical primary care with a dedicated patient-first focus.'}
            </p>
            <div className="pt-1 text-xs text-slate-400 space-y-1">
              <p>
                <span className="text-slate-500 font-medium">Council Reg. No:</span>{' '}
                <span className="text-slate-300 font-mono">{doctor?.registrationNumber || 'WBMC-64821'}</span>
              </p>
              <p>
                <span className="text-slate-500 font-medium">Affiliation:</span>{' '}
                <span className="text-slate-300">{doctor?.registrationCouncil || 'West Bengal Medical Council'}</span>
              </p>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div className="space-y-3">
            <h4 className="text-sm font-semibold text-white tracking-wider uppercase font-sans">
              Navigation
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => onNavigate('home')}
                  className="hover:text-teal-400 transition-colors"
                >
                  Home Page
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('profile')}
                  className="hover:text-teal-400 transition-colors"
                >
                  Doctor Profile & Credentials
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('services')}
                  className="hover:text-teal-400 transition-colors"
                >
                  Medical Services
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('clinic')}
                  className="hover:text-teal-400 transition-colors"
                >
                  Clinic Location & Parking
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('book')}
                  className="text-teal-400 font-semibold hover:underline"
                >
                  Book Appointment Online →
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('admin-login')}
                  className="text-slate-400 hover:text-slate-200"
                >
                  Doctor Portal Login
                </button>
              </li>
              <li>
                <a
                  href="/api/download/source-code"
                  className="text-teal-400 hover:text-teal-300 font-medium inline-flex items-center gap-1"
                >
                  <span>Download App Code (.ZIP)</span>
                  <span>↓</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Column 3: Consultation Timings */}
          <div className="space-y-3">
            <h4 className="text-sm font-semibold text-white tracking-wider uppercase font-sans flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-teal-400" />
              <span>Consultation Hours</span>
            </h4>
            <div className="text-xs space-y-2.5 text-slate-300">
              <div className="border-l-2 border-teal-500 pl-3 py-0.5">
                <p className="font-semibold text-white">Monday – Saturday</p>
                <p className="text-slate-400">Morning: 10:00 AM – 1:00 PM</p>
                <p className="text-slate-400">Evening: 05:00 PM – 8:00 PM</p>
              </div>
              <div className="border-l-2 border-slate-700 pl-3 py-0.5">
                <p className="font-semibold text-slate-400">Sunday</p>
                <p className="text-slate-500">Clinic Closed (Emergencies via Hospital)</p>
              </div>
              <p className="text-[11px] text-slate-400 pt-1">
                Consultation Fee: ₹{clinic?.consultationFee || 500} per visit
              </p>
            </div>
          </div>

          {/* Column 4: Clinic Contact & Directions */}
          <div className="space-y-3">
            <h4 className="text-sm font-semibold text-white tracking-wider uppercase font-sans flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-teal-400" />
              <span>Clinic Location</span>
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              {clinic?.name || 'Arogya Health & Consultation Clinic'}
              <br />
              {clinic?.addressLine1 || 'Suite 204, Care Health Complex'}
              <br />
              {clinic?.addressLine2 || 'Station Road'}
              <br />
              {clinic?.city || 'Kolkata'}, {clinic?.state || 'West Bengal'} - {clinic?.postalCode || '700001'}
            </p>
            <div className="space-y-1.5 text-xs pt-1">
              <a
                href={`tel:${(clinic?.phone || '+919876543210').replace(/\s+/g, '')}`}
                className="flex items-center gap-2 hover:text-teal-400 transition-colors"
              >
                <Phone className="w-3.5 h-3.5 text-teal-400" />
                <span>{clinic?.phone || '+91 98765 43210'}</span>
              </a>
              <a
                href={`mailto:${clinic?.email || 'care@drjagadishdas.com'}`}
                className="flex items-center gap-2 hover:text-teal-400 transition-colors"
              >
                <Mail className="w-3.5 h-3.5 text-teal-400" />
                <span>{clinic?.email || 'care@drjagadishdas.com'}</span>
              </a>
            </div>
            <div className="pt-2">
              <a
                href={clinic?.googleMapsUrl || 'https://maps.google.com'}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-teal-300 bg-slate-800 border border-slate-700 rounded-md hover:bg-slate-700 transition-colors"
              >
                <span>Get Directions in Google Maps</span>
                <span>↗</span>
              </a>
            </div>
          </div>
        </div>

        {/* Emergency Disclaimer Banner */}
        <div className="mt-12 pt-6 border-t border-slate-800/80 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
            <p>
              <strong className="text-slate-200">Emergency Notice:</strong> This appointment system is intended for scheduled, non-life-threatening clinical outpatient visits. In case of acute cardiac emergency, severe breathlessness, trauma, or severe hemorrhage, please call 112 / 102 or proceed immediately to the nearest hospital casualty emergency room.
            </p>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="mt-8 pt-4 border-t border-slate-800 text-center text-xs text-slate-400 flex flex-col sm:flex-row justify-between items-center gap-2">
          <p>© {new Date().getFullYear()} Dr. Jagadish Das (MBBS). All rights reserved.</p>
          <p className="flex items-center gap-1 text-slate-400">
            <span>Official Clinical Appointment Booking Portal</span>
            <span aria-hidden="true">·</span>
            <span className="text-teal-400">HIPAA & Privacy Conscious</span>
          </p>
        </div>
      </div>
    </footer>
  );
};
