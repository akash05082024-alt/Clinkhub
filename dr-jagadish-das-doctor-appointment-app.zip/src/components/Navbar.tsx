import React, { useState } from 'react';
import { Stethoscope, Calendar, Phone, Menu, X, Shield, User, Download } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { PublicClinicInfo } from '../types';
import { DownloadAppModal } from './DownloadAppModal';

interface NavbarProps {
  currentTab: string;
  onNavigate: (tab: string, appointmentId?: string) => void;
  clinicInfo?: PublicClinicInfo | null;
}

export const Navbar: React.FC<NavbarProps> = ({ currentTab, onNavigate, clinicInfo }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [downloadModalOpen, setDownloadModalOpen] = useState(false);
  const { isAuthenticated, user } = useAuth();

  const handleNav = (tab: string) => {
    onNavigate(tab);
    setMobileMenuOpen(false);
  };

  const doctorName = clinicInfo?.doctor.name || 'Dr. Jagadish Das';
  const degrees = clinicInfo?.doctor.degrees || 'MBBS';
  const clinicPhone = clinicInfo?.clinic.phone || '+91 98765 43210';

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 transition-all">
      {/* Top quick-bar for emergency / quick phone */}
      <div className="bg-slate-900 text-slate-300 text-xs py-1.5 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-2">
          <div className="flex items-center gap-2">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-400"></span>
            <span className="font-medium text-slate-200">Consultation Timings:</span>
            <span>Mon–Sat 10:00 AM – 1:00 PM & 5:00 PM – 8:00 PM</span>
          </div>
          <div className="flex items-center gap-4 text-slate-300">
            <a
              href={`tel:${clinicPhone.replace(/\s+/g, '')}`}
              className="flex items-center gap-1.5 hover:text-white transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-teal-400" />
              <span>Clinic: {clinicPhone}</span>
            </a>
            <span className="hidden md:inline text-slate-600">|</span>
            <span className="hidden md:inline text-slate-400">Kolkata, West Bengal</span>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Brand Identity */}
          <button
            onClick={() => handleNav('home')}
            className="flex items-center gap-3.5 text-left focus:outline-none group"
          >
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-teal-600 to-cyan-700 flex items-center justify-center text-white shadow-sm shadow-teal-700/20 group-hover:scale-105 transition-transform">
              <Stethoscope className="w-6 h-6 stroke-[2.2]" />
            </div>
            <div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-xl font-bold tracking-tight text-slate-900 font-serif group-hover:text-teal-700 transition-colors">
                  {doctorName}
                </span>
                <span className="text-sm font-semibold text-teal-700 font-sans tracking-wide">
                  ({degrees})
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium tracking-normal">
                {clinicInfo?.clinic.name || 'Arogya Health & Consultation Clinic'}
              </p>
            </div>
          </button>

          {/* Desktop Nav Items */}
          <nav className="hidden md:flex items-center gap-8">
            <button
              onClick={() => handleNav('home')}
              className={`text-sm font-medium transition-colors hover:text-teal-700 ${
                currentTab === 'home' ? 'text-teal-700 font-semibold' : 'text-slate-600'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => handleNav('profile')}
              className={`text-sm font-medium transition-colors hover:text-teal-700 ${
                currentTab === 'profile' ? 'text-teal-700 font-semibold' : 'text-slate-600'
              }`}
            >
              Doctor Profile
            </button>
            <button
              onClick={() => handleNav('services')}
              className={`text-sm font-medium transition-colors hover:text-teal-700 ${
                currentTab === 'services' ? 'text-teal-700 font-semibold' : 'text-slate-600'
              }`}
            >
              Services
            </button>
            <button
              onClick={() => handleNav('clinic')}
              className={`text-sm font-medium transition-colors hover:text-teal-700 ${
                currentTab === 'clinic' ? 'text-teal-700 font-semibold' : 'text-slate-600'
              }`}
            >
              Clinic & Location
            </button>
            <button
              onClick={() => handleNav('my-appointment')}
              className={`text-sm font-medium transition-colors hover:text-teal-700 ${
                currentTab === 'my-appointment' ? 'text-teal-700 font-semibold' : 'text-slate-600'
              }`}
            >
              Find Booking
            </button>
          </nav>

          {/* Right Action Buttons */}
          <div className="hidden md:flex items-center gap-3">
            {/* Download App CTA */}
            <button
              type="button"
              onClick={() => setDownloadModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 hover:text-teal-800 hover:bg-teal-50 border border-slate-300 rounded-lg transition-colors"
              title="Download App as PWA or Source Code (.ZIP)"
            >
              <Download className="w-3.5 h-3.5 text-teal-700" />
              <span>Download App</span>
            </button>

            {isAuthenticated ? (
              <button
                onClick={() => handleNav('admin')}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-teal-800 bg-teal-50 border border-teal-200/80 rounded-lg hover:bg-teal-100 transition-colors"
              >
                <Shield className="w-3.5 h-3.5 text-teal-700" />
                <span>Doctor Portal</span>
              </button>
            ) : (
              <button
                onClick={() => handleNav('admin-login')}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 transition-colors"
                title="Doctor Admin Access"
              >
                <User className="w-3.5 h-3.5 text-slate-500" />
                <span>Doctor Login</span>
              </button>
            )}

            <button
              onClick={() => handleNav('book')}
              className="flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-teal-700 hover:bg-teal-800 active:bg-teal-900 rounded-lg shadow-sm shadow-teal-900/10 transition-all hover:shadow"
            >
              <Calendar className="w-4 h-4" />
              <span>Book Appointment</span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              type="button"
              onClick={() => setDownloadModalOpen(true)}
              className="p-2 text-slate-600 hover:text-teal-700 hover:bg-slate-100 rounded-lg"
              title="Download App"
            >
              <Download className="w-5 h-5 text-teal-700" />
            </button>
            <button
              onClick={() => handleNav('book')}
              className="px-3 py-2 text-xs font-semibold text-white bg-teal-700 rounded-lg"
            >
              Book
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-lg focus:outline-none"
              aria-label="Toggle navigation"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-3 shadow-lg">
          <button
            onClick={() => handleNav('home')}
            className="w-full text-left py-2 text-base font-medium text-slate-800 border-b border-slate-100"
          >
            Home
          </button>
          <button
            onClick={() => handleNav('profile')}
            className="w-full text-left py-2 text-base font-medium text-slate-800 border-b border-slate-100"
          >
            Doctor Profile
          </button>
          <button
            onClick={() => handleNav('services')}
            className="w-full text-left py-2 text-base font-medium text-slate-800 border-b border-slate-100"
          >
            Services Offered
          </button>
          <button
            onClick={() => handleNav('clinic')}
            className="w-full text-left py-2 text-base font-medium text-slate-800 border-b border-slate-100"
          >
            Clinic Details & Map
          </button>
          <button
            onClick={() => handleNav('my-appointment')}
            className="w-full text-left py-2 text-base font-medium text-slate-800 border-b border-slate-100"
          >
            Lookup Booking by ID
          </button>
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              setDownloadModalOpen(true);
            }}
            className="w-full text-left py-2 text-base font-semibold text-teal-800 border-b border-slate-100 flex items-center justify-between"
          >
            <span>Download / Install App</span>
            <Download className="w-4 h-4 text-teal-700" />
          </button>
          <div className="pt-2 flex flex-col gap-2">
            <button
              onClick={() => handleNav('book')}
              className="w-full py-3 text-center text-sm font-semibold text-white bg-teal-700 rounded-lg shadow"
            >
              Book Appointment Online
            </button>
            {isAuthenticated ? (
              <button
                onClick={() => handleNav('admin')}
                className="w-full py-2.5 text-center text-sm font-medium text-teal-800 bg-teal-50 border border-teal-200 rounded-lg"
              >
                Go to Doctor Admin ({user?.fullName || 'Doctor'})
              </button>
            ) : (
              <button
                onClick={() => handleNav('admin-login')}
                className="w-full py-2.5 text-center text-sm font-medium text-slate-700 border border-slate-300 rounded-lg"
              >
                Doctor Admin Login
              </button>
            )}
          </div>
        </div>
      )}

      {/* Download App Modal */}
      <DownloadAppModal
        isOpen={downloadModalOpen}
        onClose={() => setDownloadModalOpen(false)}
      />
    </header>
  );
};
