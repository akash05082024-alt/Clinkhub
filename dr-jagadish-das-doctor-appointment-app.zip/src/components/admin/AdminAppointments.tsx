import React, { useState, useEffect } from 'react';
import {
  Search,
  Filter,
  Calendar,
  Clock,
  CheckCircle2,
  XCircle,
  Edit,
  Eye,
  FileText,
  AlertCircle,
  Phone,
  User,
  ArrowUpDown,
  RefreshCw,
  Plus
} from 'lucide-react';
import { api } from '../../api';
import { Appointment, AppointmentStatus } from '../../types';

interface AdminAppointmentsProps {
  initialDate?: string;
  initialStatus?: string;
  onOpenNewModal: () => void;
}

export const AdminAppointments: React.FC<AdminAppointmentsProps> = ({
  initialDate,
  initialStatus,
  onOpenNewModal
}) => {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDate, setSelectedDate] = useState<string>(initialDate || '');
  const [selectedStatus, setSelectedStatus] = useState<string>(initialStatus || 'ALL');

  // Modals
  const [detailsModalAppt, setDetailsModalAppt] = useState<Appointment | null>(null);
  const [notesModalAppt, setNotesModalAppt] = useState<Appointment | null>(null);
  const [notesInput, setNotesInput] = useState('');
  const [rescheduleAppt, setRescheduleAppt] = useState<Appointment | null>(null);
  const [rescheduleDate, setRescheduleDate] = useState('');
  const [rescheduleTime, setRescheduleTime] = useState('');
  const [rescheduleError, setRescheduleError] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const fetchAppointments = async () => {
    setLoading(true);
    try {
      const data = await api.getAppointments({
        date: selectedDate || undefined,
        status: selectedStatus !== 'ALL' ? selectedStatus : undefined,
        search: searchTerm || undefined
      });
      setAppointments(data.appointments || []);
    } catch (err) {
      console.error('Failed to fetch appointments:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, [selectedDate, selectedStatus]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchAppointments();
  };

  const handleStatusChange = async (id: string, newStatus: AppointmentStatus) => {
    try {
      const res = await api.updateAppointmentStatus(id, newStatus);
      setAppointments((prev) =>
        prev.map((a) => (a.appointment_id === id ? res.appointment : a))
      );
      if (detailsModalAppt?.appointment_id === id) {
        setDetailsModalAppt(res.appointment);
      }
    } catch (err: unknown) {
      alert(err instanceof Error ? err.message : 'Status update failed');
    }
  };

  const handleSaveNotes = async () => {
    if (!notesModalAppt) return;
    setIsProcessing(true);
    try {
      const res = await api.updateDoctorNotes(notesModalAppt.appointment_id, notesInput);
      setAppointments((prev) =>
        prev.map((a) => (a.appointment_id === notesModalAppt.appointment_id ? res.appointment : a))
      );
      setNotesModalAppt(null);
    } catch (err: unknown) {
      alert(err instanceof Error ? err.message : 'Failed to save notes');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleConfirmReschedule = async () => {
    if (!rescheduleAppt || !rescheduleDate || !rescheduleTime) {
      setRescheduleError('Please select both a new date and a new time.');
      return;
    }
    setIsProcessing(true);
    setRescheduleError(null);
    try {
      const res = await api.rescheduleAppointment(rescheduleAppt.appointment_id, rescheduleDate, rescheduleTime);
      setAppointments((prev) =>
        prev.map((a) => (a.appointment_id === rescheduleAppt.appointment_id ? res.appointment : a))
      );
      setRescheduleAppt(null);
    } catch (err: unknown) {
      setRescheduleError(err instanceof Error ? err.message : 'Reschedule failed');
    } finally {
      setIsProcessing(false);
    }
  };

  const todayStr = new Date().toISOString().split('T')[0];

  return (
    <div className="space-y-6">
      {/* Header and Controls */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <span className="text-xs uppercase font-bold tracking-wider text-teal-700 font-sans">
            Clinic Schedules
          </span>
          <h2 className="text-2xl font-serif font-bold text-slate-900 mt-0.5">
            Appointment Management
          </h2>
          <p className="text-xs text-slate-500">
            Total {appointments.length} appointments match current filter
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onOpenNewModal}
            className="px-4 py-2 text-xs font-bold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-sm flex items-center gap-1.5 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>+ Book Patient</span>
          </button>
          <button
            type="button"
            onClick={fetchAppointments}
            className="p-2 text-slate-500 hover:text-slate-800 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors"
            title="Refresh list"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-teal-700' : ''}`} />
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
        <form onSubmit={handleSearchSubmit} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-3">
          {/* Search query: patient name or phone or ID */}
          <div className="lg:col-span-5 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              placeholder="Search by patient name, mobile, or APT ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-600"
            />
          </div>

          {/* Quick Date Presets */}
          <div className="lg:col-span-3 flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setSelectedDate(todayStr)}
              className={`flex-1 py-2 px-2 text-xs rounded-xl font-medium border text-center transition-colors ${
                selectedDate === todayStr
                  ? 'bg-teal-700 text-white border-teal-800 font-semibold'
                  : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              Today
            </button>
            <button
              type="button"
              onClick={() => setSelectedDate('')}
              className={`flex-1 py-2 px-2 text-xs rounded-xl font-medium border text-center transition-colors ${
                selectedDate === ''
                  ? 'bg-teal-700 text-white border-teal-800 font-semibold'
                  : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              All Dates
            </button>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="py-1.5 px-2 text-xs border border-slate-200 rounded-xl bg-slate-50 text-slate-700 focus:bg-white focus:outline-none"
            />
          </div>

          {/* Status Filter */}
          <div className="lg:col-span-3">
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full py-2 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-600 text-slate-700 font-medium"
            >
              <option value="ALL">All Statuses</option>
              <option value="PENDING">PENDING</option>
              <option value="CONFIRMED">CONFIRMED</option>
              <option value="COMPLETED">COMPLETED</option>
              <option value="CANCELLED">CANCELLED</option>
              <option value="NO-SHOW">NO-SHOW</option>
            </select>
          </div>

          {/* Search trigger */}
          <div className="lg:col-span-1">
            <button
              type="submit"
              className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold"
            >
              Filter
            </button>
          </div>
        </form>
      </div>

      {/* Clean Table for Appointments (As requested by prompt)
          Columns: Appointment ID | Patient | Phone | Date | Time | Reason | Status | Actions */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-400 space-y-2">
            <div className="inline-block w-6 h-6 border-2 border-teal-600 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-xs">Loading appointments record...</p>
          </div>
        ) : appointments.length === 0 ? (
          <div className="p-12 text-center space-y-2 text-slate-400 text-xs">
            <Calendar className="w-8 h-8 mx-auto text-slate-300" />
            <p className="text-sm font-semibold text-slate-700">No appointments found</p>
            <p>Try clearing filters or search term to see other bookings.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 font-semibold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-3 px-4">Appointment ID</th>
                  <th className="py-3 px-4">Patient</th>
                  <th className="py-3 px-4">Phone</th>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Time</th>
                  <th className="py-3 px-4">Reason</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {appointments.map((apt) => {
                  return (
                    <tr key={apt.appointment_id} className="hover:bg-slate-50/70 transition-colors">
                      {/* 1. Appointment ID */}
                      <td className="py-3 px-4 font-mono font-bold text-teal-900">
                        {apt.appointment_id}
                      </td>

                      {/* 2. Patient */}
                      <td className="py-3 px-4">
                        <span className="font-semibold text-slate-900 block">{apt.patient_name}</span>
                        <span className="text-[11px] text-slate-500">
                          {apt.patient_age}y · {apt.patient_gender}
                        </span>
                      </td>

                      {/* 3. Phone */}
                      <td className="py-3 px-4 font-mono text-slate-700">
                        <a href={`tel:${apt.patient_phone}`} className="hover:text-teal-700">
                          {apt.patient_phone}
                        </a>
                      </td>

                      {/* 4. Date */}
                      <td className="py-3 px-4 font-mono text-slate-800">
                        {apt.appointment_date}
                      </td>

                      {/* 5. Time */}
                      <td className="py-3 px-4 font-mono font-semibold text-slate-900">
                        {apt.appointment_time}
                      </td>

                      {/* 6. Reason */}
                      <td className="py-3 px-4 max-w-xs truncate text-slate-700" title={apt.reason}>
                        {apt.reason}
                        {apt.doctor_notes && (
                          <span className="block text-[10px] text-teal-700 italic truncate">
                            Note: {apt.doctor_notes}
                          </span>
                        )}
                      </td>

                      {/* 7. Status */}
                      <td className="py-3 px-4">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                            apt.status === 'CONFIRMED'
                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                              : apt.status === 'PENDING'
                              ? 'bg-amber-50 text-amber-800 border border-amber-200'
                              : apt.status === 'COMPLETED'
                              ? 'bg-teal-50 text-teal-800 border border-teal-200'
                              : apt.status === 'CANCELLED'
                              ? 'bg-rose-50 text-rose-800 border border-rose-200'
                              : 'bg-slate-100 text-slate-700 border border-slate-300'
                          }`}
                        >
                          {apt.status}
                        </span>
                      </td>

                      {/* 8. Actions (View details, Confirm, Reject/cancel, Mark completed, Reschedule, Add notes) */}
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Details */}
                          <button
                            type="button"
                            onClick={() => setDetailsModalAppt(apt)}
                            title="View full details"
                            className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          {/* Notes */}
                          <button
                            type="button"
                            onClick={() => {
                              setNotesModalAppt(apt);
                              setNotesInput(apt.doctor_notes || '');
                            }}
                            title="Add / Edit Clinical Notes"
                            className="p-1.5 text-slate-500 hover:text-teal-700 hover:bg-teal-50 rounded-lg"
                          >
                            <FileText className="w-3.5 h-3.5" />
                          </button>

                          {/* Confirm action if pending */}
                          {apt.status === 'PENDING' && (
                            <button
                              type="button"
                              onClick={() => handleStatusChange(apt.appointment_id, 'CONFIRMED')}
                              className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded text-[11px]"
                            >
                              Confirm
                            </button>
                          )}

                          {/* Mark Complete action */}
                          {apt.status === 'CONFIRMED' && (
                            <button
                              type="button"
                              onClick={() => handleStatusChange(apt.appointment_id, 'COMPLETED')}
                              className="px-2 py-1 bg-teal-700 hover:bg-teal-800 text-white font-semibold rounded text-[11px]"
                            >
                              Complete
                            </button>
                          )}

                          {/* Reschedule */}
                          {apt.status !== 'CANCELLED' && apt.status !== 'COMPLETED' && (
                            <button
                              type="button"
                              onClick={() => {
                                setRescheduleAppt(apt);
                                setRescheduleDate(apt.appointment_date);
                                setRescheduleTime(apt.appointment_time);
                                setRescheduleError(null);
                              }}
                              className="p-1.5 text-slate-500 hover:text-teal-700 hover:bg-slate-100 rounded-lg"
                              title="Reschedule"
                            >
                              <Calendar className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* Cancel / Reject */}
                          {apt.status !== 'CANCELLED' && apt.status !== 'COMPLETED' && (
                            <button
                              type="button"
                              onClick={() => handleStatusChange(apt.appointment_id, 'CANCELLED')}
                              className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg"
                              title="Cancel appointment"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* MODAL 1: Appointment Details Modal */}
      {detailsModalAppt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 space-y-5 shadow-2xl border border-slate-200">
            <div className="flex justify-between items-start border-b border-slate-100 pb-3">
              <div>
                <span className="text-[11px] font-mono text-teal-800 font-bold">
                  {detailsModalAppt.appointment_id}
                </span>
                <h3 className="text-lg font-bold text-slate-900">Appointment Information</h3>
              </div>
              <button
                type="button"
                onClick={() => setDetailsModalAppt(null)}
                className="text-slate-400 hover:text-slate-700 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3 p-3.5 bg-slate-50 rounded-xl">
                <div>
                  <span className="text-slate-500 block text-[11px]">Patient Name</span>
                  <span className="font-bold text-slate-900 text-sm">{detailsModalAppt.patient_name}</span>
                  <span className="text-slate-500 block">
                    {detailsModalAppt.patient_age} Years · {detailsModalAppt.patient_gender}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[11px]">Contact</span>
                  <a
                    href={`tel:${detailsModalAppt.patient_phone}`}
                    className="font-mono font-bold text-teal-800 hover:underline block"
                  >
                    {detailsModalAppt.patient_phone}
                  </a>
                  {detailsModalAppt.patient_email && (
                    <span className="text-slate-500 text-[11px] block">{detailsModalAppt.patient_email}</span>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 p-3.5 bg-slate-50 rounded-xl">
                <div>
                  <span className="text-slate-500 block text-[11px]">Appointment Slot</span>
                  <span className="font-bold text-slate-900 block font-mono">
                    {detailsModalAppt.appointment_date}
                  </span>
                  <span className="font-semibold text-teal-800 block font-mono">
                    {detailsModalAppt.appointment_time}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[11px]">Current Status</span>
                  <span className="font-bold text-slate-900 block">{detailsModalAppt.status}</span>
                  <div className="mt-1 flex items-center gap-1">
                    <select
                      value={detailsModalAppt.status}
                      onChange={(e) =>
                        handleStatusChange(
                          detailsModalAppt.appointment_id,
                          e.target.value as AppointmentStatus
                        )
                      }
                      className="py-1 px-2 text-[11px] bg-white border border-slate-300 rounded font-semibold"
                    >
                      <option value="PENDING">PENDING</option>
                      <option value="CONFIRMED">CONFIRMED</option>
                      <option value="COMPLETED">COMPLETED</option>
                      <option value="CANCELLED">CANCELLED</option>
                      <option value="NO-SHOW">NO-SHOW</option>
                    </select>
                  </div>
                </div>
              </div>

              <div>
                <span className="text-slate-500 font-semibold block mb-1">Reason for Visit:</span>
                <p className="p-3 bg-white border border-slate-200 rounded-xl text-slate-800">
                  {detailsModalAppt.reason}
                </p>
              </div>

              <div>
                <span className="text-slate-500 font-semibold block mb-1">Doctor's Clinical Notes:</span>
                <p className="p-3 bg-teal-50/50 border border-teal-100 rounded-xl text-slate-800 italic">
                  {detailsModalAppt.doctor_notes || 'No notes added yet.'}
                </p>
              </div>

              {detailsModalAppt.patient_address && (
                <div>
                  <span className="text-slate-500 font-semibold block mb-0.5">Address:</span>
                  <p className="text-slate-700">{detailsModalAppt.patient_address}</p>
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-slate-100 flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setDetailsModalAppt(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: Clinical Doctor Notes Modal */}
      {notesModalAppt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl border border-slate-200">
            <div>
              <span className="text-[11px] font-mono text-teal-800 font-bold">
                {notesModalAppt.appointment_id}
              </span>
              <h3 className="text-base font-bold text-slate-900">
                Doctor Notes for {notesModalAppt.patient_name}
              </h3>
              <p className="text-xs text-slate-500">
                Add clinical observations, medication instructions, or follow-up recommendations.
              </p>
            </div>

            <textarea
              rows={4}
              value={notesInput}
              onChange={(e) => setNotesInput(e.target.value)}
              placeholder="e.g. Advised BP monitoring morning and evening. Prescribed Paracetamol 650mg SOS. Review in 10 days with CBC report..."
              className="w-full p-3 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600 leading-relaxed"
            ></textarea>

            <div className="flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setNotesModalAppt(null)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isProcessing}
                onClick={handleSaveNotes}
                className="px-4 py-2 bg-teal-700 hover:bg-teal-800 text-white font-semibold rounded-lg shadow-sm"
              >
                {isProcessing ? 'Saving...' : 'Save Clinical Notes'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: Reschedule Modal */}
      {rescheduleAppt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl border border-slate-200">
            <div>
              <span className="text-[11px] font-mono text-teal-800 font-bold">
                {rescheduleAppt.appointment_id}
              </span>
              <h3 className="text-base font-bold text-slate-900">
                Reschedule Appointment
              </h3>
              <p className="text-xs text-slate-500">
                Patient: <strong className="text-slate-800">{rescheduleAppt.patient_name}</strong>
              </p>
            </div>

            {rescheduleError && (
              <div className="p-3 rounded-lg bg-rose-50 text-rose-800 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{rescheduleError}</span>
              </div>
            )}

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">New Date</label>
                <input
                  type="date"
                  value={rescheduleDate}
                  onChange={(e) => setRescheduleDate(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">New Time Slot</label>
                <select
                  value={rescheduleTime}
                  onChange={(e) => setRescheduleTime(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600 font-mono"
                >
                  <option value="">Select Slot</option>
                  <option value="10:00 AM">10:00 AM</option>
                  <option value="10:20 AM">10:20 AM</option>
                  <option value="10:40 AM">10:40 AM</option>
                  <option value="11:00 AM">11:00 AM</option>
                  <option value="11:20 AM">11:20 AM</option>
                  <option value="11:40 AM">11:40 AM</option>
                  <option value="12:00 PM">12:00 PM</option>
                  <option value="12:20 PM">12:20 PM</option>
                  <option value="12:40 PM">12:40 PM</option>
                  <option value="05:00 PM">05:00 PM</option>
                  <option value="05:20 PM">05:20 PM</option>
                  <option value="05:40 PM">05:40 PM</option>
                  <option value="06:00 PM">06:00 PM</option>
                  <option value="06:20 PM">06:20 PM</option>
                  <option value="06:40 PM">06:40 PM</option>
                  <option value="07:00 PM">07:00 PM</option>
                  <option value="07:20 PM">07:20 PM</option>
                  <option value="07:40 PM">07:40 PM</option>
                </select>
              </div>

              <p className="text-[11px] text-teal-800 bg-teal-50 p-2.5 rounded-lg">
                Rescheduling will automatically trigger an SMS/WhatsApp update notification to the patient.
              </p>
            </div>

            <div className="flex justify-end gap-2 text-xs pt-2">
              <button
                type="button"
                onClick={() => setRescheduleAppt(null)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isProcessing}
                onClick={handleConfirmReschedule}
                className="px-4 py-2 bg-teal-700 hover:bg-teal-800 text-white font-semibold rounded-lg shadow-sm"
              >
                {isProcessing ? 'Updating...' : 'Confirm Reschedule'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
