import React, { useState, useEffect } from 'react';
import { Sliders, Clock, Calendar, Check, AlertCircle, Plus, Trash2, ShieldCheck } from 'lucide-react';
import { api } from '../../api';
import { AvailabilitySettings } from '../../types';

export const AdminAvailability: React.FC = () => {
  const [availability, setAvailability] = useState<AvailabilitySettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // New holiday input
  const [newHolidayDate, setNewHolidayDate] = useState('');
  const [newHolidayReason, setNewHolidayReason] = useState('');

  const fetchAvailability = async () => {
    setLoading(true);
    try {
      const res = await api.getAvailability();
      setAvailability(res.availability);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to load availability');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAvailability();
  }, []);

  const handleDayToggle = (dayIdx: number) => {
    if (!availability) return;
    const current = [...availability.workingDays];
    const exists = current.includes(dayIdx);
    const updated = exists ? current.filter((d) => d !== dayIdx) : [...current, dayIdx].sort();
    setAvailability({ ...availability, workingDays: updated });
  };

  const handleAddHoliday = (e: React.FormEvent) => {
    e.preventDefault();
    if (!availability || !newHolidayDate || !newHolidayReason.trim()) return;

    const updatedHolidays = [
      ...availability.holidays,
      { date: newHolidayDate, reason: newHolidayReason.trim() }
    ];

    setAvailability({ ...availability, holidays: updatedHolidays });
    setNewHolidayDate('');
    setNewHolidayReason('');
  };

  const handleRemoveHoliday = (dateStr: string) => {
    if (!availability) return;
    setAvailability({
      ...availability,
      holidays: availability.holidays.filter((h) => h.date !== dateStr)
    });
  };

  const handleSave = async () => {
    if (!availability) return;
    setSaving(true);
    setMessage(null);
    setError(null);

    try {
      const res = await api.updateAvailability(availability);
      setAvailability(res.availability);
      setMessage('Availability schedule, working hours & holidays saved successfully!');
      setTimeout(() => setMessage(null), 4000);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to update schedule');
    } finally {
      setSaving(false);
    }
  };

  const daysMap = [
    { idx: 1, name: 'Monday' },
    { idx: 2, name: 'Tuesday' },
    { idx: 3, name: 'Wednesday' },
    { idx: 4, name: 'Thursday' },
    { idx: 5, name: 'Friday' },
    { idx: 6, name: 'Saturday' },
    { idx: 0, name: 'Sunday' }
  ];

  if (loading) {
    return (
      <div className="p-12 text-center text-slate-400 space-y-2">
        <div className="inline-block w-6 h-6 border-2 border-teal-600 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-xs">Loading availability settings...</p>
      </div>
    );
  }

  if (!availability) return null;

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <span className="text-xs uppercase font-bold tracking-wider text-teal-700 font-sans">
          Schedule & Shifts
        </span>
        <h2 className="text-2xl font-serif font-bold text-slate-900 mt-0.5">
          Doctor Availability & Slot Management
        </h2>
        <p className="text-xs text-slate-500">
          Configure consultation hours, shift intervals, slot durations, and clinic closure dates. Changes apply immediately to patient booking.
        </p>
      </div>

      {message && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{message}</span>
        </div>
      )}

      {error && (
        <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* 1. Working Days */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-teal-700" />
            <span>Working Days</span>
          </h3>
          <span className="text-xs text-slate-500">Click to toggle day open/closed</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2.5">
          {daysMap.map((d) => {
            const isActive = availability.workingDays.includes(d.idx);
            return (
              <button
                key={d.idx}
                type="button"
                onClick={() => handleDayToggle(d.idx)}
                className={`py-3 px-2 rounded-xl text-xs font-semibold border transition-all text-center flex flex-col items-center justify-center gap-1 ${
                  isActive
                    ? 'bg-teal-700 text-white border-teal-800 shadow-2xs'
                    : 'bg-slate-50 text-slate-400 border-slate-200 hover:border-slate-300'
                }`}
              >
                <span>{d.name}</span>
                <span className="text-[10px] font-normal">
                  {isActive ? 'Available' : 'Closed'}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Shift Hours Configuration (Morning & Evening) */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-6">
        <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <Clock className="w-4 h-4 text-teal-700" />
          <span>Consultation Shifts & Timing</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Morning Shift */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-slate-900">Morning Shift</span>
              <label className="flex items-center gap-2 text-xs cursor-pointer">
                <input
                  type="checkbox"
                  checked={availability.morningShift.enabled}
                  onChange={(e) =>
                    setAvailability({
                      ...availability,
                      morningShift: {
                        ...availability.morningShift,
                        enabled: e.target.checked
                      }
                    })
                  }
                  className="w-4 h-4 text-teal-600 rounded"
                />
                <span className="text-slate-600">Enabled</span>
              </label>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-slate-500 mb-1">Start Time</label>
                <input
                  type="time"
                  disabled={!availability.morningShift.enabled}
                  value={availability.morningShift.startTime}
                  onChange={(e) =>
                    setAvailability({
                      ...availability,
                      morningShift: {
                        ...availability.morningShift,
                        startTime: e.target.value
                      }
                    })
                  }
                  className="w-full p-2 border border-slate-300 rounded-lg bg-white font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-500 mb-1">End Time</label>
                <input
                  type="time"
                  disabled={!availability.morningShift.enabled}
                  value={availability.morningShift.endTime}
                  onChange={(e) =>
                    setAvailability({
                      ...availability,
                      morningShift: {
                        ...availability.morningShift,
                        endTime: e.target.value
                      }
                    })
                  }
                  className="w-full p-2 border border-slate-300 rounded-lg bg-white font-mono"
                />
              </div>
            </div>
            <p className="text-[11px] text-slate-500">Default: 10:00 AM – 01:00 PM</p>
          </div>

          {/* Evening Shift */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-slate-900">Evening Shift</span>
              <label className="flex items-center gap-2 text-xs cursor-pointer">
                <input
                  type="checkbox"
                  checked={availability.eveningShift.enabled}
                  onChange={(e) =>
                    setAvailability({
                      ...availability,
                      eveningShift: {
                        ...availability.eveningShift,
                        enabled: e.target.checked
                      }
                    })
                  }
                  className="w-4 h-4 text-teal-600 rounded"
                />
                <span className="text-slate-600">Enabled</span>
              </label>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-slate-500 mb-1">Start Time</label>
                <input
                  type="time"
                  disabled={!availability.eveningShift.enabled}
                  value={availability.eveningShift.startTime}
                  onChange={(e) =>
                    setAvailability({
                      ...availability,
                      eveningShift: {
                        ...availability.eveningShift,
                        startTime: e.target.value
                      }
                    })
                  }
                  className="w-full p-2 border border-slate-300 rounded-lg bg-white font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-500 mb-1">End Time</label>
                <input
                  type="time"
                  disabled={!availability.eveningShift.enabled}
                  value={availability.eveningShift.endTime}
                  onChange={(e) =>
                    setAvailability({
                      ...availability,
                      eveningShift: {
                        ...availability.eveningShift,
                        endTime: e.target.value
                      }
                    })
                  }
                  className="w-full p-2 border border-slate-300 rounded-lg bg-white font-mono"
                />
              </div>
            </div>
            <p className="text-[11px] text-slate-500">Default: 05:00 PM – 08:00 PM</p>
          </div>
        </div>

        {/* Slot Duration & Max Appointments */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Slot Duration (Minutes per Consultation)
            </label>
            <select
              value={availability.slotDurationMinutes}
              onChange={(e) =>
                setAvailability({
                  ...availability,
                  slotDurationMinutes: Number(e.target.value)
                })
              }
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold"
            >
              <option value="15">15 Minutes</option>
              <option value="20">20 Minutes (Recommended)</option>
              <option value="30">30 Minutes</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Max Daily Appointments Cap
            </label>
            <input
              type="number"
              min="5"
              max="60"
              value={availability.maxAppointmentsPerDay}
              onChange={(e) =>
                setAvailability({
                  ...availability,
                  maxAppointmentsPerDay: Number(e.target.value)
                })
              }
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
            />
          </div>
        </div>
      </div>

      {/* 3. Holidays & Special Unavailable Dates */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
        <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <Calendar className="w-4 h-4 text-teal-700" />
          <span>Holidays & Clinic Closures</span>
        </h3>
        <p className="text-xs text-slate-500">
          Designate upcoming holidays, conferences, or leave dates. All slots on these days are blocked automatically.
        </p>

        {/* List of current holidays */}
        <div className="space-y-2">
          {availability.holidays.length === 0 ? (
            <p className="text-xs text-slate-400 italic">No special closure dates configured.</p>
          ) : (
            availability.holidays.map((h) => (
              <div
                key={h.date}
                className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs"
              >
                <div>
                  <span className="font-mono font-bold text-slate-900 block">{h.date}</span>
                  <span className="text-slate-600">{h.reason}</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleRemoveHoliday(h.date)}
                  className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg"
                  title="Remove holiday"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Add new holiday form */}
        <form onSubmit={handleAddHoliday} className="pt-2 border-t border-slate-100 flex flex-wrap gap-2 text-xs">
          <input
            type="date"
            required
            value={newHolidayDate}
            onChange={(e) => setNewHolidayDate(e.target.value)}
            className="p-2 border border-slate-300 rounded-lg bg-slate-50 focus:bg-white"
          />
          <input
            type="text"
            required
            placeholder="Reason (e.g. Festival, Medical Conference)"
            value={newHolidayReason}
            onChange={(e) => setNewHolidayReason(e.target.value)}
            className="flex-1 min-w-[200px] p-2 border border-slate-300 rounded-lg bg-slate-50 focus:bg-white"
          />
          <button
            type="submit"
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Holiday</span>
          </button>
        </form>
      </div>

      {/* Save Button */}
      <div className="flex justify-end pt-2">
        <button
          type="button"
          disabled={saving}
          onClick={handleSave}
          className="px-8 py-3 bg-teal-700 hover:bg-teal-800 active:bg-teal-900 text-white rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-2"
        >
          {saving ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              <span>Saving Changes...</span>
            </>
          ) : (
            <span>Save Availability & Schedule</span>
          )}
        </button>
      </div>
    </div>
  );
};
