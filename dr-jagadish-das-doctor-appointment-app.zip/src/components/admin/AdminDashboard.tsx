import React, { useEffect, useState } from 'react';
import {
  Calendar,
  Users,
  CheckCircle2,
  Clock,
  XCircle,
  AlertTriangle,
  TrendingUp,
  PlusCircle,
  Settings,
  Sliders,
  DollarSign,
  ArrowRight,
  RefreshCw,
  Eye,
  UserCheck
} from 'lucide-react';
import { api } from '../../api';
import { DashboardStats, Appointment } from '../../types';

interface AdminDashboardProps {
  onNavigateTab: (tab: string, filterParams?: { date?: string; status?: string }) => void;
  onOpenNewAppointment: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onNavigateTab,
  onOpenNewAppointment
}) => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [todayList, setTodayList] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    setLoading(true);
    try {
      const todayStr = new Date().toISOString().split('T')[0];
      const [statsData, apptsData] = await Promise.all([
        api.getDashboardStats(),
        api.getAppointments({ date: todayStr })
      ]);
      setStats(statsData);
      setTodayList(apptsData.appointments || []);
    } catch (err) {
      console.error('Failed to load dashboard statistics:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const todayStr = new Date().toISOString().split('T')[0];

  return (
    <div className="space-y-8">
      {/* Top Welcome & Quick Actions Bar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <span className="text-xs uppercase font-bold tracking-wider text-teal-700 font-sans">
            Clinic Overview
          </span>
          <h1 className="text-2xl font-serif font-bold text-slate-900 mt-0.5">
            Welcome, Dr. Jagadish Das
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Today is{' '}
            <strong className="text-slate-800">
              {new Date().toLocaleDateString('en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })}
            </strong>
          </p>
        </div>

        {/* 5 Prominent Quick Actions as specified in prompt:
            + New Appointment, Today's Appointments, Manage Availability, Patients, Settings */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onOpenNewAppointment}
            className="px-4 py-2 text-xs font-bold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-sm flex items-center gap-1.5 transition-all"
          >
            <PlusCircle className="w-4 h-4" />
            <span>+ New Appointment</span>
          </button>

          <button
            onClick={() => onNavigateTab('appointments', { date: todayStr })}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl flex items-center gap-1.5 transition-colors"
          >
            <Calendar className="w-4 h-4 text-teal-700" />
            <span>Today's List</span>
          </button>

          <button
            onClick={() => onNavigateTab('availability')}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl flex items-center gap-1.5 transition-colors"
          >
            <Sliders className="w-4 h-4 text-teal-700" />
            <span>Availability</span>
          </button>

          <button
            onClick={() => onNavigateTab('patients')}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl flex items-center gap-1.5 transition-colors"
          >
            <Users className="w-4 h-4 text-teal-700" />
            <span>Patients</span>
          </button>

          <button
            onClick={() => onNavigateTab('settings')}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl flex items-center gap-1.5 transition-colors"
          >
            <Settings className="w-4 h-4 text-teal-700" />
            <span>Settings</span>
          </button>

          <button
            onClick={loadData}
            title="Refresh statistics"
            className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition-colors"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-teal-600' : ''}`} />
          </button>
        </div>
      </div>

      {/* 8 Primary Cards Required by Prompt:
          - Today's appointments
          - Upcoming appointments
          - Total appointments
          - Pending appointments
          - Confirmed appointments
          - Cancelled appointments
          - Completed appointments
          - Today's patient count
      */}
      <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-4">
        {/* 1. Today's Appointments */}
        <div
          onClick={() => onNavigateTab('appointments', { date: todayStr })}
          className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs hover:border-teal-500 cursor-pointer transition-all space-y-1"
        >
          <div className="flex justify-between items-center text-slate-500 text-xs">
            <span className="font-semibold">Today's Total</span>
            <div className="p-2 rounded-xl bg-teal-50 text-teal-700">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-bold font-mono text-slate-900">{stats?.todayCount ?? '...'}</p>
          <p className="text-[11px] text-teal-700 font-medium">Scheduled for today</p>
        </div>

        {/* 2. Today's Patient Count */}
        <div
          onClick={() => onNavigateTab('patients')}
          className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs hover:border-teal-500 cursor-pointer transition-all space-y-1"
        >
          <div className="flex justify-between items-center text-slate-500 text-xs">
            <span className="font-semibold">Today's Patients</span>
            <div className="p-2 rounded-xl bg-cyan-50 text-cyan-700">
              <UserCheck className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-bold font-mono text-slate-900">{stats?.todayPatientCount ?? '...'}</p>
          <p className="text-[11px] text-cyan-700 font-medium">Distinct patient visits</p>
        </div>

        {/* 3. Upcoming Appointments */}
        <div
          onClick={() => onNavigateTab('appointments')}
          className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs hover:border-teal-500 cursor-pointer transition-all space-y-1"
        >
          <div className="flex justify-between items-center text-slate-500 text-xs">
            <span className="font-semibold">Upcoming</span>
            <div className="p-2 rounded-xl bg-indigo-50 text-indigo-700">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-bold font-mono text-slate-900">{stats?.upcomingCount ?? '...'}</p>
          <p className="text-[11px] text-indigo-700 font-medium">Future active dates</p>
        </div>

        {/* 4. Total Appointments */}
        <div
          onClick={() => onNavigateTab('appointments', { status: 'ALL' })}
          className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs hover:border-teal-500 cursor-pointer transition-all space-y-1"
        >
          <div className="flex justify-between items-center text-slate-500 text-xs">
            <span className="font-semibold">All Time Total</span>
            <div className="p-2 rounded-xl bg-slate-100 text-slate-700">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-bold font-mono text-slate-900">{stats?.totalCount ?? '...'}</p>
          <p className="text-[11px] text-slate-500 font-medium">Lifetime bookings</p>
        </div>

        {/* 5. Confirmed Appointments */}
        <div
          onClick={() => onNavigateTab('appointments', { status: 'CONFIRMED' })}
          className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs hover:border-emerald-500 cursor-pointer transition-all space-y-1"
        >
          <div className="flex justify-between items-center text-slate-500 text-xs">
            <span className="font-semibold">Confirmed</span>
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-bold font-mono text-emerald-800">{stats?.confirmedCount ?? '...'}</p>
          <p className="text-[11px] text-emerald-700 font-medium">Ready for consultation</p>
        </div>

        {/* 6. Pending Appointments */}
        <div
          onClick={() => onNavigateTab('appointments', { status: 'PENDING' })}
          className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs hover:border-amber-500 cursor-pointer transition-all space-y-1"
        >
          <div className="flex justify-between items-center text-slate-500 text-xs">
            <span className="font-semibold">Pending</span>
            <div className="p-2 rounded-xl bg-amber-50 text-amber-700">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-bold font-mono text-amber-800">{stats?.pendingCount ?? '...'}</p>
          <p className="text-[11px] text-amber-700 font-medium">Awaiting confirmation</p>
        </div>

        {/* 7. Completed Appointments */}
        <div
          onClick={() => onNavigateTab('appointments', { status: 'COMPLETED' })}
          className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs hover:border-teal-500 cursor-pointer transition-all space-y-1"
        >
          <div className="flex justify-between items-center text-slate-500 text-xs">
            <span className="font-semibold">Completed</span>
            <div className="p-2 rounded-xl bg-teal-50 text-teal-700">
              <UserCheck className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-bold font-mono text-slate-800">{stats?.completedCount ?? '...'}</p>
          <p className="text-[11px] text-teal-700 font-medium">Consulted & documented</p>
        </div>

        {/* 8. Cancelled Appointments */}
        <div
          onClick={() => onNavigateTab('appointments', { status: 'CANCELLED' })}
          className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs hover:border-rose-500 cursor-pointer transition-all space-y-1"
        >
          <div className="flex justify-between items-center text-slate-500 text-xs">
            <span className="font-semibold">Cancelled</span>
            <div className="p-2 rounded-xl bg-rose-50 text-rose-700">
              <XCircle className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-bold font-mono text-rose-800">{stats?.cancelledCount ?? '...'}</p>
          <p className="text-[11px] text-rose-600 font-medium">Slots released back</p>
        </div>
      </div>

      {/* Analytics Charts & Schedule Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* 7-Day Trend Chart - 7 Cols */}
        <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <span className="text-xs uppercase font-bold tracking-wider text-teal-700 font-sans">
                Activity Trend
              </span>
              <h3 className="text-base font-bold text-slate-900 mt-0.5">
                7-Day Appointment Distribution
              </h3>
            </div>
            <span className="text-xs text-slate-500">Past & Upcoming Days</span>
          </div>

          {/* Simple Clean Bar Chart (Zero pills, accessible contrast) */}
          <div className="pt-4">
            <div className="h-48 flex items-end justify-between gap-3 px-2 border-b border-slate-200">
              {(stats?.trend || []).map((t, idx) => {
                const max = Math.max(...(stats?.trend.map((x) => x.count) || [1]), 5);
                const heightPct = Math.round((t.count / max) * 100);
                const isTodayBar = t.date === todayStr;

                return (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                    <span className="text-[11px] font-mono font-bold text-slate-700 group-hover:text-teal-700">
                      {t.count}
                    </span>
                    <div
                      style={{ height: `${Math.max(heightPct, 8)}%` }}
                      className={`w-full max-w-[42px] rounded-t-lg transition-all ${
                        isTodayBar
                          ? 'bg-teal-600 shadow-sm'
                          : 'bg-slate-200 hover:bg-teal-400'
                      }`}
                    ></div>
                    <span
                      className={`text-[10px] text-center truncate w-full ${
                        isTodayBar ? 'font-bold text-teal-800' : 'text-slate-500'
                      }`}
                    >
                      {t.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Financial summary note */}
          <div className="pt-2 flex items-center justify-between text-xs text-slate-600 border-t border-slate-100">
            <span>Official Consultation Fee: ₹{stats?.consultationFee || 500}</span>
            <span>
              Today's Estimated Patient Inflow:{' '}
              <strong className="text-slate-900 font-mono">₹{stats?.todayRevenueEstimate || 0}</strong>
            </span>
          </div>
        </div>

        {/* Today's Appointments Queue Preview - 5 Cols */}
        <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-4 flex flex-col">
          <div className="flex justify-between items-center">
            <div>
              <span className="text-xs uppercase font-bold tracking-wider text-teal-700 font-sans">
                Live Queue
              </span>
              <h3 className="text-base font-bold text-slate-900 mt-0.5">
                Today's Patient Schedule
              </h3>
            </div>
            <button
              onClick={() => onNavigateTab('appointments', { date: todayStr })}
              className="text-xs font-semibold text-teal-700 hover:underline flex items-center gap-1"
            >
              <span>View All</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto space-y-2.5 max-h-[310px] pr-1">
            {todayList.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs border border-dashed border-slate-200 rounded-xl space-y-2">
                <Calendar className="w-6 h-6 mx-auto text-slate-300" />
                <p>No appointments booked for today yet.</p>
                <button
                  type="button"
                  onClick={onOpenNewAppointment}
                  className="text-teal-700 font-semibold hover:underline"
                >
                  + Add Walk-in Patient
                </button>
              </div>
            ) : (
              todayList.map((apt) => (
                <div
                  key={apt.appointment_id}
                  className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 hover:bg-teal-50/40 transition-colors flex items-center justify-between text-xs"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900">{apt.patient_name}</span>
                      <span className="text-[10px] text-slate-500 font-mono">({apt.patient_age}y · {apt.patient_gender})</span>
                    </div>
                    <p className="text-[11px] text-slate-500 truncate max-w-[200px] mt-0.5">{apt.reason}</p>
                  </div>

                  <div className="text-right">
                    <span className="font-mono font-bold text-teal-900 block">{apt.appointment_time}</span>
                    <span
                      className={`text-[10px] font-semibold ${
                        apt.status === 'CONFIRMED'
                          ? 'text-emerald-700'
                          : apt.status === 'PENDING'
                          ? 'text-amber-700'
                          : apt.status === 'COMPLETED'
                          ? 'text-teal-700'
                          : 'text-rose-600'
                      }`}
                    >
                      {apt.status}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
