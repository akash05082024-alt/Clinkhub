import React, { useState } from 'react';
import {
  LayoutDashboard,
  Calendar,
  Users,
  Sliders,
  Settings,
  Bell,
  LogOut,
  ExternalLink,
  PlusCircle,
  Stethoscope,
  RotateCcw,
  ShieldCheck,
  Menu,
  X
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../api';
import { AdminDashboard } from './AdminDashboard';
import { AdminAppointments } from './AdminAppointments';
import { AdminPatients } from './AdminPatients';
import { AdminAvailability } from './AdminAvailability';
import { AdminSettings } from './AdminSettings';
import { AdminNotifications } from './AdminNotifications';
import { AdminNewAppointmentModal } from './AdminNewAppointmentModal';
import { DownloadAppModal } from '../DownloadAppModal';
import { Appointment } from '../../types';

interface AdminLayoutProps {
  onBackToWebsite: () => void;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({ onBackToWebsite }) => {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [filterParams, setFilterParams] = useState<{ date?: string; status?: string }>({});
  const [showNewModal, setShowNewModal] = useState(false);
  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [resettingDemo, setResettingDemo] = useState(false);

  const handleNavigateTab = (tab: string, params?: { date?: string; status?: string }) => {
    setActiveTab(tab);
    if (params) {
      setFilterParams(params);
    }
    setMobileSidebarOpen(false);
  };

  const handleResetDemo = async () => {
    if (window.confirm('Reset all demo appointments, patient logs, and settings to original initial seed?')) {
      setResettingDemo(true);
      try {
        await api.resetDemoData();
        window.location.reload();
      } catch (err) {
        console.error(err);
      } finally {
        setResettingDemo(false);
      }
    }
  };

  const handleNewAppointmentSuccess = (newApt: Appointment) => {
    setShowNewModal(false);
    setActiveTab('appointments');
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
      {/* Top Admin Navbar */}
      <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-30">
        <div className="px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
              className="p-1.5 md:hidden text-slate-400 hover:text-white"
            >
              {mobileSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-teal-600 flex items-center justify-center text-white shadow-sm">
                <Stethoscope className="w-5 h-5" />
              </div>
              <div>
                <span className="font-bold text-sm text-white font-serif tracking-tight">
                  Dr. Jagadish Das
                </span>
                <span className="text-[11px] text-teal-400 font-sans block leading-none">
                  Admin Consultation Console
                </span>
              </div>
            </div>
          </div>

          {/* Right Header items */}
          <div className="flex items-center gap-2 sm:gap-3 text-xs">
            {/* Demo Reset button */}
            <button
              type="button"
              onClick={handleResetDemo}
              disabled={resettingDemo}
              title="Reset Demo Records"
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors border border-slate-700 text-[11px]"
            >
              <RotateCcw className={`w-3.5 h-3.5 ${resettingDemo ? 'animate-spin' : ''}`} />
              <span>Reset Demo Data</span>
            </button>

            {/* Download App / Source Code button */}
            <button
              type="button"
              onClick={() => setShowDownloadModal(true)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-teal-800 text-teal-100 hover:bg-teal-700 transition-colors text-[11px] font-semibold"
              title="Download App as PWA or Full Source Code (.ZIP)"
            >
              <span>Download App</span>
            </button>

            {/* Quick Walk-in button */}
            <button
              type="button"
              onClick={() => setShowNewModal(true)}
              className="px-3 py-1.5 bg-teal-600 hover:bg-teal-500 text-white rounded-lg font-semibold flex items-center gap-1.5 transition-colors"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>+ Walk-in</span>
            </button>

            {/* Back to Public Site */}
            <button
              type="button"
              onClick={onBackToWebsite}
              className="hidden sm:flex items-center gap-1 px-3 py-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <span>Public Site</span>
              <ExternalLink className="w-3 h-3 text-slate-400" />
            </button>

            {/* Logout */}
            <button
              type="button"
              onClick={logout}
              className="flex items-center gap-1 px-2.5 py-1.5 text-rose-300 hover:text-rose-100 hover:bg-rose-950/40 rounded-lg transition-colors"
              title="Sign Out"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Logout</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Admin Shell with Sidebar */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 gap-6">
        {/* Desktop Sidebar Navigation */}
        <aside
          className={`w-64 bg-white rounded-2xl border border-slate-200 shadow-2xs p-4 flex flex-col justify-between shrink-0 ${
            mobileSidebarOpen
              ? 'fixed inset-y-0 left-0 z-40 w-64 shadow-2xl m-4'
              : 'hidden md:flex'
          }`}
        >
          <div className="space-y-1">
            <div className="px-3 py-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Management Menu
            </div>

            <button
              type="button"
              onClick={() => handleNavigateTab('dashboard')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'dashboard'
                  ? 'bg-teal-700 text-white shadow-2xs'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>Dashboard Overview</span>
            </button>

            <button
              type="button"
              onClick={() => handleNavigateTab('appointments')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'appointments'
                  ? 'bg-teal-700 text-white shadow-2xs'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Calendar className="w-4 h-4" />
              <span>Appointments Queue</span>
            </button>

            <button
              type="button"
              onClick={() => handleNavigateTab('patients')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'patients'
                  ? 'bg-teal-700 text-white shadow-2xs'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Patients Directory</span>
            </button>

            <button
              type="button"
              onClick={() => handleNavigateTab('availability')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'availability'
                  ? 'bg-teal-700 text-white shadow-2xs'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Sliders className="w-4 h-4" />
              <span>Slot Availability</span>
            </button>

            <button
              type="button"
              onClick={() => handleNavigateTab('notifications')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'notifications'
                  ? 'bg-teal-700 text-white shadow-2xs'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Bell className="w-4 h-4" />
              <span>Notification Logs</span>
            </button>

            <button
              type="button"
              onClick={() => handleNavigateTab('settings')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'settings'
                  ? 'bg-teal-700 text-white shadow-2xs'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Settings className="w-4 h-4" />
              <span>Settings & Setup</span>
            </button>
          </div>

          {/* Doctor bottom badge */}
          <div className="pt-4 border-t border-slate-100 text-[11px] text-slate-500 space-y-2">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span className="font-semibold text-slate-700 truncate">{user?.fullName || 'Dr. Jagadish Das'}</span>
            </div>
            <p className="text-[10px] text-slate-400">
              Admin Session Active
            </p>
          </div>
        </aside>

        {/* Content Area */}
        <main className="flex-1 min-w-0">
          {activeTab === 'dashboard' && (
            <AdminDashboard
              onNavigateTab={handleNavigateTab}
              onOpenNewAppointment={() => setShowNewModal(true)}
            />
          )}

          {activeTab === 'appointments' && (
            <AdminAppointments
              initialDate={filterParams.date}
              initialStatus={filterParams.status}
              onOpenNewModal={() => setShowNewModal(true)}
            />
          )}

          {activeTab === 'patients' && <AdminPatients />}

          {activeTab === 'availability' && <AdminAvailability />}

          {activeTab === 'notifications' && <AdminNotifications />}

          {activeTab === 'settings' && <AdminSettings />}
        </main>
      </div>

      {/* New Appointment Modal */}
      {showNewModal && (
        <AdminNewAppointmentModal
          onClose={() => setShowNewModal(false)}
          onSuccess={handleNewAppointmentSuccess}
        />
      )}

      {/* Download App Modal */}
      <DownloadAppModal
        isOpen={showDownloadModal}
        onClose={() => setShowDownloadModal(false)}
      />
    </div>
  );
};
