import React, { useState } from 'react';
import { PlusCircle, Calendar, Clock, User, Phone, AlertCircle, CheckCircle2 } from 'lucide-react';
import { api } from '../../api';
import { Appointment } from '../../types';

interface AdminNewAppointmentModalProps {
  onClose: () => void;
  onSuccess: (appointment: Appointment) => void;
}

export const AdminNewAppointmentModal: React.FC<AdminNewAppointmentModalProps> = ({
  onClose,
  onSuccess
}) => {
  const todayStr = new Date().toISOString().split('T')[0];
  const [date, setDate] = useState(todayStr);
  const [time, setTime] = useState('10:00 AM');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState<'Male' | 'Female' | 'Other'>('Male');
  const [address, setAddress] = useState('');
  const [reason, setReason] = useState('Clinic Walk-in Consultation');
  const [doctorNotes, setDoctorNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const cleanPhone = phone.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      setError('Please provide a valid 10-digit mobile number.');
      return;
    }

    const ageNum = parseInt(age, 10);
    if (isNaN(ageNum) || ageNum <= 0) {
      setError('Please enter a valid age.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await api.createAppointmentAdmin({
        date,
        time,
        name: name.trim(),
        phone: phone.trim(),
        email: email.trim(),
        age: ageNum,
        gender,
        address: address.trim(),
        reason: reason.trim(),
        doctorNotes: doctorNotes.trim()
      });

      onSuccess(res.appointment);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Could not create appointment');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-5 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-start border-b border-slate-100 pb-3">
          <div>
            <span className="text-[11px] font-bold text-teal-700 uppercase tracking-wider">
              Walk-in / Phone Reservation
            </span>
            <h3 className="text-xl font-bold font-serif text-slate-900">
              New Patient Appointment
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 text-sm font-bold"
          >
            ✕
          </button>
        </div>

        {error && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Date</label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Time Slot</label>
              <select
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono"
              >
                <option value="10:00 AM">10:00 AM</option>
                <option value="10:20 AM">10:20 AM</option>
                <option value="10:40 AM">10:40 AM</option>
                <option value="11:00 AM">11:00 AM</option>
                <option value="11:20 AM">11:20 AM</option>
                <option value="11:40 AM">11:40 AM</option>
                <option value="12:00 PM">12:00 PM</option>
                <option value="12:20 PM">12:20 PM</option>
                <option value="12:40 PM">12:40 PM</option>
                <option value="05:00 PM">05:00 PM</option>
                <option value="05:20 PM">05:20 PM</option>
                <option value="05:40 PM">05:40 PM</option>
                <option value="06:00 PM">06:00 PM</option>
                <option value="06:20 PM">06:20 PM</option>
                <option value="06:40 PM">06:40 PM</option>
                <option value="07:00 PM">07:00 PM</option>
                <option value="07:20 PM">07:20 PM</option>
                <option value="07:40 PM">07:40 PM</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Patient Full Name *</label>
            <input
              type="text"
              required
              placeholder="e.g. Ramesh Mukherjee"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Mobile Number *</label>
              <input
                type="tel"
                required
                placeholder="e.g. 98301 23456"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Email (Optional)</label>
              <input
                type="email"
                placeholder="name@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Age *</label>
              <input
                type="number"
                required
                min="1"
                placeholder="Years"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Gender *</label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value as 'Male' | 'Female' | 'Other')}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
              >
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Reason for Visit</label>
            <input
              type="text"
              required
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Initial Doctor Notes (Optional)</label>
            <textarea
              rows={2}
              value={doctorNotes}
              onChange={(e) => setDoctorNotes(e.target.value)}
              placeholder="e.g. Walk-in patient presenting with acute fever..."
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
            ></textarea>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold rounded-xl shadow-sm"
            >
              {isSubmitting ? 'Booking...' : 'Create Appointment'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
