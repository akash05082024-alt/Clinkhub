import React, { useState, useEffect } from 'react';
import { MessageSquare, RefreshCw, CheckCircle2, AlertTriangle, Phone, Search } from 'lucide-react';
import { api } from '../../api';
import { NotificationLog } from '../../types';

export const AdminNotifications: React.FC = () => {
  const [logs, setLogs] = useState<NotificationLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterType, setFilterType] = useState<string>('ALL');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');

  const fetchLogs = async () => {
    setLoading(true);
    try {
      const data = await api.getNotifications();
      setLogs(data.notifications || []);
    } catch (err) {
      console.error('Failed to load notification logs:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  const filteredLogs = logs.filter((log) => {
    if (filterType !== 'ALL' && log.type !== filterType) return false;
    if (filterStatus !== 'ALL' && log.status !== filterStatus) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <span className="text-xs uppercase font-bold tracking-wider text-teal-700 font-sans">
            Audit Trail
          </span>
          <h2 className="text-2xl font-serif font-bold text-slate-900 mt-0.5">
            SMS & WhatsApp Dispatch Logs
          </h2>
          <p className="text-xs text-slate-500">
            Real-time delivery verification, automatic fallback events, and timestamps
          </p>
        </div>

        <button
          type="button"
          onClick={fetchLogs}
          className="p-2 text-slate-500 hover:text-slate-800 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors"
          title="Refresh notification history"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-teal-700' : ''}`} />
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs flex flex-wrap items-center gap-3 text-xs">
        <div className="flex items-center gap-2">
          <span className="text-slate-500 font-semibold">Channel:</span>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
          >
            <option value="ALL">All Channels</option>
            <option value="WhatsApp">WhatsApp</option>
            <option value="SMS">SMS</option>
          </select>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-slate-500 font-semibold">Status:</span>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
          >
            <option value="ALL">All Statuses</option>
            <option value="Sent">Sent</option>
            <option value="Fallback Sent">Fallback Sent</option>
            <option value="Failed">Failed</option>
          </select>
        </div>

        <div className="ml-auto text-slate-500">
          Showing <strong>{filteredLogs.length}</strong> dispatches
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-400 space-y-2">
            <div className="inline-block w-6 h-6 border-2 border-teal-600 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-xs">Fetching notification activity...</p>
          </div>
        ) : filteredLogs.length === 0 ? (
          <div className="p-12 text-center text-slate-400 text-xs">
            No notification records found matching criteria.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 font-semibold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-3 px-4">Channel / Type</th>
                  <th className="py-3 px-4">Recipient</th>
                  <th className="py-3 px-4">Recipient Phone</th>
                  <th className="py-3 px-4">Appointment ID</th>
                  <th className="py-3 px-4">Timestamp</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Details / Errors</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 font-bold">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold ${
                          log.type === 'WhatsApp'
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            : 'bg-indigo-50 text-indigo-800 border border-indigo-200'
                        }`}
                      >
                        <MessageSquare className="w-3 h-3" />
                        <span>{log.type}</span>
                      </span>
                    </td>

                    <td className="py-3 px-4 font-semibold text-slate-800">
                      {log.recipient}
                    </td>

                    <td className="py-3 px-4 font-mono">
                      {log.recipient_phone}
                    </td>

                    <td className="py-3 px-4 font-mono font-bold text-teal-900">
                      {log.appointment_id}
                    </td>

                    <td className="py-3 px-4 font-mono text-slate-500">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>

                    <td className="py-3 px-4">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                          log.status === 'Sent'
                            ? 'bg-emerald-100 text-emerald-800'
                            : log.status === 'Fallback Sent'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {log.status}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-slate-500 max-w-xs truncate" title={log.error || log.message}>
                      {log.error ? (
                        <span className="text-rose-600 font-semibold">{log.error}</span>
                      ) : (
                        <span className="truncate block">{log.message.replace(/\n+/g, ' ')}</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
