import React, { useState, useEffect } from 'react';
import { Search, User, Phone, Mail, MapPin, Calendar, Clock, FileText, ArrowRight, Eye } from 'lucide-react';
import { api } from '../../api';
import { Patient, Appointment } from '../../types';

export const AdminPatients: React.FC = () => {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  // Selected patient details modal
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [patientHistory, setPatientHistory] = useState<Appointment[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  const fetchPatients = async () => {
    setLoading(true);
    try {
      const data = await api.getPatients(searchTerm);
      setPatients(data.patients || []);
    } catch (err) {
      console.error('Failed to load patients list:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPatients();
  }, [searchTerm]);

  const handleOpenPatient = async (patient: Patient) => {
    setSelectedPatient(patient);
    setHistoryLoading(true);
    try {
      const data = await api.getPatientDetails(patient.patient_id);
      setPatientHistory(data.appointments || []);
    } catch (err) {
      console.error('Failed to load patient history:', err);
    } finally {
      setHistoryLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <span className="text-xs uppercase font-bold tracking-wider text-teal-700 font-sans">
            Medical Records
          </span>
          <h2 className="text-2xl font-serif font-bold text-slate-900 mt-0.5">
            Patient Directory
          </h2>
          <p className="text-xs text-slate-500">
            Secure history of registered patients and clinical notes
          </p>
        </div>

        {/* Search */}
        <div className="w-full sm:w-72 relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
            <Search className="w-4 h-4" />
          </div>
          <input
            type="text"
            placeholder="Search patient name or phone..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600"
          />
        </div>
      </div>

      {/* Patients Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-400 space-y-2">
            <div className="inline-block w-6 h-6 border-2 border-teal-600 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-xs">Loading patient registry...</p>
          </div>
        ) : patients.length === 0 ? (
          <div className="p-12 text-center text-slate-400 text-xs">
            No patient records match the search.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 font-semibold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-3 px-4">Patient ID</th>
                  <th className="py-3 px-4">Full Name</th>
                  <th className="py-3 px-4">Demographics</th>
                  <th className="py-3 px-4">Phone / Contact</th>
                  <th className="py-3 px-4">Visits</th>
                  <th className="py-3 px-4">Last Visit</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {patients.map((p) => (
                  <tr key={p.patient_id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-teal-900">{p.patient_id}</td>
                    <td className="py-3 px-4">
                      <span className="font-bold text-slate-900 block">{p.name}</span>
                      {p.email && <span className="text-[11px] text-slate-400">{p.email}</span>}
                    </td>
                    <td className="py-3 px-4">
                      {p.age} Years · {p.gender}
                    </td>
                    <td className="py-3 px-4 font-mono">
                      <a href={`tel:${p.phone}`} className="hover:text-teal-700">
                        {p.phone}
                      </a>
                    </td>
                    <td className="py-3 px-4 font-mono font-semibold text-slate-900">
                      {p.appointmentCount || 1}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600">
                      {p.lastVisitDate || 'Recent'}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        type="button"
                        onClick={() => handleOpenPatient(p)}
                        className="inline-flex items-center gap-1 px-3 py-1.5 bg-teal-50 hover:bg-teal-100 text-teal-800 rounded-lg font-semibold text-xs transition-colors"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>View History</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Patient Profile & Consultation History Modal */}
      {selectedPatient && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex justify-between items-start border-b border-slate-100 pb-4">
              <div>
                <span className="text-[11px] font-mono text-teal-700 font-bold">
                  {selectedPatient.patient_id}
                </span>
                <h3 className="text-xl font-bold font-serif text-slate-900">
                  {selectedPatient.name}
                </h3>
                <p className="text-xs text-slate-500">
                  Patient Medical Record & Chronic History
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedPatient(null)}
                className="text-slate-400 hover:text-slate-700 text-base font-bold"
              >
                ✕
              </button>
            </div>

            {/* Demographic Card */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-semibold">Age / Gender</span>
                <span className="font-bold text-slate-900 text-sm">
                  {selectedPatient.age}y · {selectedPatient.gender}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-semibold">Phone</span>
                <span className="font-mono font-bold text-slate-900">{selectedPatient.phone}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-semibold">Email</span>
                <span className="text-slate-700 truncate block">{selectedPatient.email || 'None'}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-semibold">Address</span>
                <span className="text-slate-700 truncate block">{selectedPatient.address || 'Kolkata'}</span>
              </div>
            </div>

            {/* Appointment History List */}
            <div className="space-y-3">
              <h4 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-teal-700" />
                <span>Appointment & Consultation History ({patientHistory.length})</span>
              </h4>

              {historyLoading ? (
                <div className="p-8 text-center text-slate-400 text-xs">Loading records...</div>
              ) : patientHistory.length === 0 ? (
                <p className="p-4 bg-slate-50 rounded-xl text-xs text-slate-500 text-center">
                  No prior consultation records logged.
                </p>
              ) : (
                <div className="space-y-3">
                  {patientHistory.map((h) => (
                    <div
                      key={h.appointment_id}
                      className="p-4 rounded-xl border border-slate-200 bg-white space-y-2 text-xs"
                    >
                      <div className="flex flex-wrap justify-between items-center gap-2">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-teal-900">
                            {h.appointment_id}
                          </span>
                          <span className="text-slate-400">·</span>
                          <span className="font-mono font-semibold text-slate-800">
                            {h.appointment_date} at {h.appointment_time}
                          </span>
                        </div>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            h.status === 'COMPLETED'
                              ? 'bg-teal-50 text-teal-800 border border-teal-200'
                              : h.status === 'CONFIRMED'
                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {h.status}
                        </span>
                      </div>

                      <div className="text-slate-700">
                        <strong className="text-slate-900">Reason:</strong> {h.reason}
                      </div>

                      {h.doctor_notes ? (
                        <div className="p-2.5 bg-teal-50/60 border border-teal-100 rounded-lg text-teal-950">
                          <span className="font-bold block text-[11px]">Doctor's Clinical Notes:</span>
                          <p className="text-[11px] leading-relaxed mt-0.5">{h.doctor_notes}</p>
                        </div>
                      ) : (
                        <span className="text-slate-400 text-[11px] italic">
                          No clinical notes entered for this visit.
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="pt-2 border-t border-slate-100 text-right">
              <button
                type="button"
                onClick={() => setSelectedPatient(null)}
                className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl font-semibold text-xs"
              >
                Close Profile
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
