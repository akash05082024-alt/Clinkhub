import React, { useState, useEffect } from 'react';
import {
  Settings,
  User,
  Building,
  Phone,
  MessageSquare,
  KeyRound,
  ShieldCheck,
  Check,
  AlertCircle,
  ExternalLink,
  Send,
  Server,
  Terminal,
  Globe,
  Lock
} from 'lucide-react';
import { api } from '../../api';
import { DoctorProfile, ClinicSettings, AvailabilitySettings } from '../../types';

export const AdminSettings: React.FC = () => {
  const [activeTab, setActiveTab] = useState<
    'doctor' | 'clinic' | 'notifications' | 'password' | 'deployment'
  >('doctor');

  const [doctor, setDoctor] = useState<DoctorProfile | null>(null);
  const [clinic, setClinic] = useState<ClinicSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Password change state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Notification testing state
  const [testPhone, setTestPhone] = useState('+919876543210');
  const [testMessage, setTestMessage] = useState(
    'Test alert: Dr. Jagadish Das Clinic Notification Gateway is operational.'
  );
  const [forceFailWhatsApp, setForceFailWhatsApp] = useState(false);
  const [testingNotification, setTestingNotification] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);

  const fetchSettings = async () => {
    setLoading(true);
    try {
      const data = await api.getSettings();
      setDoctor(data.doctor);
      setClinic(data.clinic);
    } catch (err: unknown) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to load settings');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, []);

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!doctor || !clinic) return;

    setSaving(true);
    setSuccessMsg(null);
    setErrorMsg(null);

    try {
      const res = await api.updateSettings({ doctor, clinic });
      setDoctor(res.doctor);
      setClinic(res.clinic);
      setSuccessMsg('Settings updated successfully!');
      setTimeout(() => setSuccessMsg(null), 4000);
    } catch (err: unknown) {
      setErrorMsg(err instanceof Error ? err.message : 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (newPassword !== confirmPassword) {
      setErrorMsg('New password and confirmation do not match.');
      return;
    }

    setSaving(true);
    try {
      await api.changePassword(currentPassword, newPassword);
      setSuccessMsg('Password changed successfully!');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setTimeout(() => setSuccessMsg(null), 4000);
    } catch (err: unknown) {
      setErrorMsg(err instanceof Error ? err.message : 'Password update failed');
    } finally {
      setSaving(false);
    }
  };

  const handleTestNotification = async () => {
    setTestingNotification(true);
    setTestResult(null);
    try {
      const res = await api.testNotification(testPhone, testMessage, forceFailWhatsApp);
      setTestResult(res.message);
    } catch (err: unknown) {
      setTestResult(`Error: ${err instanceof Error ? err.message : 'Dispatch error'}`);
    } finally {
      setTestingNotification(false);
    }
  };

  if (loading) {
    return (
      <div className="p-12 text-center text-slate-400 space-y-2">
        <div className="inline-block w-6 h-6 border-2 border-teal-600 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-xs">Loading clinic settings...</p>
      </div>
    );
  }

  if (!doctor || !clinic) return null;

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <span className="text-xs uppercase font-bold tracking-wider text-teal-700 font-sans">
          Configuration
        </span>
        <h2 className="text-2xl font-serif font-bold text-slate-900 mt-0.5">
          Clinic & System Settings
        </h2>
        <p className="text-xs text-slate-500">
          Update doctor credentials, clinic information, SMS & WhatsApp integrations, or security.
        </p>
      </div>

      {successMsg && (
        <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {errorMsg && (
        <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Tabs Bar */}
      <div className="flex border-b border-slate-200 overflow-x-auto gap-2">
        <button
          type="button"
          onClick={() => setActiveTab('doctor')}
          className={`py-2.5 px-4 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'doctor'
              ? 'border-teal-700 text-teal-800 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <User className="w-3.5 h-3.5" />
          <span>Doctor Profile</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('clinic')}
          className={`py-2.5 px-4 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'clinic'
              ? 'border-teal-700 text-teal-800 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Building className="w-3.5 h-3.5" />
          <span>Clinic Information</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('notifications')}
          className={`py-2.5 px-4 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'notifications'
              ? 'border-teal-700 text-teal-800 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <MessageSquare className="w-3.5 h-3.5" />
          <span>WhatsApp & SMS Gateway</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('password')}
          className={`py-2.5 px-4 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'password'
              ? 'border-teal-700 text-teal-800 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <KeyRound className="w-3.5 h-3.5" />
          <span>Password & Security</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('deployment')}
          className={`py-2.5 px-4 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'deployment'
              ? 'border-teal-700 text-teal-800 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Server className="w-3.5 h-3.5" />
          <span>Production & Setup Guide</span>
        </button>
      </div>

      {/* TAB 1: Doctor Profile Form */}
      {activeTab === 'doctor' && (
        <form onSubmit={handleSaveSettings} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-5 text-xs">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Doctor Full Name</label>
              <input
                type="text"
                value={doctor.name}
                onChange={(e) => setDoctor({ ...doctor, name: e.target.value })}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Degrees / Qualifications</label>
              <input
                type="text"
                value={doctor.degrees}
                onChange={(e) => setDoctor({ ...doctor, degrees: e.target.value })}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Specialization</label>
              <input
                type="text"
                value={doctor.specialization}
                onChange={(e) => setDoctor({ ...doctor, specialization: e.target.value })}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Years of Clinical Experience</label>
              <input
                type="number"
                value={doctor.experienceYears}
                onChange={(e) => setDoctor({ ...doctor, experienceYears: Number(e.target.value) })}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Medical Registration Number</label>
              <input
                type="text"
                value={doctor.registrationNumber}
                onChange={(e) => setDoctor({ ...doctor, registrationNumber: e.target.value })}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Medical Council Name</label>
              <input
                type="text"
                value={doctor.registrationCouncil}
                onChange={(e) => setDoctor({ ...doctor, registrationCouncil: e.target.value })}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Languages Spoken (comma-separated)</label>
            <input
              type="text"
              value={doctor.languages.join(', ')}
              onChange={(e) =>
                setDoctor({
                  ...doctor,
                  languages: e.target.value.split(',').map((s) => s.trim()).filter(Boolean)
                })
              }
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">About Doctor (Biography)</label>
            <textarea
              rows={4}
              value={doctor.about}
              onChange={(e) => setDoctor({ ...doctor, about: e.target.value })}
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg leading-relaxed"
            ></textarea>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold rounded-xl"
            >
              {saving ? 'Saving...' : 'Save Doctor Profile'}
            </button>
          </div>
        </form>
      )}

      {/* TAB 2: Clinic Information Form */}
      {activeTab === 'clinic' && (
        <form onSubmit={handleSaveSettings} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-5 text-xs">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Clinic Name</label>
              <input
                type="text"
                value={clinic.name}
                onChange={(e) => setClinic({ ...clinic, name: e.target.value })}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Tagline</label>
              <input
                type="text"
                value={clinic.tagline}
                onChange={(e) => setClinic({ ...clinic, tagline: e.target.value })}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Address Line 1</label>
              <input
                type="text"
                value={clinic.addressLine1}
                onChange={(e) => setClinic({ ...clinic, addressLine1: e.target.value })}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Address Line 2 (Landmark)</label>
              <input
                type="text"
                value={clinic.addressLine2}
                onChange={(e) => setClinic({ ...clinic, addressLine2: e.target.value })}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
              />
            </div>

            <div className="grid grid-cols-3 gap-2 md:col-span-2">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">City</label>
                <input
                  type="text"
                  value={clinic.city}
                  onChange={(e) => setClinic({ ...clinic, city: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">State</label>
                <input
                  type="text"
                  value={clinic.state}
                  onChange={(e) => setClinic({ ...clinic, state: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Postal Code</label>
                <input
                  type="text"
                  value={clinic.postalCode}
                  onChange={(e) => setClinic({ ...clinic, postalCode: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Clinic Phone Number</label>
              <input
                type="text"
                value={clinic.phone}
                onChange={(e) => setClinic({ ...clinic, phone: e.target.value })}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Emergency Helpline</label>
              <input
                type="text"
                value={clinic.emergencyPhone}
                onChange={(e) => setClinic({ ...clinic, emergencyPhone: e.target.value })}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Consultation Fee (₹)</label>
              <input
                type="number"
                value={clinic.consultationFee}
                onChange={(e) => setClinic({ ...clinic, consultationFee: Number(e.target.value) })}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg font-bold"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Google Maps Direction URL</label>
              <input
                type="text"
                value={clinic.googleMapsUrl}
                onChange={(e) => setClinic({ ...clinic, googleMapsUrl: e.target.value })}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Parking & Accessibility Information</label>
            <input
              type="text"
              value={clinic.parkingInfo}
              onChange={(e) => setClinic({ ...clinic, parkingInfo: e.target.value })}
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
            />
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold rounded-xl"
            >
              {saving ? 'Saving...' : 'Save Clinic Details'}
            </button>
          </div>
        </form>
      )}

      {/* TAB 3: WhatsApp & SMS Settings */}
      {activeTab === 'notifications' && (
        <div className="space-y-6">
          <form onSubmit={handleSaveSettings} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-5 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Notification API Settings</h3>
                <p className="text-slate-500 text-[11px]">
                  Preferred: WhatsApp API · Automatic Fallback: SMS
                </p>
              </div>
              <span className="text-[10px] text-teal-800 bg-teal-50 border border-teal-200 font-bold px-2 py-0.5 rounded">
                Dual Channel Active
              </span>
            </div>

            {/* Doctor Registered Phone */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Doctor Registered Mobile Number (Receives New Booking Notifications)
              </label>
              <input
                type="text"
                value={clinic.doctorPhoneNumber || ''}
                onChange={(e) => setClinic({ ...clinic, doctorPhoneNumber: e.target.value })}
                placeholder="+919876543210"
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg font-mono"
              />
              <p className="text-[10px] text-slate-400 mt-1">
                Configurable via DOCTOR_PHONE_NUMBER env var or here in settings.
              </p>
            </div>

            {/* WhatsApp Settings */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
              <span className="font-bold text-slate-900 block text-xs">
                Meta WhatsApp Business API Settings
              </span>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 mb-1 font-medium">WhatsApp API Token / Key</label>
                  <input
                    type="password"
                    value={clinic.whatsappApiKey || ''}
                    onChange={(e) => setClinic({ ...clinic, whatsappApiKey: e.target.value })}
                    placeholder="WHATSAPP_API_KEY (EAAG...)"
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 mb-1 font-medium">WhatsApp Phone Number ID</label>
                  <input
                    type="text"
                    value={clinic.whatsappPhoneNumberId || ''}
                    onChange={(e) => setClinic({ ...clinic, whatsappPhoneNumberId: e.target.value })}
                    placeholder="WHATSAPP_PHONE_NUMBER_ID (e.g. 104829104928)"
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg font-mono"
                  />
                </div>
              </div>
            </div>

            {/* SMS Gateway Settings */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
              <span className="font-bold text-slate-900 block text-xs">
                SMS Gateway Settings (Fallback)
              </span>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 mb-1 font-medium">SMS API Key</label>
                  <input
                    type="password"
                    value={clinic.smsApiKey || ''}
                    onChange={(e) => setClinic({ ...clinic, smsApiKey: e.target.value })}
                    placeholder="SMS_API_KEY"
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 mb-1 font-medium">SMS Sender ID</label>
                  <input
                    type="text"
                    value={clinic.smsSenderId || 'DRJDAS'}
                    onChange={(e) => setClinic({ ...clinic, smsSenderId: e.target.value })}
                    placeholder="SMS_SENDER_ID (e.g. DRJDAS)"
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg font-mono uppercase"
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                disabled={saving}
                className="px-6 py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold rounded-xl"
              >
                {saving ? 'Saving...' : 'Save Notification Keys'}
              </button>
            </div>
          </form>

          {/* Test Notification Simulator */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-4 text-xs">
            <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Send className="w-4 h-4 text-teal-700" />
              <span>Test Notification Dispatch & Fallback Simulation</span>
            </h4>
            <p className="text-slate-500">
              Verify your notification setup. You can also simulate a WhatsApp failure to watch the SMS fallback dispatch automatically.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Recipient Mobile</label>
                <input
                  type="text"
                  value={testPhone}
                  onChange={(e) => setTestPhone(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Message Content</label>
                <input
                  type="text"
                  value={testMessage}
                  onChange={(e) => setTestMessage(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>
            </div>

            <label className="flex items-center gap-2 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={forceFailWhatsApp}
                onChange={(e) => setForceFailWhatsApp(e.target.checked)}
                className="w-4 h-4 text-teal-600 rounded"
              />
              <span className="text-slate-700 font-semibold">
                Simulate WhatsApp failure (forces instant SMS fallback execution)
              </span>
            </label>

            {testResult && (
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-800 font-mono text-[11px]">
                {testResult}
              </div>
            )}

            <div>
              <button
                type="button"
                disabled={testingNotification}
                onClick={handleTestNotification}
                className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-xl"
              >
                {testingNotification ? 'Dispatching...' : 'Dispatch Test Alert'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: Password Change */}
      {activeTab === 'password' && (
        <form onSubmit={handleChangePassword} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-4 text-xs max-w-md">
          <h3 className="text-sm font-bold text-slate-900">Change Admin Password</h3>
          <p className="text-slate-500">
            Keep your doctor administrative credentials secure. Minimum 6 characters required.
          </p>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Current Password</label>
            <input
              type="password"
              required
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">New Password</label>
            <input
              type="password"
              required
              minLength={6}
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Confirm New Password</label>
            <input
              type="password"
              required
              minLength={6}
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold rounded-xl"
            >
              {saving ? 'Updating...' : 'Update Password'}
            </button>
          </div>
        </form>
      )}

      {/* TAB 5: Production & Setup Guide (As explicitly requested by prompt) */}
      {activeTab === 'deployment' && (
        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-2xs space-y-6 text-xs text-slate-700">
          <div>
            <span className="text-[10px] uppercase font-bold tracking-wider text-teal-700 font-sans">
              Documentation & Operations
            </span>
            <h3 className="text-lg font-bold text-slate-900 mt-0.5">
              Production Deployment & Integration Checklist
            </h3>
            <p className="text-slate-500 mt-1">
              Follow these setup instructions to deploy this application to a real production VPS, Cloud Run, or Docker container.
            </p>
          </div>

          <div className="space-y-4">
            {/* 1. Database */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5">
              <span className="font-bold text-slate-900 text-xs">1. Database Setup</span>
              <p className="text-slate-600 leading-relaxed">
                The current system utilizes an atomic, file-persisted JSON database engine located at <code className="bg-white px-1.5 py-0.5 rounded border border-slate-200 font-mono text-[11px]">/data/clinic-db.json</code> with in-memory caching and lock protection. For multi-instance horizontal scaling, connect PostgreSQL using Drizzle or Cloud SQL.
              </p>
            </div>

            {/* 2. Admin Account */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5">
              <span className="font-bold text-slate-900 text-xs">2. Admin Account</span>
              <p className="text-slate-600 leading-relaxed">
                Default initial credentials: <code className="bg-white px-1.5 py-0.5 rounded border border-slate-200 font-mono text-[11px]">doctor@drjagadishdas.com</code> / <code className="bg-white px-1.5 py-0.5 rounded border border-slate-200 font-mono text-[11px]">Doctor@2026</code>. You should change this password via the <strong>Password & Security</strong> tab immediately after initial deployment.
              </p>
            </div>

            {/* 3. WhatsApp API */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5">
              <span className="font-bold text-slate-900 text-xs">3. WhatsApp API (Meta Cloud API)</span>
              <p className="text-slate-600 leading-relaxed">
                Create a Meta for Developers account → Create a Business App → Add WhatsApp product → Obtain permanent System User Access Token and Phone Number ID. Configure <code className="bg-white px-1.5 py-0.5 rounded border border-slate-200 font-mono text-[11px]">WHATSAPP_API_KEY</code> and <code className="bg-white px-1.5 py-0.5 rounded border border-slate-200 font-mono text-[11px]">WHATSAPP_PHONE_NUMBER_ID</code>.
              </p>
            </div>

            {/* 4. SMS API */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5">
              <span className="font-bold text-slate-900 text-xs">4. SMS API (Fallback Gateway)</span>
              <p className="text-slate-600 leading-relaxed">
                Register on Fast2SMS, Twilio, or Gupshup → Whitelist approved DLT Sender ID (e.g. <code className="bg-white px-1.5 py-0.5 rounded border border-slate-200 font-mono text-[11px]">DRJDAS</code>) → Set <code className="bg-white px-1.5 py-0.5 rounded border border-slate-200 font-mono text-[11px]">SMS_API_KEY</code> and <code className="bg-white px-1.5 py-0.5 rounded border border-slate-200 font-mono text-[11px]">SMS_SENDER_ID</code> in environment.
              </p>
            </div>

            {/* 5. Google Maps */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5">
              <span className="font-bold text-slate-900 text-xs">5. Google Maps Location</span>
              <p className="text-slate-600 leading-relaxed">
                Search your clinic on Google Maps → Click 'Share' → Copy 'Link to share' for <code className="bg-white px-1.5 py-0.5 rounded border border-slate-200 font-mono text-[11px]">googleMapsUrl</code> and 'Embed a map' HTML iframe link for <code className="bg-white px-1.5 py-0.5 rounded border border-slate-200 font-mono text-[11px]">googleMapsEmbedUrl</code>.
              </p>
            </div>

            {/* 6. Domain, Hosting & SSL */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5">
              <span className="font-bold text-slate-900 text-xs">6. Domain, Hosting & HTTPS/SSL</span>
              <p className="text-slate-600 leading-relaxed">
                Host on Ubuntu VPS (Nginx + PM2) or Google Cloud Run. For SSL, run <code className="bg-white px-1.5 py-0.5 rounded border border-slate-200 font-mono text-[11px]">certbot --nginx -d drjagadishdas.com</code> to provision free auto-renewing Let's Encrypt certificates.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
