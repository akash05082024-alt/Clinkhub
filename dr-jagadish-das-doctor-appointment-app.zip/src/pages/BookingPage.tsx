import React, { useState } from 'react';
import { PublicClinicInfo, Appointment } from '../types';
import { AppointmentBookingSection } from '../components/AppointmentBookingSection';
import { ConfirmationView } from '../components/ConfirmationView';

interface BookingPageProps {
  clinicInfo?: PublicClinicInfo | null;
  onAppointmentConfirmed?: (appointment: Appointment) => void;
}

export const BookingPage: React.FC<BookingPageProps> = ({
  clinicInfo,
  onAppointmentConfirmed
}) => {
  const [confirmedAppt, setConfirmedAppt] = useState<Appointment | null>(null);

  const handleBookingSuccess = (appt: Appointment) => {
    setConfirmedAppt(appt);
    if (onAppointmentConfirmed) {
      onAppointmentConfirmed(appt);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      {confirmedAppt ? (
        <ConfirmationView
          appointment={confirmedAppt}
          clinicInfo={clinicInfo}
          onBookAnother={() => setConfirmedAppt(null)}
        />
      ) : (
        <div className="space-y-6">
          <div className="border-b border-slate-200 pb-5 text-center max-w-2xl mx-auto">
            <span className="text-xs uppercase font-bold tracking-wider text-teal-700 font-sans">
              Online Scheduling
            </span>
            <h1 className="text-3xl font-serif font-bold text-slate-900 mt-1">
              Select Your Appointment Slot
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Real-time schedule with Dr. Jagadish Das (MBBS). Slots are locked immediately upon booking to prevent double-booking.
            </p>
          </div>

          <AppointmentBookingSection
            clinicInfo={clinicInfo}
            onBookingSuccess={handleBookingSuccess}
          />
        </div>
      )}
    </div>
  );
};
