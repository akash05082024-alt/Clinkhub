import React from 'react';
import { Building, MapPin, Phone, Clock, Car, Compass, Calendar, ShieldCheck, Mail, AlertCircle } from 'lucide-react';
import { PublicClinicInfo } from '../types';
import { ClinicMapSection } from '../components/ClinicMapSection';

interface ClinicPageProps {
  clinicInfo?: PublicClinicInfo | null;
  onBookClick: () => void;
}

export const ClinicPage: React.FC<ClinicPageProps> = ({ clinicInfo, onBookClick }) => {
  const clinic = clinicInfo?.clinic;
  const doctor = clinicInfo?.doctor;

  const fullAddress = clinic
    ? `${clinic.addressLine1}, ${clinic.addressLine2}, ${clinic.city}, ${clinic.state} - ${clinic.postalCode}`
    : 'Suite 204, 2nd Floor, Care Health Complex, Station Road, Kolkata, West Bengal - 700001';

  return (
    <div className="space-y-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      {/* Top Header */}
      <div className="border-b border-slate-200 pb-5">
        <span className="text-xs uppercase font-bold tracking-wider text-teal-700 font-sans">
          Facilities & Visiting Information
        </span>
        <h1 className="text-3xl sm:text-4xl font-serif font-bold text-slate-900 mt-1">
          {clinic?.name || 'Arogya Health & Consultation Clinic'}
        </h1>
        <p className="text-sm text-slate-600 mt-1">
          {clinic?.tagline || 'Compassionate, ethical outpatient care in a modern, accessible setting.'}
        </p>
      </div>

      {/* Facilities Key Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-3">
          <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center">
            <Clock className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900">Consultation Timings</h3>
          <div className="space-y-1.5 text-slate-600">
            <p><strong>Monday – Saturday:</strong></p>
            <p>Morning: 10:00 AM – 01:00 PM</p>
            <p>Evening: 05:00 PM – 08:00 PM</p>
            <p className="text-[11px] text-slate-400 pt-1">Sunday Closed (Emergency on call)</p>
          </div>
        </div>

        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-3">
          <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center">
            <Car className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900">Parking & Accessibility</h3>
          <p className="text-slate-600 leading-relaxed">
            {clinic?.parkingInfo ||
              'Dedicated basement and street parking available for cars and two-wheelers. Complete wheelchair accessibility via ground ramp and wide stretcher elevator to 2nd floor suite.'}
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-3">
          <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900">Consultation Terms</h3>
          <div className="space-y-1 text-slate-600">
            <p>Standard Outpatient Fee: <strong className="text-slate-900 text-sm">₹{clinic?.consultationFee || 500}</strong></p>
            <p className="text-[11px]">Includes vitals screening and comprehensive diagnostic prescription.</p>
            <p className="text-[11px] text-teal-700 font-semibold pt-1">Cash, UPI & Debit Cards accepted</p>
          </div>
        </div>
      </div>

      {/* Embedded Map Section */}
      <ClinicMapSection clinicInfo={clinicInfo} onBookClick={onBookClick} />

      {/* Patient Notice Card */}
      <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
        <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-teal-700" />
          <span>Patient Visit Guidelines</span>
        </h4>
        <p className="text-slate-600 leading-relaxed">
          {clinic?.notice ||
            'Please bring your previous prescriptions, diagnostic test reports, and government ID card for your appointment. Arrive 10 to 15 minutes ahead of your reserved slot for vitals registration.'}
        </p>
      </div>

      {/* Primary CTA */}
      <div className="p-8 rounded-3xl bg-slate-900 text-white flex flex-col sm:flex-row items-center justify-between gap-6">
        <div>
          <h3 className="text-2xl font-serif font-bold">Schedule Your Clinic Consultation</h3>
          <p className="text-xs text-slate-300 mt-1">
            Book online to avoid waiting room queues. Instant appointment confirmation.
          </p>
        </div>
        <button
          onClick={onBookClick}
          className="px-6 py-3.5 bg-teal-400 hover:bg-teal-300 text-slate-900 rounded-xl font-bold text-sm shadow-md transition-all shrink-0"
        >
          Book Consultation Slot
        </button>
      </div>
    </div>
  );
};
