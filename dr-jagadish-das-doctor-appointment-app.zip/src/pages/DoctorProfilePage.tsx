import React from 'react';
import {
  Calendar,
  Phone,
  Compass,
  Award,
  Clock,
  ShieldCheck,
  Stethoscope,
  Globe,
  MapPin,
  CheckCircle2,
  FileCheck,
  ArrowRight
} from 'lucide-react';
import { PublicClinicInfo } from '../types';

interface DoctorProfilePageProps {
  clinicInfo?: PublicClinicInfo | null;
  onBookClick: () => void;
}

export const DoctorProfilePage: React.FC<DoctorProfilePageProps> = ({ clinicInfo, onBookClick }) => {
  const doctor = clinicInfo?.doctor;
  const clinic = clinicInfo?.clinic;

  const doctorName = doctor?.name || 'Dr. Jagadish Das';
  const degrees = doctor?.degrees || 'MBBS';
  const specialization = doctor?.specialization || 'General Medicine / Consultant Physician';
  const experienceYears = doctor?.experienceYears || 14;
  const regNumber = doctor?.registrationNumber || 'WBMC-64821';
  const regCouncil = doctor?.registrationCouncil || 'West Bengal Medical Council';
  const fee = clinic?.consultationFee || 500;
  const languages = doctor?.languages || ['English', 'Bengali', 'Hindi'];
  const photoUrl = doctor?.photoUrl || '/doctor-avatar.svg';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      {/* Top Breadcrumb & Title */}
      <div className="border-b border-slate-200 pb-5">
        <span className="text-xs uppercase font-bold tracking-wider text-teal-700 font-sans">
          Medical Practitioner Credentials
        </span>
        <h1 className="text-3xl sm:text-4xl font-serif font-bold text-slate-900 mt-1">
          Professional Doctor Profile
        </h1>
        <p className="text-sm text-slate-600 mt-1">
          Detailed background, certified degrees, clinical registrations, and outpatient consultation terms.
        </p>
      </div>

      {/* Main Profile Header Card */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Photo & Quick Badges - 4 Cols */}
          <div className="lg:col-span-4 flex flex-col items-center text-center">
            <div className="w-52 h-52 sm:w-60 sm:h-60 rounded-full overflow-hidden p-1.5 bg-gradient-to-tr from-teal-600 via-teal-400 to-cyan-500 shadow-lg">
              <img
                src={photoUrl}
                alt={doctorName}
                className="w-full h-full object-cover rounded-full bg-slate-100"
              />
            </div>

            <div className="mt-5 space-y-1">
              <span className="inline-block px-3 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-semibold rounded-full">
                Active Practicing License
              </span>
              <p className="text-xs text-slate-500 font-mono pt-1">
                Medical Council Registration: <br />
                <strong className="text-slate-800 text-sm">{regNumber}</strong>
              </p>
              <p className="text-[11px] text-slate-400">{regCouncil}</p>
            </div>

            <div className="w-full mt-6 space-y-2">
              <button
                onClick={onBookClick}
                className="w-full py-3.5 px-4 bg-teal-700 hover:bg-teal-800 active:bg-teal-900 text-white rounded-xl font-bold text-sm shadow-sm flex items-center justify-center gap-2 transition-all"
              >
                <Calendar className="w-4 h-4" />
                <span>Book Consultation Slot</span>
              </button>
              <a
                href={`tel:${(clinic?.phone || '+919876543210').replace(/\s+/g, '')}`}
                className="w-full py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl font-semibold text-xs flex items-center justify-center gap-2 transition-colors"
              >
                <Phone className="w-3.5 h-3.5 text-teal-700" />
                <span>Call Clinic Desk</span>
              </a>
            </div>
          </div>

          {/* Details & Credentials - 8 Cols */}
          <div className="lg:col-span-8 space-y-6">
            <div>
              <div className="flex flex-wrap items-baseline gap-2">
                <h2 className="text-3xl font-serif font-bold text-slate-900">{doctorName}</h2>
                <span className="text-lg font-bold text-teal-700 font-sans tracking-wide">({degrees})</span>
              </div>
              <p className="text-sm font-semibold text-slate-700 mt-1">{specialization}</p>
              <p className="text-xs text-slate-500 mt-0.5">
                {experienceYears}+ Years of Clinical Outpatient Experience
              </p>
            </div>

            {/* Quick Summary Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80">
                <span className="text-slate-500 block text-[11px] font-medium">Consultation Fee</span>
                <span className="text-lg font-bold text-slate-900 block mt-0.5">₹{fee}</span>
                <span className="text-[10px] text-slate-500">Payable at clinic desk</span>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80">
                <span className="text-slate-500 block text-[11px] font-medium">Languages Spoken</span>
                <span className="text-xs font-semibold text-slate-900 block mt-1">
                  {languages.join(', ')}
                </span>
                <span className="text-[10px] text-slate-500">Fluency in consultations</span>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80">
                <span className="text-slate-500 block text-[11px] font-medium">Consultation Hours</span>
                <span className="text-xs font-semibold text-slate-900 block mt-1">
                  10 AM–1 PM & 5 PM–8 PM
                </span>
                <span className="text-[10px] text-slate-500">Monday to Saturday</span>
              </div>
            </div>

            {/* About Doctor Section */}
            <div className="space-y-3 pt-2">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Stethoscope className="w-4 h-4 text-teal-700" />
                <span>About Dr. Jagadish Das</span>
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-sans">
                {doctor?.about ||
                  'Dr. Jagadish Das (MBBS) has dedicated his career to delivering ethical, thorough, and accessible primary healthcare. With more than a decade of experience across hospital wards and outpatient clinics, he excels in diagnostic accuracy, systematic fever evaluations, cardiovascular screening, diabetes control, and elder care.'}
              </p>
            </div>

            {/* Qualifications / Degrees */}
            <div className="space-y-3 pt-2">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Award className="w-4 h-4 text-teal-700" />
                <span>Degrees & Medical Education</span>
              </h3>
              <div className="space-y-2.5">
                {(doctor?.qualifications || []).map((q, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex justify-between items-center text-xs"
                  >
                    <div>
                      <span className="font-bold text-slate-900 block">{q.degree}</span>
                      <span className="text-slate-500 text-[11px]">{q.institution}</span>
                    </div>
                    <span className="font-mono text-teal-800 font-semibold px-2 py-0.5 bg-white border border-slate-200 rounded">
                      {q.year}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Clinic Affiliation Details */}
            <div className="p-4 rounded-2xl bg-teal-50/70 border border-teal-200/80 space-y-2 text-xs">
              <div className="flex items-center gap-2 text-teal-900 font-bold">
                <MapPin className="w-4 h-4 text-teal-700" />
                <span>Primary Clinic Facility</span>
              </div>
              <p className="text-slate-700 leading-snug">
                <strong className="text-slate-900">{clinic?.name || 'Arogya Health & Consultation Clinic'}</strong>
                <br />
                {clinic?.addressLine1}, {clinic?.addressLine2}, {clinic?.city}, {clinic?.state} - {clinic?.postalCode}
              </p>
              <p className="text-[11px] text-teal-900 pt-1">
                Equipped with basic vitals monitoring, glucometer testing, nebulizer support, and ECG coordination.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Services Section */}
      <div className="space-y-6">
        <div>
          <span className="text-xs uppercase font-bold tracking-wider text-teal-700 font-sans">
            Specialized Care
          </span>
          <h2 className="text-2xl font-serif font-bold text-slate-900 mt-1">
            Clinical Services & Treatments
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {(doctor?.services || []).map((srv, idx) => (
            <div
              key={idx}
              className="p-6 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-3"
            >
              <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center font-bold">
                {idx + 1}
              </div>
              <h3 className="text-base font-bold text-slate-900">{srv.title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed">{srv.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Booking Banner */}
      <div className="p-8 rounded-3xl bg-slate-900 text-white flex flex-col sm:flex-row items-center justify-between gap-6">
        <div>
          <h3 className="text-2xl font-serif font-bold">Ready to Consult Dr. Jagadish Das?</h3>
          <p className="text-xs text-slate-300 mt-1">
            Consultation Fee: ₹{fee} · Instant online slot reservation · Real-time SMS & WhatsApp alerts
          </p>
        </div>
        <button
          onClick={onBookClick}
          className="px-6 py-3.5 bg-teal-400 hover:bg-teal-300 text-slate-900 rounded-xl font-bold text-sm shadow-md transition-all shrink-0"
        >
          Book Appointment Now
        </button>
      </div>
    </div>
  );
};
