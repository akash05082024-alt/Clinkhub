import React, { useState } from 'react';
import { Search, Calendar, Phone, AlertCircle, FileText, ArrowRight } from 'lucide-react';
import { api } from '../api';
import { Appointment, PublicClinicInfo } from '../types';
import { ConfirmationView } from '../components/ConfirmationView';

interface FindAppointmentPageProps {
  clinicInfo?: PublicClinicInfo | null;
  onBookClick: () => void;
  initialAppointmentId?: string;
}

export const FindAppointmentPage: React.FC<FindAppointmentPageProps> = ({
  clinicInfo,
  onBookClick,
  initialAppointmentId = ''
}) => {
  const [searchId, setSearchId] = useState<string>(initialAppointmentId);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [appointment, setAppointment] = useState<Appointment | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchId.trim()) return;

    setLoading(true);
    setError(null);
    setAppointment(null);

    try {
      const res = await api.getAppointmentById(searchId.trim());
      setAppointment(res.appointment);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Could not find an appointment with this ID.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <div className="border-b border-slate-200 pb-5 text-center max-w-xl mx-auto">
        <span className="text-xs uppercase font-bold tracking-wider text-teal-700 font-sans">
          Patient Self-Service
        </span>
        <h1 className="text-3xl font-serif font-bold text-slate-900 mt-1">
          Find Your Appointment
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 mt-1">
          Enter your unique Appointment ID (e.g. <strong className="font-mono text-slate-900">APT-2026-0001</strong>) to view status, add to your calendar, or cancel.
        </p>
      </div>

      {/* Search Bar */}
      <form onSubmit={handleSearch} className="max-w-md mx-auto">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              placeholder="e.g. APT-2026-0001"
              value={searchId}
              onChange={(e) => setSearchId(e.target.value.toUpperCase())}
              className="w-full pl-9 pr-3 py-3 text-sm font-mono uppercase bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-teal-600"
            />
          </div>
          <button
            type="submit"
            disabled={loading || !searchId.trim()}
            className="px-5 py-3 text-xs font-bold text-white bg-teal-700 hover:bg-teal-800 disabled:bg-slate-300 rounded-xl transition-colors shadow-sm"
          >
            {loading ? 'Searching...' : 'Search'}
          </button>
        </div>

        {error && (
          <div className="mt-4 p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
      </form>

      {/* Result Display */}
      {appointment ? (
        <div className="pt-2">
          <ConfirmationView
            appointment={appointment}
            clinicInfo={clinicInfo}
            onBookAnother={onBookClick}
            onAppointmentUpdated={(upd) => setAppointment(upd)}
          />
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center max-w-lg mx-auto space-y-4">
          <FileText className="w-10 h-10 text-slate-300 mx-auto" />
          <div>
            <h3 className="text-sm font-bold text-slate-800">Don't have an Appointment ID yet?</h3>
            <p className="text-xs text-slate-500 mt-1">
              You can book a new clinic consultation with Dr. Jagadish Das in under a minute.
            </p>
          </div>
          <button
            type="button"
            onClick={onBookClick}
            className="px-6 py-2.5 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-semibold shadow-sm inline-flex items-center gap-1.5"
          >
            <span>Book New Appointment Online</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};
