import React from 'react';
import {
  Calendar,
  Phone,
  Compass,
  Award,
  Clock,
  ShieldCheck,
  Stethoscope,
  HeartPulse,
  Activity,
  Thermometer,
  FileText,
  CheckCircle2,
  Users,
  ChevronRight,
  ArrowRight,
  Building,
  MapPin,
  AlertCircle
} from 'lucide-react';
import { PublicClinicInfo, Appointment } from '../types';
import { AppointmentBookingSection } from '../components/AppointmentBookingSection';
import { ClinicMapSection } from '../components/ClinicMapSection';

interface HomePageProps {
  clinicInfo?: PublicClinicInfo | null;
  onNavigate: (tab: string) => void;
  onBookingSuccess: (appointment: Appointment) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ clinicInfo, onNavigate, onBookingSuccess }) => {
  const doctor = clinicInfo?.doctor;
  const clinic = clinicInfo?.clinic;

  const doctorName = doctor?.name || 'Dr. Jagadish Das';
  const degrees = doctor?.degrees || 'MBBS';
  const specialization = doctor?.specialization || 'General Medicine / Consultant Physician';
  const experienceYears = doctor?.experienceYears || 14;
  const clinicName = clinic?.name || 'Arogya Health & Consultation Clinic';
  const clinicPhone = clinic?.phone || '+91 98765 43210';
  const clinicAddress = clinic
    ? `${clinic.addressLine1}, ${clinic.addressLine2}, ${clinic.city}`
    : 'Suite 204, Care Health Complex, Station Road, Kolkata';
  const mapsUrl = clinic?.googleMapsUrl || 'https://maps.google.com';

  const scrollToBooking = () => {
    const el = document.getElementById('booking-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    } else {
      onNavigate('book');
    }
  };

  return (
    <div className="space-y-16">
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden bg-gradient-to-b from-slate-900 via-slate-900 to-slate-800 text-white pt-12 pb-20 lg:pt-16 lg:pb-28">
        {/* Soft atmospheric medical glow background */}
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-10 w-80 h-80 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Content - 7 Cols */}
            <div className="lg:col-span-7 space-y-6">
              {/* Doctor credential header kicker */}
              <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-teal-300 font-sans">
                <span className="w-2 h-2 rounded-full bg-teal-400"></span>
                <span>Consultant Physician & Primary Care</span>
                <span className="text-slate-500">·</span>
                <span>{experienceYears}+ Years Clinical Experience</span>
              </div>

              {/* Main Headline */}
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-serif font-bold text-white tracking-tight leading-[1.12]">
                Book Your Appointment <span className="text-teal-400 italic font-serif">Online</span>
              </h1>

              {/* Lead Paragraph */}
              <p className="text-base sm:text-lg text-slate-300 max-w-2xl font-sans font-light leading-relaxed">
                Consult with <strong className="text-white font-semibold">{doctorName}</strong> ({degrees}) for
                evidence-based diagnosis, fever management, chronic health checkups, and compassionate family healthcare.
                Real-time slot availability with instant SMS & WhatsApp confirmations.
              </p>

              {/* Doctor Brief Info Strip */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-xs grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                <div>
                  <span className="text-slate-400 block text-[11px]">Doctor</span>
                  <span className="font-bold text-white text-sm font-serif">{doctorName}</span>
                  <span className="text-teal-300 block">{degrees}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Clinic Location</span>
                  <span className="font-semibold text-white truncate block">{clinicName}</span>
                  <span className="text-slate-300 text-[11px] truncate block">{clinicAddress}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Consultation Timings</span>
                  <span className="font-bold text-white block">10:00 AM – 1:00 PM</span>
                  <span className="text-slate-300 text-[11px] block">05:00 PM – 8:00 PM (Mon–Sat)</span>
                </div>
              </div>

              {/* Hero Action Buttons */}
              <div className="pt-2 flex flex-wrap items-center gap-3 sm:gap-4">
                {/* 1. Primary CTA: Book Appointment */}
                <button
                  onClick={scrollToBooking}
                  className="px-7 py-3.5 rounded-xl text-sm font-bold text-slate-900 bg-teal-400 hover:bg-teal-300 active:bg-teal-500 shadow-lg shadow-teal-500/20 flex items-center gap-2.5 transition-all hover:scale-[1.02]"
                >
                  <Calendar className="w-4 h-4 text-slate-900" />
                  <span>Book Appointment</span>
                </button>

                {/* 2. Call Now */}
                <a
                  href={`tel:${clinicPhone.replace(/\s+/g, '')}`}
                  className="px-6 py-3.5 rounded-xl text-sm font-semibold text-white bg-white/10 hover:bg-white/15 border border-white/15 flex items-center gap-2 transition-colors"
                >
                  <Phone className="w-4 h-4 text-teal-300" />
                  <span>Call Now</span>
                </a>

                {/* 3. Get Directions */}
                <a
                  href={mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-5 py-3.5 rounded-xl text-sm font-semibold text-slate-300 hover:text-white flex items-center gap-1.5 transition-colors"
                >
                  <Compass className="w-4 h-4 text-teal-400" />
                  <span>Get Directions ↗</span>
                </a>
              </div>

              {/* Consultation Fee and Guarantee notice */}
              <div className="pt-2 flex items-center gap-6 text-xs text-slate-400">
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-teal-400" />
                  <span>Official Consultation Fee: ₹{clinic?.consultationFee || 500}</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-teal-400" />
                  <span>Zero Waiting via Prior Slot Booking</span>
                </span>
              </div>
            </div>

            {/* Right Card / Doctor Portrait - 5 Cols */}
            <div className="lg:col-span-5 flex justify-center">
              <div className="relative w-full max-w-md bg-white rounded-3xl p-6 sm:p-8 text-slate-900 shadow-2xl border border-slate-100">
                {/* Doctor Avatar / Image placeholder */}
                <div className="relative w-44 h-44 sm:w-52 sm:h-52 mx-auto rounded-full overflow-hidden p-1.5 bg-gradient-to-tr from-teal-600 via-teal-400 to-cyan-500 shadow-md">
                  <img
                    src={doctor?.photoUrl || '/doctor-avatar.svg'}
                    alt={doctorName}
                    className="w-full h-full object-cover rounded-full bg-slate-100"
                  />
                  <div className="absolute bottom-2 right-2 bg-teal-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full border-2 border-white shadow">
                    VERIFIED MBBS
                  </div>
                </div>

                <div className="text-center mt-5 space-y-1.5">
                  <h3 className="text-2xl font-bold font-serif text-slate-900">{doctorName}</h3>
                  <p className="text-xs font-semibold text-teal-800 tracking-wide uppercase font-sans">
                    {degrees} · {specialization}
                  </p>
                  <p className="text-xs text-slate-500 font-mono">
                    Council Reg. No: {doctor?.registrationNumber || 'WBMC-64821'}
                  </p>
                </div>

                <div className="mt-6 pt-5 border-t border-slate-100 grid grid-cols-2 gap-3 text-center text-xs">
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                    <span className="text-slate-500 block text-[10px] uppercase font-semibold">Experience</span>
                    <span className="text-base font-bold text-slate-900">{experienceYears}+ Years</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                    <span className="text-slate-500 block text-[10px] uppercase font-semibold">Consultation Fee</span>
                    <span className="text-base font-bold text-slate-900">₹{clinic?.consultationFee || 500}</span>
                  </div>
                </div>

                <div className="mt-5 space-y-2">
                  <button
                    onClick={scrollToBooking}
                    className="w-full py-3 text-center text-xs font-bold text-white bg-teal-700 hover:bg-teal-800 rounded-xl transition-all shadow-sm flex items-center justify-center gap-1.5"
                  >
                    <span>Check Available Slots</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onNavigate('profile')}
                    className="w-full py-2 text-center text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors"
                  >
                    View Detailed Doctor Credentials →
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. DOCTOR INTRO & QUALIFICATIONS SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-6 space-y-5">
            <span className="text-xs uppercase font-bold tracking-wider text-teal-700 font-sans">
              About The Doctor
            </span>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-slate-900 leading-tight">
              Experienced, Ethical & Patient-Centric Healthcare
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed font-sans">
              {doctor?.about ||
                'Dr. Jagadish Das (MBBS) is a trusted General Physician dedicated to providing accessible, evidence-based primary medical care. With a focus on thorough diagnosis and clear patient communication, Dr. Das handles outpatient ailments, infectious diseases, and continuous management of chronic conditions.'}
            </p>

            <div className="space-y-3 pt-2 text-xs">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900">Bachelor of Medicine, Bachelor of Surgery (MBBS):</strong>
                  <p className="text-slate-500 text-[11px]">Calcutta National Medical College & Hospital (2012)</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900">Active Medical Council Registration:</strong>
                  <p className="text-slate-500 text-[11px]">
                    Registered with West Bengal Medical Council · Reg No. {doctor?.registrationNumber || 'WBMC-64821'}
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900">Multilingual Consultation:</strong>
                  <p className="text-slate-500 text-[11px]">
                    Fluent in English, Bengali, and Hindi for clear patient understanding.
                  </p>
                </div>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => onNavigate('profile')}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-teal-800 hover:text-teal-900 hover:underline"
              >
                <span>Read Full Professional Background & Experience</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="lg:col-span-6 bg-slate-50 p-6 sm:p-8 rounded-3xl border border-slate-200 space-y-4">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Award className="w-5 h-5 text-teal-700" />
              <span>Key Qualifications & Training</span>
            </h3>

            <div className="space-y-3 text-xs">
              {doctor?.qualifications.map((q, idx) => (
                <div key={idx} className="p-3.5 rounded-xl bg-white border border-slate-200/80 shadow-2xs">
                  <div className="flex justify-between items-start">
                    <span className="font-bold text-slate-900">{q.degree}</span>
                    <span className="font-mono text-[11px] text-teal-700 font-semibold">{q.year}</span>
                  </div>
                  <p className="text-slate-500 text-[11px] mt-0.5">{q.institution}</p>
                </div>
              ))}
            </div>

            <div className="p-4 rounded-xl bg-teal-50 border border-teal-100 text-xs text-teal-950 space-y-1">
              <p className="font-bold">Clinic Consultation Ethos</p>
              <p className="text-[11px] text-teal-800 leading-relaxed">
                Every consultation provides adequate time for clinical listening, vital sign measurement, tailored diagnostic prescription, and structured follow-up advice.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 3. PRIMARY ONLINE BOOKING SYSTEM SECTION (Target of CTA) */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 pt-4 scroll-mt-24" id="booking-section">
        <div className="text-center max-w-2xl mx-auto mb-8">
          <span className="text-xs uppercase font-bold tracking-wider text-teal-700 font-sans">
            Instant Online Schedule
          </span>
          <h2 className="text-3xl font-serif font-bold text-slate-900 mt-1">
            Check Real-Time Available Slots
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            Pick a date, select your slot, and secure your appointment in under 60 seconds.
          </p>
        </div>

        {/* The interactive booking wizard component */}
        <AppointmentBookingSection
          clinicInfo={clinicInfo}
          onBookingSuccess={onBookingSuccess}
        />
      </section>

      {/* 4. SERVICES OFFERED */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" id="services-section">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs uppercase font-bold tracking-wider text-teal-700 font-sans">
            Clinical Care Areas
          </span>
          <h2 className="text-3xl font-serif font-bold text-slate-900 mt-1">
            Services & Consultations
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            Comprehensive primary medical care delivered with clinical accuracy and empathy.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {(doctor?.services || []).map((srv, idx) => (
            <div
              key={idx}
              className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-2xs hover:shadow-md hover:border-teal-500/50 transition-all flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center">
                  <Stethoscope className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-slate-900">{srv.title}</h3>
                <p className="text-xs text-slate-600 leading-relaxed">{srv.description}</p>
              </div>

              <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-400 font-mono text-[11px]">Fee: ₹{clinic?.consultationFee || 500}</span>
                <button
                  type="button"
                  onClick={scrollToBooking}
                  className="font-semibold text-teal-700 hover:text-teal-800 hover:underline flex items-center gap-1"
                >
                  <span>Book Slot</span>
                  <span>→</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. CLINIC INFORMATION & GOOGLE MAPS SECTION */}
      <ClinicMapSection clinicInfo={clinicInfo} onBookClick={scrollToBooking} />

      {/* 6. EMERGENCY / URGENT CARE ADVISORY SECTION */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 pb-10">
        <div className="p-6 rounded-2xl bg-amber-50/70 border border-amber-200 text-amber-950 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="p-2.5 rounded-xl bg-amber-100 text-amber-800 shrink-0">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h4 className="text-base font-bold text-amber-950">Emergency & Critical Care Advisory</h4>
              <p className="text-xs text-amber-900 leading-relaxed max-w-2xl">
                This clinic platform is for outpatient appointments. In cases of acute chest pain, sudden paralysis, unconsciousness, severe asthma attacks, or heavy bleeding, immediately contact the national emergency ambulance (102 / 112) or reach your nearest emergency hospital.
              </p>
            </div>
          </div>
          <a
            href={`tel:${(clinic?.emergencyPhone || '+919876543211').replace(/\s+/g, '')}`}
            className="shrink-0 px-5 py-2.5 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-bold shadow-sm transition-colors text-center"
          >
            Emergency Helpline: {clinic?.emergencyPhone || '+91 98765 43211'}
          </a>
        </div>
      </section>
    </div>
  );
};
