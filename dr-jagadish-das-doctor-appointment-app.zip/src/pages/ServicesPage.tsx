import React from 'react';
import { Stethoscope, CheckCircle2, ShieldCheck, HeartPulse, Activity, Thermometer, FileText, ArrowRight } from 'lucide-react';
import { PublicClinicInfo } from '../types';

interface ServicesPageProps {
  clinicInfo?: PublicClinicInfo | null;
  onBookClick: () => void;
}

export const ServicesPage: React.FC<ServicesPageProps> = ({ clinicInfo, onBookClick }) => {
  const doctor = clinicInfo?.doctor;
  const clinic = clinicInfo?.clinic;

  const services = doctor?.services || [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      {/* Header */}
      <div className="border-b border-slate-200 pb-5">
        <span className="text-xs uppercase font-bold tracking-wider text-teal-700 font-sans">
          Clinical Practice
        </span>
        <h1 className="text-3xl sm:text-4xl font-serif font-bold text-slate-900 mt-1">
          Medical Services & Care Areas
        </h1>
        <p className="text-sm text-slate-600 mt-1">
          Provided by <strong className="text-slate-800">Dr. Jagadish Das (MBBS)</strong> at {clinic?.name || 'Arogya Clinic'}.
        </p>
      </div>

      {/* Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {services.map((srv, idx) => (
          <div
            key={idx}
            className="p-6 rounded-3xl bg-white border border-slate-200 shadow-2xs hover:shadow-md hover:border-teal-500/50 transition-all flex flex-col justify-between"
          >
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center font-bold">
                <Stethoscope className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 font-serif">{srv.title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed font-sans">{srv.description}</p>
            </div>

            <div className="pt-6 mt-6 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-500 font-medium">Fee: ₹{clinic?.consultationFee || 500}</span>
              <button
                type="button"
                onClick={onBookClick}
                className="font-bold text-teal-700 hover:text-teal-800 flex items-center gap-1"
              >
                <span>Book Slot</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Diagnostic & Lab Advisory Notice */}
      <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-xs text-slate-700">
        <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-teal-700" />
          <span>Diagnostic Protocol & Laboratory Reviews</span>
        </h4>
        <p className="leading-relaxed text-slate-600">
          Dr. Jagadish Das emphasizes targeted, rational diagnostic testing. Routine blood counts, lipid profiles, HbA1c, thyroid function tests, liver & renal panels, and ECGs are ordered strictly when clinically indicated. Follow-up reviews for recent reports are streamlined to ensure timely therapeutic adjustments.
        </p>
      </div>

      {/* CTA Box */}
      <div className="p-8 rounded-3xl bg-slate-900 text-white flex flex-col sm:flex-row items-center justify-between gap-6">
        <div>
          <h3 className="text-2xl font-serif font-bold">Need a Clinical Consultation?</h3>
          <p className="text-xs text-slate-300 mt-1">
            Standard OPD Consultation Fee: ₹{clinic?.consultationFee || 500} · Instant SMS & WhatsApp Confirmation
          </p>
        </div>
        <button
          onClick={onBookClick}
          className="px-6 py-3.5 bg-teal-400 hover:bg-teal-300 text-slate-900 rounded-xl font-bold text-sm shadow-md transition-all shrink-0"
        >
          Book Your Appointment
        </button>
      </div>
    </div>
  );
};
