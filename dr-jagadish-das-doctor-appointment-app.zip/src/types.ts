export type AppointmentStatus = 'PENDING' | 'CONFIRMED' | 'COMPLETED' | 'CANCELLED' | 'NO-SHOW';

export interface DoctorProfile {
  id?: string;
  name: string;
  degrees: string;
  specialization: string;
  experienceYears: number;
  registrationNumber: string;
  registrationCouncil: string;
  consultationFee: number;
  languages: string[];
  photoUrl: string;
  about: string;
  qualifications: {
    degree: string;
    institution: string;
    year: string;
  }[];
  services: {
    title: string;
    description: string;
    icon: string;
  }[];
}

export interface ClinicSettings {
  name: string;
  tagline: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  state: string;
  postalCode: string;
  phone: string;
  emergencyPhone: string;
  email: string;
  googleMapsUrl: string;
  googleMapsEmbedUrl?: string;
  parkingInfo: string;
  consultationFee: number;
  notice: string;
  whatsappApiKey?: string;
  whatsappPhoneNumberId?: string;
  smsApiKey?: string;
  smsSenderId?: string;
  doctorPhoneNumber?: string;
}

export interface AvailabilitySettings {
  workingDays: number[];
  morningShift: {
    enabled: boolean;
    startTime: string;
    endTime: string;
  };
  eveningShift: {
    enabled: boolean;
    startTime: string;
    endTime: string;
  };
  slotDurationMinutes: number;
  maxAppointmentsPerDay: number;
  holidays: {
    date: string;
    reason: string;
  }[];
}

export interface Appointment {
  appointment_id: string;
  doctor_id: string;
  patient_id: string;
  patient_name: string;
  patient_phone: string;
  patient_email: string;
  patient_age: number;
  patient_gender: 'Male' | 'Female' | 'Other';
  patient_address: string;
  appointment_date: string;
  appointment_time: string;
  reason: string;
  status: AppointmentStatus;
  doctor_notes: string;
  created_at: string;
  updated_at: string;
  cancelled_at?: string;
  cancellation_reason?: string;
}

export interface Patient {
  patient_id: string;
  name: string;
  phone: string;
  email: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  address: string;
  created_at: string;
  updated_at: string;
  appointmentCount?: number;
  lastVisitDate?: string;
  latestStatus?: string;
}

export interface NotificationLog {
  id: string;
  type: 'WhatsApp' | 'SMS';
  recipient: 'Doctor' | 'Patient';
  recipient_phone: string;
  appointment_id: string;
  message: string;
  timestamp: string;
  status: 'Sent' | 'Failed' | 'Fallback Sent';
  error?: string;
}

export interface PublicClinicInfo {
  doctor: DoctorProfile;
  clinic: ClinicSettings;
  availability: AvailabilitySettings;
}

export interface TimeSlot {
  time: string;
  shift: 'Morning' | 'Evening';
  available: boolean;
  status: 'available' | 'booked' | 'past';
}

export interface AvailableSlotsResponse {
  date: string;
  isOpen: boolean;
  reason?: string;
  totalSlots: number;
  availableSlotsCount: number;
  slots: TimeSlot[];
}

export interface DashboardStats {
  todayCount: number;
  upcomingCount: number;
  totalCount: number;
  pendingCount: number;
  confirmedCount: number;
  completedCount: number;
  cancelledCount: number;
  noShowCount: number;
  todayPatientCount: number;
  trend: { date: string; label: string; count: number }[];
  consultationFee: number;
  todayRevenueEstimate: number;
}
